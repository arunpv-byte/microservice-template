-- Database initialization script
-- Run this script to manually create the database and tables

USE master;
GO

IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'MicroserviceDb')
BEGIN
    CREATE DATABASE MicroserviceDb;
END
GO

USE MicroserviceDb;
GO

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Orders')
BEGIN
    CREATE TABLE Orders (
        Id UNIQUEIDENTIFIER PRIMARY KEY,
        CustomerName NVARCHAR(200) NOT NULL,
        Amount DECIMAL(18,2) NOT NULL,
        Currency NVARCHAR(3) NOT NULL,
        Status INT NOT NULL,
        CreatedAt DATETIME2 NOT NULL,
        UpdatedAt DATETIME2 NULL
    );
    
    CREATE INDEX IX_Orders_CreatedAt ON Orders(CreatedAt);
    CREATE INDEX IX_Orders_Status ON Orders(Status);
END
GO
