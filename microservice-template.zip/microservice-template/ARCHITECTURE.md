# Architecture Documentation

## Overview

This microservice template implements Clean Architecture with Vertical Slice pattern, ensuring maintainability, testability, and scalability. It features dynamic third-party service authentication, comprehensive enterprise features, and a factory pattern for external service integration.

## Enterprise Features

### API Versioning
- URL-based versioning (`/api/v1/endpoint`)
- Query string and header support
- Automatic API explorer integration

### Rate Limiting
- Fixed window (100 req/min) and token bucket policies
- Configurable per endpoint
- Automatic 429 responses

### Circuit Breaker & Resilience
- Polly-based circuit breaker pattern
- Exponential backoff retry policy
- Transient fault handling

### Distributed Tracing
- OpenTelemetry integration
- ASP.NET Core, HTTP, and SQL instrumentation
- Jaeger exporter support

### Caching
- Redis distributed caching with memory fallback
- JSON serialization support
- Configurable cache providers

### Event-Driven Architecture
- Domain events with MediatR
- Message publishing abstraction
- In-memory publisher for development

## Architectural Principles

### Clean Architecture

The solution follows Clean Architecture with clear separation of concerns:

```
┌─────────────────────────────────────────┐
│              API Layer                  │
│  (Controllers, Middleware, Filters)     │
└─────────────────┬───────────────────────┘
                  │
┌─────────────────▼───────────────────────┐
│         Application Layer               │
│  (Features, Handlers, Validators)       │
└─────────────────┬───────────────────────┘
                  │
┌─────────────────▼───────────────────────┐
│           Domain Layer                  │
│  (Entities, Value Objects, Exceptions)  │
└─────────────────────────────────────────┘
                  ▲
                  │
┌─────────────────┴───────────────────────┐
│       Infrastructure Layer              │
│  (Repositories, Persistence, Services)  │
└─────────────────────────────────────────┘
```

### Dependency Rules

1. **Domain** has NO dependencies
2. **Application** depends only on Domain
3. **Infrastructure** depends on Application
4. **API** depends on Application and Infrastructure

### Vertical Slice Pattern

Each feature is self-contained:

```
Features/
└── Cardholders/
    ├── CreateCardholder/
    │   ├── CreateCardholderCommand.cs
    │   ├── CreateCardholderHandler.cs
    │   └── CreateCardholderResponse.cs
    ├── GetCardholder/
    │   ├── GetCardholderQuery.cs
    │   ├── GetCardholderHandler.cs
    │   └── GetCardholderResponse.cs
    └── UpdateCardholder/
        ├── UpdateCardholderCommand.cs
        ├── UpdateCardholderHandler.cs
        └── UpdateCardholderResponse.cs
└── Cards/
    └── GetCardBalance/
        ├── GetCardBalanceQuery.cs
        ├── GetCardBalanceHandler.cs
        └── GetCardBalanceResponse.cs
```

## Third-Party Service Integration

### Dynamic Authentication Factory

The template implements a factory pattern for dynamic third-party service authentication:

```
┌─────────────────────────────────────────┐
│         IThirdPartyServiceFactory       │
│  ┌─────────────────────────────────────┐ │
│  │     Configuration-Based Auth       │ │
│  │  ┌─────────────────────────────────┐│ │
│  │  │ Bearer │ ApiKey │ Basic Auth   ││ │
│  │  └─────────────────────────────────┘│ │
│  └─────────────────────────────────────┘ │
└─────────────────────────────────────────┘
                  │
┌─────────────────▼───────────────────────┐
│        Third-Party Services             │
│  ┌─────────┐ ┌─────────┐ ┌─────────────┐│
│  │NymCard  │ │ Stripe  │ │   PayPal    ││
│  │(ApiKey) │ │(Bearer) │ │   (Basic)   ││
│  └─────────┘ └─────────┘ └─────────────┘│
└─────────────────────────────────────────┘
```

### Configuration-Driven Authentication

```json
"ThirdPartyServices": {
  "NymCard": {
    "BaseUrl": "https://api.sand.platform.nymcard.com",
    "AuthType": "ApiKey",
    "ApiKey": "<NymCardApiKey>"
  },
  "Stripe": {
    "BaseUrl": "https://api.stripe.com",
    "AuthType": "Bearer",
    "Token": "<StripeApiKey>"
  },
  "PayPal": {
    "BaseUrl": "https://api.paypal.com",
    "AuthType": "Basic",
    "Username": "<PayPalClientId>",
    "Password": "<PayPalClientSecret>"
  }
}
```

## Layer Responsibilities

### Domain Layer

- Contains business entities with rich behavior
- Defines value objects for domain concepts
- Declares domain exceptions
- NO framework dependencies
- NO DTOs

**Key Files:**
- `Entities/Order.cs` - Rich domain entity
- `ValueObjects/Money.cs` - Immutable value object
- `Exceptions/DomainException.cs` - Base domain exception

### Application Layer

- Implements use cases via handlers
- Defines repository interfaces
- Contains validation logic
- Orchestrates domain operations

**Key Files:**
- `Features/*/Handler.cs` - Use case implementation
- `Interfaces/IOrderRepository.cs` - Repository contract
- `Validators/*Validator.cs` - FluentValidation rules
- `Behaviors/ValidationBehavior.cs` - MediatR pipeline

### Infrastructure Layer

- Implements repository interfaces
- Handles data persistence with Dapper
- Manages external service integrations with dynamic authentication
- Database initialization
- Third-party service factory pattern
- Circuit breaker and resilience patterns
- Caching with Redis/Memory support
- Message publishing for event-driven architecture

**Key Files:**
- `Repositories/CardholderRepository.cs` - Dapper implementation
- `Persistence/DatabaseInitializer.cs` - Schema setup
- `Configurations/DependencyInjection.cs` - Service registration with enterprise features
- `Services/ThirdPartyServiceFactory.cs` - Dynamic service resolution
- `ExternalServices/Clients/NymCardService.cs` - Third-party API client
- `Resilience/ResilienceExtensions.cs` - Circuit breaker configuration
- `Caching/CachingExtensions.cs` - Redis/Memory caching setup
- `Caching/RedisCacheService.cs` - Cache service implementation
- `Messaging/InMemoryMessagePublisher.cs` - Event publishing

### API Layer

- Exposes HTTP endpoints for cardholder and card management with API versioning
- Handles global exception handling and rate limiting
- Implements request/response logging with distributed tracing
- Configures middleware pipeline with enterprise features
- JWT Bearer authentication for Swagger
- OpenTelemetry instrumentation

**Key Files:**
- `Controllers/CardholdersController.cs` - Cardholder CRUD endpoints with v1.0 versioning
- `Controllers/CardsController.cs` - Card balance endpoints with rate limiting
- `Middleware/GlobalExceptionMiddleware.cs` - Exception handling
- `Middleware/RequestLoggingMiddleware.cs` - Request logging
- `Middleware/RateLimitingExtensions.cs` - Rate limiting configuration
- `Versioning/ApiVersioningExtensions.cs` - API versioning setup
- `Telemetry/TelemetryExtensions.cs` - OpenTelemetry configuration
- `Program.cs` - Application bootstrap with enterprise features

## Design Patterns

### CQRS (Command Query Responsibility Segregation)

- **Commands**: Modify state (CreateOrder, UpdateOrder)
- **Queries**: Read state (GetOrder)
- Implemented via MediatR

### Repository Pattern

- Abstracts data access
- Defined in Application, implemented in Infrastructure
- Enables testability and flexibility

### Mediator Pattern

- Decouples request/response handling
- Enables cross-cutting concerns via behaviors
- Implemented via MediatR library

## Cross-Cutting Concerns

### API Versioning

- URL-based versioning with Asp.Versioning
- Multiple versioning strategies (URL, query, header)
- Automatic API explorer integration

### Rate Limiting

- .NET 8 built-in rate limiting
- Fixed window and token bucket algorithms
- Per-endpoint configuration

### Circuit Breaker

- Polly-based resilience patterns
- Exponential backoff retry
- Automatic circuit breaking

### Distributed Tracing

- OpenTelemetry instrumentation
- ASP.NET Core, HTTP, and SQL tracing
- Jaeger exporter integration

### Caching

- Redis distributed caching
- Memory caching fallback
- JSON serialization support

### Event Publishing

- Domain events with MediatR
- Message publishing abstraction
- In-memory publisher for development

### Validation

- FluentValidation for declarative validation
- ValidationBehavior in MediatR pipeline
- Fail-fast approach

### Logging

- Structured logging with Serilog
- LoggingBehavior tracks handler execution
- RequestLoggingMiddleware logs HTTP requests
- Correlation ID for request tracing

### Exception Handling

- GlobalExceptionMiddleware catches all exceptions
- Domain exceptions mapped to HTTP status codes
- Structured error responses with correlation ID

### Health Checks

- Database connectivity check
- Exposed at `/health` endpoint
- Kubernetes-ready

## Data Flow

### Command Flow (Create Cardholder)

```
1. HTTP POST → CardholdersController.CreateCardholder()
2. Controller → MediatR.Send(CreateCardholderCommand)
3. MediatR Pipeline:
   - LoggingBehavior (start)
   - ValidationBehavior (validate)
   - CreateCardholderHandler.Handle()
4. Handler → ThirdPartyServiceFactory.GetService<INymCardService>()
5. Handler → NymCardService.CreateUserAsync() (with dynamic auth)
6. Handler → Domain (Cardholder.Create)
7. Handler → Repository.CreateAsync()
8. Repository → Database (Dapper)
9. Response ← CreateCardholderResponse
10. HTTP 201 Created
```

### Query Flow (Get Card Balance)

```
1. HTTP GET → CardsController.GetCardBalance(accountId)
2. Controller → MediatR.Send(GetCardBalanceQuery)
3. MediatR Pipeline:
   - LoggingBehavior (start)
   - GetCardBalanceHandler.Handle()
4. Handler → ThirdPartyServiceFactory.GetService<INymCardService>()
5. Handler → NymCardService.GetAccountAsync() (with dynamic auth)
6. Response ← GetCardBalanceResponse
7. HTTP 200 OK
```

### Third-Party Service Authentication Flow

```
1. Application Startup:
   - DependencyInjection.AddNymCardService()
   - ConfigureServiceAuth() reads ThirdPartyServices config
   - HttpClient configured with auth headers

2. Runtime Service Resolution:
   - Handler → ThirdPartyServiceFactory.GetService<T>()
   - Factory → ServiceProvider.GetRequiredService<T>()
   - DI Container → Creates service with pre-configured HttpClient
   - Service → Makes authenticated API calls
```

## Testing Strategy

### Unit Tests

- Domain entity behavior
- Application handler logic
- No external dependencies
- Fast execution

### Integration Tests

- End-to-end API testing
- WebApplicationFactory
- Test database

## Extension Points

### Adding New Features

1. Create feature folder in `Application/Features/`
2. Define Command/Query with MediatR
3. Implement Handler with factory pattern for external services
4. Add Validator
5. Add Controller endpoint
6. Write tests

### Adding New Third-Party Services

1. Define service interface in `Application/Interfaces/`
2. Implement service client in `Infrastructure/ExternalServices/Clients/`
3. Add service configuration in `appsettings.json` under `ThirdPartyServices`
4. Register service in `DependencyInjection.cs` with `ConfigureServiceAuth`
5. Use via `IThirdPartyServiceFactory` in handlers

### Adding New Entities

1. Create entity in `Domain/Entities/`
2. Define repository interface in `Application/Interfaces/`
3. Implement repository in `Infrastructure/Repositories/`
4. Update DatabaseInitializer

### Adding Behaviors

1. Create behavior in `Application/Behaviors/`
2. Implement `IPipelineBehavior<TRequest, TResponse>`
3. Register in `ServiceCollectionExtensions`

## Best Practices

1. **Keep Domain Pure**: No framework dependencies in Domain layer
2. **Rich Domain Models**: Behavior in entities, not anemic models
3. **Immutable Value Objects**: Use records for value objects
4. **Explicit Dependencies**: Constructor injection only
5. **Async All The Way**: Use async/await consistently
6. **Cancellation Tokens**: Support cancellation in all async methods
7. **Structured Logging**: Use structured logging with context
8. **Fail Fast**: Validate early, throw meaningful exceptions
