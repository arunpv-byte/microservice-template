using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using microservice_template.Application.Features.Cardholders.CreateCardholder;
using microservice_template.Application.Interfaces;
using microservice_template.Domain.Entities;

namespace microservice_template.UnitTests.Application;

public sealed class CreateCardholderHandlerTests
{
    [Fact]
    public async Task Handle_WithValidRequest_ShouldReturnSuccessResponse()
    {
        // Arrange
        var mockNymCardService = new Mock<INymCardService>();
        var mockServiceFactory = new Mock<IThirdPartyServiceFactory>();
        var mockCardholderRepository = new Mock<ICardholderRepository>();
        var mockLogger = new Mock<ILogger<CreateCardholderHandler>>();

        var nymCardResponse = new NymCardCreateUserResponse("user-123", "Success", "User created");
        mockNymCardService.Setup(x => x.CreateUserAsync(It.IsAny<NymCardCreateUserRequest>(), It.IsAny<CancellationToken>()))
                         .ReturnsAsync(nymCardResponse);
        mockServiceFactory.Setup(x => x.GetService<INymCardService>())
                         .Returns(mockNymCardService.Object);

        mockCardholderRepository.Setup(x => x.CreateAsync(It.IsAny<Cardholder>(), It.IsAny<CancellationToken>()))
                               .ReturnsAsync((Cardholder c, CancellationToken _) => c);
        mockCardholderRepository.Setup(x => x.GetCtsCredCentreId(It.IsAny<string>(), It.IsAny<string>()))
                               .Returns("123");
        mockCardholderRepository.Setup(x => x.checkcardholderref(It.IsAny<int>(), It.IsAny<string>()))
                               .Returns(0);
        mockCardholderRepository.Setup(x => x.GetParentUserId(It.IsAny<string>()))
                               .Returns("parent-123");

        var handler = new CreateCardholderHandler(mockServiceFactory.Object, mockCardholderRepository.Object, mockLogger.Object);
        
        var command = new CreateCardholderCommand(
            "John", "Doe", "john@example.com", "+1234567890",
            "1990-01-01", "123 Main St", "Apt 1", "Building A", "City", "Country", "12345",
            "testuser", "device123", "Mr", "Middle", "Johnny", "M");

        // Act
        var result = await handler.Handle(command, CancellationToken.None);

        // Assert
        result.userId.Should().Be("user-123");
        result.firstName.Should().Be("John");
        result.lastName.Should().Be("Doe");
        result.email.Should().Be("john@example.com");
        result.status.Should().Be("Success");
        result.createdAt.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(5));

        mockCardholderRepository.Verify(x => x.CreateAsync(It.IsAny<Cardholder>(), It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task Handle_WithNymCardFailure_ShouldReturnErrorResponse()
    {
        // Arrange
        var mockNymCardService = new Mock<INymCardService>();
        var mockServiceFactory = new Mock<IThirdPartyServiceFactory>();
        var mockCardholderRepository = new Mock<ICardholderRepository>();
        var mockLogger = new Mock<ILogger<CreateCardholderHandler>>();

        var nymCardResponse = new NymCardCreateUserResponse("", "Error", "API Error");
        mockNymCardService.Setup(x => x.CreateUserAsync(It.IsAny<NymCardCreateUserRequest>(), It.IsAny<CancellationToken>()))
                         .ReturnsAsync(nymCardResponse);
        mockServiceFactory.Setup(x => x.GetService<INymCardService>())
                         .Returns(mockNymCardService.Object);

        mockCardholderRepository.Setup(x => x.CreateAsync(It.IsAny<Cardholder>(), It.IsAny<CancellationToken>()))
                               .ReturnsAsync((Cardholder c, CancellationToken _) => c);
        mockCardholderRepository.Setup(x => x.GetCtsCredCentreId(It.IsAny<string>(), It.IsAny<string>()))
                               .Returns("123");
        mockCardholderRepository.Setup(x => x.checkcardholderref(It.IsAny<int>(), It.IsAny<string>()))
                               .Returns(0);
        mockCardholderRepository.Setup(x => x.GetParentUserId(It.IsAny<string>()))
                               .Returns("parent-123");

        var handler = new CreateCardholderHandler(mockServiceFactory.Object, mockCardholderRepository.Object, mockLogger.Object);
        
        var command = new CreateCardholderCommand(
            "John", "Doe", "john@example.com", "+1234567890",
            "1990-01-01", "123 Main St", "Apt 1", "Building A", "City", "Country", "12345",
            "testuser", "device123", "Mr", "Middle", "Johnny", "M");

        // Act
        var result = await handler.Handle(command, CancellationToken.None);

        // Assert
        result.userId.Should().BeEmpty();
        result.status.Should().Be("Error");
    }
}
