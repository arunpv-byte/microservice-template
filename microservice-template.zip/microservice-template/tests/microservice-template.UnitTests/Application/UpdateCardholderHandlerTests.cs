using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using microservice_template.Application.Features.Cardholders.UpdateCardholder;
using microservice_template.Application.Interfaces;
using microservice_template.Domain.Entities;

namespace microservice_template.UnitTests.Application;

public sealed class UpdateCardholderHandlerTests
{
    [Fact]
    public async Task Handle_WithValidRequest_ShouldReturnSuccessResponse()
    {
        // Arrange
        var mockNymCardService = new Mock<INymCardService>();
        var mockServiceFactory = new Mock<IThirdPartyServiceFactory>();
        var mockCardholderRepository = new Mock<ICardholderRepository>();
        var mockLogger = new Mock<ILogger<UpdateCardholderHandler>>();

        var existingCardholder = Cardholder.Create("252525","user-123", "John", "Doe", "john@example.com", "+1234567890",
            "1990-01-01", "123 Main St", "sfdgfdg", "City", "Country", "12345");

        var nymCardResponse = new NymCardUpdateUserResponse("user-123", "Success", "User updated");
        mockNymCardService.Setup(x => x.UpdateUserAsync(It.IsAny<string>(), It.IsAny<NymCardUpdateUserRequest>(), It.IsAny<CancellationToken>()))
                         .ReturnsAsync(nymCardResponse);
        mockServiceFactory.Setup(x => x.GetService<INymCardService>())
                         .Returns(mockNymCardService.Object);

        mockCardholderRepository.Setup(x => x.GetByNymCardUserIdAsync("user-123", It.IsAny<CancellationToken>()))
                               .ReturnsAsync(existingCardholder);

        mockCardholderRepository.Setup(x => x.UpdateAsync(It.IsAny<Cardholder>(), It.IsAny<CancellationToken>()))
                               .ReturnsAsync((Cardholder c, CancellationToken _) => c);

        var handler = new UpdateCardholderHandler(mockServiceFactory.Object, mockCardholderRepository.Object, mockLogger.Object);
        
        var command = new UpdateCardholderCommand(
            "user-123","john@example.com", "+1234567890");

        // Act
        var result = await handler.Handle(command, CancellationToken.None);

        // Assert
        result.cardholderReference.Should().Be("user-123");
        result.emailAddress.Should().Be("john@example.com");

        mockCardholderRepository.Verify(x => x.UpdateAsync(It.IsAny<Cardholder>(), It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task Handle_WithNymCardFailure_ShouldReturnErrorResponse()
    {
        // Arrange
        var mockNymCardService = new Mock<INymCardService>();
        var mockServiceFactory = new Mock<IThirdPartyServiceFactory>();
        var mockCardholderRepository = new Mock<ICardholderRepository>();
        var mockLogger = new Mock<ILogger<UpdateCardholderHandler>>();

        var existingCardholder = Cardholder.Create("252525","user-123", "John", "Doe", "john@example.com", "+1234567890",
            "1990-01-01", "123 Main St", "dfsff", "City", "Country", "12345");

        var nymCardResponse = new NymCardUpdateUserResponse("user-123", "Error", "API Error");
        mockNymCardService.Setup(x => x.UpdateUserAsync(It.IsAny<string>(), It.IsAny<NymCardUpdateUserRequest>(), It.IsAny<CancellationToken>()))
                         .ReturnsAsync(nymCardResponse);
        mockServiceFactory.Setup(x => x.GetService<INymCardService>())
                         .Returns(mockNymCardService.Object);

        mockCardholderRepository.Setup(x => x.GetByNymCardUserIdAsync("user-123", It.IsAny<CancellationToken>()))
                               .ReturnsAsync(existingCardholder);

        mockCardholderRepository.Setup(x => x.UpdateAsync(It.IsAny<Cardholder>(), It.IsAny<CancellationToken>()))
                               .ReturnsAsync((Cardholder c, CancellationToken _) => c);

        var handler = new UpdateCardholderHandler(mockServiceFactory.Object, mockCardholderRepository.Object, mockLogger.Object);
        
        var command = new UpdateCardholderCommand(
            "user-123", "john@example.com", "+1234567890");

        // Act
        var result = await handler.Handle(command, CancellationToken.None);

        // Assert
        result.cardholderReference.Should().Be("user-123");
    }
}
