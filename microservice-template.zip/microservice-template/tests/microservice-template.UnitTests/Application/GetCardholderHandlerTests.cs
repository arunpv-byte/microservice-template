using FluentAssertions;
using Moq;
using microservice_template.Application.Features.Cardholders.GetCardholder;
using microservice_template.Application.Interfaces;
using microservice_template.Domain.Entities;
using microservice_template.Domain.Exceptions;

namespace microservice_template.UnitTests.Application;

public sealed class GetCardholderHandlerTests
{
    [Fact]
    public async Task Handle_WithValidUserId_ShouldReturnCardholder()
    {
        // Arrange
        var mockCardholderRepository = new Mock<ICardholderRepository>();
        var cardholder = Cardholder.Create(
            "24526", "user-123", "John", "Doe", "john@example.com", "+1234567890",
            "1990-01-01", "123 Main St", "dsdfsdf", "City", "Country", "12345");

        mockCardholderRepository.Setup(x => x.GetByNymCardUserIdAsync("user-123", It.IsAny<CancellationToken>()))
                               .ReturnsAsync(cardholder);

        var handler = new GetCardholderHandler(mockCardholderRepository.Object);
        var query = new GetCardholderQuery("user-123");

        // Act
        var result = await handler.Handle(query, CancellationToken.None);

        // Assert
        result.cardholderReference.Should().Be("user-123");
        result.firstName.Should().Be("John");
        result.lastName.Should().Be("Doe");
        result.emailAddress.Should().Be("john@example.com");
    }

    [Fact]
    public async Task Handle_WithInvalidUserId_ShouldThrowNotFoundException()
    {
        // Arrange
        var mockCardholderRepository = new Mock<ICardholderRepository>();
        mockCardholderRepository.Setup(x => x.GetByNymCardUserIdAsync("invalid-user", It.IsAny<CancellationToken>()))
                               .ReturnsAsync((Cardholder?)null);

        var handler = new GetCardholderHandler(mockCardholderRepository.Object);
        var query = new GetCardholderQuery("invalid-user");

        // Act & Assert
        await handler.Invoking(h => h.Handle(query, CancellationToken.None))
                    .Should().ThrowAsync<NotFoundException>()
                    .WithMessage("Cardholder with userId 'invalid-user' was not found.");
    }
}
