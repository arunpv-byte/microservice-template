using FluentAssertions;
using Moq;
using microservice_template.Application.Features.Cards.GetCardBalance;
using microservice_template.Application.Interfaces;
using microservice_template.Domain.Exceptions;

namespace microservice_template.UnitTests.Application;

public sealed class GetCardBalanceHandlerTests
{
    [Fact]
    public async Task Handle_WithValidAccountId_ShouldReturnCardBalance()
    {
        // Arrange
        var mockNymCardService = new Mock<INymCardService>();
        var mockServiceFactory = new Mock<IThirdPartyServiceFactory>();
        var accountResponse = new NymCardAccountResponse("account-123", 1500.50m, "USD");

        mockNymCardService.Setup(x => x.GetAccountAsync("account-123", It.IsAny<CancellationToken>()))
                         .ReturnsAsync(accountResponse);
        mockServiceFactory.Setup(x => x.GetService<INymCardService>())
                         .Returns(mockNymCardService.Object);

        var handler = new GetCardBalanceHandler(mockServiceFactory.Object);
        var query = new GetCardBalanceQuery("account-123");

        // Act
        var result = await handler.Handle(query, CancellationToken.None);

        // Assert
        result.AccountId.Should().Be("account-123");
        result.AvailableBalance.Should().Be(1500.50m);
        result.Currency.Should().Be("USD");
    }

    [Fact]
    public async Task Handle_WithInvalidAccountId_ShouldThrowNotFoundException()
    {
        // Arrange
        var mockNymCardService = new Mock<INymCardService>();
        var mockServiceFactory = new Mock<IThirdPartyServiceFactory>();
        
        mockNymCardService.Setup(x => x.GetAccountAsync("invalid-account", It.IsAny<CancellationToken>()))
                         .ReturnsAsync((NymCardAccountResponse?)null);
        mockServiceFactory.Setup(x => x.GetService<INymCardService>())
                         .Returns(mockNymCardService.Object);

        var handler = new GetCardBalanceHandler(mockServiceFactory.Object);
        var query = new GetCardBalanceQuery("invalid-account");

        // Act & Assert
        await handler.Invoking(h => h.Handle(query, CancellationToken.None))
                    .Should().ThrowAsync<NotFoundException>()
                    .WithMessage("Account with ID 'invalid-account' was not found.");
    }
}