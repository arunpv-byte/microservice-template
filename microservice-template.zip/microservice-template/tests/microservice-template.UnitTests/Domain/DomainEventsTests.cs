using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using microservice_template.Domain.Events;
using microservice_template.Infrastructure.Messaging;

namespace microservice_template.UnitTests.Domain;

public sealed class DomainEventsTests
{
    [Fact]
    public async Task PublishDomainEventAsync_WithValidEvent_ShouldLogMessage()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<InMemoryMessagePublisher>>();
        var publisher = new InMemoryMessagePublisher(mockLogger.Object);

        var domainEvent = new CardholderCreatedEvent("user-123", "john@example.com", "John", "Doe", DateTime.UtcNow);

        // Act
        await publisher.PublishDomainEventAsync(domainEvent);

        // Assert - verify the method completes without error
        // In a real implementation, you would verify the message was published
    }

    [Fact]
    public void CardholderCreatedEvent_WithValidData_ShouldCreateEvent()
    {
        // Arrange & Act
        var createdAt = DateTime.UtcNow;
        var domainEvent = new CardholderCreatedEvent("user-123", "john@example.com", "John", "Doe", createdAt);

        // Assert
        domainEvent.UserId.Should().Be("user-123");
        domainEvent.Email.Should().Be("john@example.com");
        domainEvent.FirstName.Should().Be("John");
        domainEvent.LastName.Should().Be("Doe");
        domainEvent.CreatedAt.Should().Be(createdAt);
        domainEvent.OccurredOn.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));
    }
}