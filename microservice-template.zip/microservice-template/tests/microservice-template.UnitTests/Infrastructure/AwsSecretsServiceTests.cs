using FluentAssertions;
using Moq;
using Amazon.SecretsManager;
using Amazon.SimpleSystemsManagement;
using Amazon.SecretsManager.Model;
using Amazon.SimpleSystemsManagement.Model;
using microservice_template.Infrastructure.Services;

namespace microservice_template.UnitTests.Infrastructure;

public sealed class AwsSecretsServiceTests
{
    [Fact]
    public async Task GetSecretAsync_WithValidSecret_ShouldReturnValue()
    {
        // Arrange
        var mockSecretsManager = new Mock<IAmazonSecretsManager>();
        var mockSsm = new Mock<IAmazonSimpleSystemsManagement>();
        
        var secretResponse = new GetSecretValueResponse
        {
            SecretString = "test-secret-value"
        };
        
        mockSecretsManager.Setup(x => x.GetSecretValueAsync(It.IsAny<GetSecretValueRequest>(), It.IsAny<CancellationToken>()))
                         .ReturnsAsync(secretResponse);

        var service = new AwsSecretsService(mockSecretsManager.Object, mockSsm.Object);

        // Act
        var result = await service.GetSecretAsync("test-secret");

        // Assert
        result.Should().Be("test-secret-value");
    }

    [Fact]
    public async Task GetParameterAsync_WithValidParameter_ShouldReturnValue()
    {
        // Arrange
        var mockSecretsManager = new Mock<IAmazonSecretsManager>();
        var mockSsm = new Mock<IAmazonSimpleSystemsManagement>();
        
        var parameterResponse = new GetParameterResponse
        {
            Parameter = new Parameter
            {
                Value = "test-parameter-value"
            }
        };
        
        mockSsm.Setup(x => x.GetParameterAsync(It.IsAny<GetParameterRequest>(), It.IsAny<CancellationToken>()))
               .ReturnsAsync(parameterResponse);

        var service = new AwsSecretsService(mockSecretsManager.Object, mockSsm.Object);

        // Act
        var result = await service.GetParameterAsync("/test/parameter");

        // Assert
        result.Should().Be("test-parameter-value");
    }
}