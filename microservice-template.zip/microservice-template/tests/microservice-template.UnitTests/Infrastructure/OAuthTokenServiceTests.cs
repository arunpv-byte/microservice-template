using FluentAssertions;
using Moq;
 using System.Net;
using microservice_template.Infrastructure.Services;
using microservice_template.UnitTests.TestUtilities;

namespace microservice_template.UnitTests.Infrastructure;

public sealed class OAuthTokenServiceTests
{
    [Fact]
    public async Task GetTokenAsync_WithClientCredentials_ShouldReturnToken()
    {
        // Arrange
        var mockHandler = new MockHttpMessageHandler();
        mockHandler.SetupResponse("https://auth.example.com/token", 
            HttpStatusCode.OK, 
            new { access_token = "test-token", expires_in = 3600 });
        
        var httpClient = new HttpClient(mockHandler);
        var service = new OAuthTokenService(httpClient);

        // Act
        var result = await service.GetTokenAsync(
            "https://auth.example.com/token",
            "client-id",
            "client-secret",
            "client_credentials");

        // Assert
        result.Should().Be("test-token");
    }

    [Fact]
    public async Task GetTokenAsync_WithPasswordGrant_ShouldReturnToken()
    {
        // Arrange
        var mockHandler = new MockHttpMessageHandler();
        mockHandler.SetupResponse("https://auth.example.com/token", 
            HttpStatusCode.OK, 
            new { access_token = "password-token", expires_in = 3600 });
        
        var httpClient = new HttpClient(mockHandler);
        var service = new OAuthTokenService(httpClient);

        // Act
        var result = await service.GetTokenAsync(
            "https://auth.example.com/token",
            "client-id",
            "client-secret",
            "password",
            "username",
            "password123");

        // Assert
        result.Should().Be("password-token");
    }
}