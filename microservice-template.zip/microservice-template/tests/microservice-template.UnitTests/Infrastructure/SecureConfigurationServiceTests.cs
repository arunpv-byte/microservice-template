using FluentAssertions;
using Microsoft.Extensions.Configuration;
using Moq;
using microservice_template.Infrastructure.Configuration;
using microservice_template.Infrastructure.Services;

namespace microservice_template.UnitTests.Infrastructure;

public sealed class SecureConfigurationServiceTests
{
    [Fact]
    public async Task GetConnectionStringAsync_WithAwsEnabled_ShouldUseAwsSecrets()
    {
        // Arrange
        Environment.SetEnvironmentVariable("AWS_REGION", "eu-west-2");
        
        var mockAwsSecretsService = new Mock<IAwsSecretsService>();
        var mockConfiguration = new Mock<IConfiguration>();
        
        mockAwsSecretsService.Setup(x => x.GetParameterAsync("/microservice-template/database/defaultconnection"))
                           .ReturnsAsync("aws-connection-string");

        var service = new SecureConfigurationService(mockAwsSecretsService.Object, mockConfiguration.Object);

        // Act
        var result = await service.GetConnectionStringAsync("DefaultConnection");

        // Assert
        result.Should().Be("aws-connection-string");
        
        // Cleanup
        Environment.SetEnvironmentVariable("AWS_REGION", null);
    }

    [Fact]
    public async Task GetConnectionStringAsync_WithAwsDisabled_ShouldUseFallback()
    {
        // Arrange
        Environment.SetEnvironmentVariable("AWS_REGION", null);
        
        var mockAwsSecretsService = new Mock<IAwsSecretsService>();
        
        // Create a real configuration with connection string
        var configBuilder = new ConfigurationBuilder();
        configBuilder.AddInMemoryCollection(new Dictionary<string, string?>
        {
            ["ConnectionStrings:DefaultConnection"] = "local-connection-string"
        });
        var configuration = configBuilder.Build();

        var service = new SecureConfigurationService(mockAwsSecretsService.Object, configuration);

        // Act
        var result = await service.GetConnectionStringAsync("DefaultConnection");

        // Assert
        result.Should().Be("local-connection-string");
    }

    [Fact]
    public async Task GetThirdPartyServiceConfigAsync_WithAwsEnabled_ShouldUseAwsSecrets()
    {
        // Arrange
        Environment.SetEnvironmentVariable("AWS_REGION", "eu-west-2");
        
        var mockAwsSecretsService = new Mock<IAwsSecretsService>();
        var mockConfiguration = new Mock<IConfiguration>();
        
        mockAwsSecretsService.Setup(x => x.GetParameterAsync("/microservice-template/nymcard/apikey"))
                           .ReturnsAsync("aws-api-key");

        var service = new SecureConfigurationService(mockAwsSecretsService.Object, mockConfiguration.Object);

        // Act
        var result = await service.GetThirdPartyServiceConfigAsync("NymCard", "ApiKey");

        // Assert
        result.Should().Be("aws-api-key");
        
        // Cleanup
        Environment.SetEnvironmentVariable("AWS_REGION", null);
    }
}