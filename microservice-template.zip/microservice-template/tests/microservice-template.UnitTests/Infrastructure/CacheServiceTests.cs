using FluentAssertions;
using Microsoft.Extensions.Caching.Memory;
using microservice_template.Infrastructure.Caching;

namespace microservice_template.UnitTests.Infrastructure;

public sealed class CacheServiceTests
{
    [Fact]
    public async Task SetAsync_WithMemoryCache_ShouldStoreValue()
    {
        // Arrange
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var service = new MemoryCacheService(memoryCache);

        var testData = new { Name = "Test", Value = 123 };

        // Act
        await service.SetAsync("test-key", testData, TimeSpan.FromMinutes(5));

        // Assert
        var result = await service.GetAsync<object>("test-key");
        result.Should().NotBeNull();
    }

    [Fact]
    public async Task GetAsync_WithNonExistentKey_ShouldReturnDefault()
    {
        // Arrange
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var service = new MemoryCacheService(memoryCache);

        // Act
        var result = await service.GetAsync<string>("non-existent-key");

        // Assert
        result.Should().BeNull();
    }

    [Fact]
    public async Task RemoveAsync_WithExistingKey_ShouldRemoveValue()
    {
        // Arrange
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var service = new MemoryCacheService(memoryCache);

        await service.SetAsync("test-key", "test-value", TimeSpan.FromMinutes(5));

        // Act
        await service.RemoveAsync("test-key");

        // Assert
        var result = await service.GetAsync<string>("test-key");
        result.Should().BeNull();
    }
}