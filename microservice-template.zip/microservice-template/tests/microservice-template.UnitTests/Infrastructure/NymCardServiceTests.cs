using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using microservice_template.Application.Interfaces;
using microservice_template.Infrastructure.ExternalServices.Abstractions;
using microservice_template.Infrastructure.ExternalServices.Clients;
using microservice_template.UnitTests.TestUtilities;

namespace microservice_template.UnitTests.Infrastructure;

public sealed class NymCardServiceTests
{
    [Fact]
    public async Task CreateUserAsync_WithValidRequest_ShouldReturnSuccess()
    {
        // Arrange
        var mockHandler = new MockHttpMessageHandler();
        mockHandler.SetupResponse("https://api.sand.platform.nymcard.com/v1/users", 
            HttpStatusCode.OK, 
            new { id = "user-123", status = "Success" });
        
        var httpClient = new HttpClient(mockHandler) 
        { 
            BaseAddress = new Uri("https://api.sand.platform.nymcard.com") 
        };
        
        var logger = new Mock<ILogger<NymCardService>>();

        var service = new NymCardService(httpClient, logger.Object);
        
        var request = new NymCardCreateUserRequest
        {
            FirstName = "John",
            LastName = "Doe",
            Email = "john@example.com",
            Mobile = "+1234567890",
            DateOfBirth = "1990-01-01",
            Address = new Address
            {
                AddressLine1 = "123 Main St",
                City = "City",
                Country = "Country",
                PostalCode = "12345"
            }
        };

        // Act
        var result = await service.CreateUserAsync(request, CancellationToken.None);

        // Assert
        result.UserId.Should().Be("user-123");
        result.Status.Should().Be("Success");
        result.Message.Should().Be("User created successfully");
    }

    [Fact]
    public async Task CreateUserAsync_WithHttpError_ShouldReturnError()
    {
        // Arrange
        var mockHandler = new MockHttpMessageHandler();
        mockHandler.SetupResponse("https://api.sand.platform.nymcard.com/v1/users", 
            HttpStatusCode.BadRequest);
        
        var httpClient = new HttpClient(mockHandler) 
        { 
            BaseAddress = new Uri("https://api.sand.platform.nymcard.com") 
        };
        
        var logger = new Mock<ILogger<NymCardService>>();

        var service = new NymCardService(httpClient, logger.Object);
        
        var request = new NymCardCreateUserRequest
        {
            FirstName = "John",
            LastName = "Doe",
            Email = "john@example.com",
            Mobile = "+1234567890",
            DateOfBirth = "1990-01-01",
            Address = new Address
            {
                AddressLine1 = "123 Main St",
                City = "City",
                Country = "Country",
                PostalCode = "12345"
            }
        };

        // Act
        var result = await service.CreateUserAsync(request, CancellationToken.None);

        // Assert
        result.UserId.Should().BeEmpty();
        result.Status.Should().Be("Error");
        result.Message.Should().Contain("External service unavailable");
    }

    [Fact]
    public async Task UpdateUserAsync_WithValidRequest_ShouldReturnSuccess()
    {
        // Arrange
        var userId = "user-123";
        var mockHandler = new MockHttpMessageHandler();
        mockHandler.SetupResponse($"https://api.sand.platform.nymcard.com/v1/users/{userId}", 
            HttpStatusCode.OK, 
            new { id = userId, status = "Success" });
        
        var httpClient = new HttpClient(mockHandler) 
        { 
            BaseAddress = new Uri("https://api.sand.platform.nymcard.com") 
        };
        
        var logger = new Mock<ILogger<NymCardService>>();

        var service = new NymCardService(httpClient, logger.Object);
        
        var request = new NymCardUpdateUserRequest(
            "John", "Doe", "john@example.com", "+1234567890",
            "123 Main St", "City", "Country", "12345");

        // Act
        var result = await service.UpdateUserAsync(userId, request, CancellationToken.None);

        // Assert
        result.UserId.Should().Be(userId);
        result.Status.Should().Be("Success");
        result.Message.Should().Be("User updated successfully");
    }

    [Fact]
    public async Task UpdateUserAsync_WithHttpError_ShouldReturnError()
    {
        // Arrange
        var userId = "user-123";
        var mockHandler = new MockHttpMessageHandler();
        mockHandler.SetupResponse($"https://api.sand.platform.nymcard.com/v1/users/{userId}", 
            HttpStatusCode.NotFound);
        
        var httpClient = new HttpClient(mockHandler) 
        { 
            BaseAddress = new Uri("https://api.sand.platform.nymcard.com") 
        };
        
        var logger = new Mock<ILogger<NymCardService>>();

        var service = new NymCardService(httpClient, logger.Object);
        
        var request = new NymCardUpdateUserRequest(
            "John", "Doe", "john@example.com", "+1234567890",
            "123 Main St", "City", "Country", "12345");

        // Act
        var result = await service.UpdateUserAsync(userId, request, CancellationToken.None);

        // Assert
        result.UserId.Should().Be(userId);
        result.Status.Should().Be("Error");
        result.Message.Should().Contain("External service unavailable");
    }
}