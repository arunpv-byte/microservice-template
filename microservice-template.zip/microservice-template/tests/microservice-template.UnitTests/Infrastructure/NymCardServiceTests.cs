using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using microservice_template.Application.Interfaces;
using microservice_template.Infrastructure.ExternalServices.Abstractions;
using microservice_template.Infrastructure.ExternalServices.Clients;
using microservice_template.UnitTests.TestUtilities;

namespace microservice_template.UnitTests.Infrastructure;

public sealed class NymCardServiceTests
{
    [Fact]
    public async Task CreateUserAsync_WithValidRequest_ShouldReturnSuccess()
    {
        // Arrange
        var mockHandler = new MockHttpMessageHandler();
        mockHandler.SetupResponse("https://api.sand.platform.nymcard.com/v1/users", 
            HttpStatusCode.OK, 
            new { id = "user-123", status = "Success" });
        
        var httpClient = new HttpClient(mockHandler) 
        { 
            BaseAddress = new Uri("https://api.sand.platform.nymcard.com") 
        };
        
        var logger = new Mock<ILogger<NymCardService>>();

        var service = new NymCardService(httpClient, logger.Object, Mock.Of<ICorrelationIdService>());
        
        var request = new Nymcard_CreateCardholderReq
        {
            first_name = "John",
            last_name = "Doe",
            email = "john@example.com",
            mobile = "+1234567890",
            date_of_birth = "1990-01-01",
            address = new Address
            {
                address_line1 = "123 Main St",
                city = "City",
                country = "Country",
                postal_code = "12345"
            }
        };

        // Act
        var result = await service.CreateUserAsync(request, CancellationToken.None);

        // Assert
        result.UserId.Should().Be("user-123");
        result.Status.Should().Be("Success");
        result.Message.Should().Be("User created successfully");
    }

    [Fact]
    public async Task CreateUserAsync_WithHttpError_ShouldReturnError()
    {
        // Arrange
        var mockHandler = new MockHttpMessageHandler();
        mockHandler.SetupResponse("https://api.sand.platform.nymcard.com/v1/users", 
            HttpStatusCode.BadRequest);
        
        var httpClient = new HttpClient(mockHandler) 
        { 
            BaseAddress = new Uri("https://api.sand.platform.nymcard.com") 
        };
        
        var logger = new Mock<ILogger<NymCardService>>();

        var service = new NymCardService(httpClient, logger.Object, Mock.Of<ICorrelationIdService>());
        
        var request = new Nymcard_CreateCardholderReq
        {
            first_name = "John",
            last_name = "Doe",
            email = "john@example.com",
            mobile = "+1234567890",
            date_of_birth = "1990-01-01",
            address = new Address
            {
                address_line1 = "123 Main St",
                city = "City",
                country = "Country",
                postal_code = "12345"
            }
        };

        // Act
        var result = await service.CreateUserAsync(request, CancellationToken.None);

        // Assert
        result.UserId.Should().BeEmpty();
        result.Status.Should().Be("Error");
        result.Message.Should().Contain("External service unavailable");
    }

    [Fact]
    public async Task UpdateUserAsync_WithValidRequest_ShouldReturnSuccess()
    {
        // Arrange
        var userId = "user-123";
        var mockHandler = new MockHttpMessageHandler();
        mockHandler.SetupResponse($"https://api.sand.platform.nymcard.com/v1/users/{userId}", 
            HttpStatusCode.OK, 
            new { id = userId, status = "Success" });
        
        var httpClient = new HttpClient(mockHandler) 
        { 
            BaseAddress = new Uri("https://api.sand.platform.nymcard.com") 
        };
        
        var logger = new Mock<ILogger<NymCardService>>();

        var service = new NymCardService(httpClient, logger.Object, Mock.Of<ICorrelationIdService>());
        
        var request = new NymCardUpdateUserRequest(
            "john@example.com", "+1234567890");

        // Act
        var result = await service.UpdateUserAsync(userId, request, CancellationToken.None);

        // Assert
        result.UserId.Should().Be(userId);
        result.Status.Should().Be("Success");
        result.Message.Should().Be("User updated successfully");
    }

    [Fact]
    public async Task UpdateUserAsync_WithHttpError_ShouldReturnError()
    {
        // Arrange
        var userId = "user-123";
        var mockHandler = new MockHttpMessageHandler();
        mockHandler.SetupResponse($"https://api.sand.platform.nymcard.com/v1/users/{userId}", 
            HttpStatusCode.NotFound);
        
        var httpClient = new HttpClient(mockHandler) 
        { 
            BaseAddress = new Uri("https://api.sand.platform.nymcard.com") 
        };
        
        var logger = new Mock<ILogger<NymCardService>>();

        var service = new NymCardService(httpClient, logger.Object, Mock.Of<ICorrelationIdService>());
        
        var request = new NymCardUpdateUserRequest(
            "john@example.com", "+1234567890");

        // Act
        var result = await service.UpdateUserAsync(userId, request, CancellationToken.None);

        // Assert
        result.UserId.Should().Be(userId);
        result.Status.Should().Be("Error");
        result.Message.Should().Contain("External service unavailable");
    }
}
