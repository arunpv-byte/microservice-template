using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using microservice_template.Infrastructure.ExternalServices.Abstractions;

namespace microservice_template.UnitTests.Infrastructure;

public sealed class AuthenticationProviderTests
{
    [Fact]
    public async Task ApiKeyAuthProvider_ShouldReturnCorrectHeader()
    {
        // Arrange
        var provider = new ApiKeyAuthProvider("test-key", "X-Custom-Key");

        // Act
        var result = await provider.GetAuthenticationHeaderAsync();

        // Assert
        result.Should().Be("X-Custom-Key:test-key");
    }

    [Fact]
    public async Task BearerTokenAuthProvider_ShouldReturnCorrectHeader()
    {
        // Arrange
        var provider = new BearerTokenAuthProvider("test-token");

        // Act
        var result = await provider.GetAuthenticationHeaderAsync();

        // Assert
        result.Should().Be("Bearer test-token");
    }

    [Fact]
    public async Task BasicAuthProvider_ShouldReturnCorrectHeader()
    {
        // Arrange
        var provider = new BasicAuthProvider("user", "pass");

        // Act
        var result = await provider.GetAuthenticationHeaderAsync();

        // Assert
        result.Should().StartWith("Authorization:Basic ");
        var base64 = result.Split(':')[1].Replace("Basic ", "");
        var decoded = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(base64));
        decoded.Should().Be("user:pass");
    }

    [Fact]
    public void OAuthTokenProvider_ClientCredentials_ShouldReturnCachedToken()
    {
        // Arrange
        var httpClient = new HttpClient();
        var tokenCache = new Mock<ITokenCache>();
        var provider = new OAuthTokenProvider(httpClient, tokenCache.Object, "https://test.com/token", "client", "secret");

        // Act & Assert
        provider.Should().NotBeNull();
    }

    [Fact]
    public void OAuthTokenProvider_Password_ShouldReturnCachedToken()
    {
        // Arrange
        var httpClient = new HttpClient();
        var tokenCache = new Mock<ITokenCache>();
        var provider = new OAuthTokenProvider(httpClient, tokenCache.Object, "https://test.com/token", "client", "secret", "user", "pass");

        // Act & Assert
        provider.Should().NotBeNull();
    }
}