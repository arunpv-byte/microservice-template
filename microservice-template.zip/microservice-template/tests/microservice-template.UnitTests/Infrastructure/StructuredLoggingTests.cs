using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Moq;
using microservice_template.Infrastructure.Services;

namespace microservice_template.UnitTests.Infrastructure;

public sealed class StructuredLoggingTests
{
    [Fact]
    public void CorrelationIdService_GetCorrelationId_ShouldReturnIdFromHttpContext()
    {
        // Arrange
        var httpContext = new DefaultHttpContext();
        var correlationId = Guid.NewGuid().ToString();
        httpContext.Items["CorrelationId"] = correlationId;

        var mockAccessor = new Mock<IHttpContextAccessor>();
        mockAccessor.Setup(x => x.HttpContext).Returns(httpContext);

        var service = new CorrelationIdService(mockAccessor.Object);

        // Act
        var result = service.GetCorrelationId();

        // Assert
        result.Should().Be(correlationId);
    }

    [Fact]
    public void CorrelationIdService_GetCorrelationId_WithoutHttpContext_ShouldReturnNewGuid()
    {
        // Arrange
        var mockAccessor = new Mock<IHttpContextAccessor>();
        mockAccessor.Setup(x => x.HttpContext).Returns((HttpContext?)null);

        var service = new CorrelationIdService(mockAccessor.Object);

        // Act
        var result = service.GetCorrelationId();

        // Assert
        result.Should().NotBeNullOrEmpty();
        Guid.TryParse(result, out _).Should().BeTrue();
    }

    [Fact]
    public void CorrelationIdService_SetCorrelationId_ShouldSetInHttpContext()
    {
        // Arrange
        var httpContext = new DefaultHttpContext();
        var correlationId = Guid.NewGuid().ToString();

        var mockAccessor = new Mock<IHttpContextAccessor>();
        mockAccessor.Setup(x => x.HttpContext).Returns(httpContext);

        var service = new CorrelationIdService(mockAccessor.Object);

        // Act
        service.SetCorrelationId(correlationId);

        // Assert
        httpContext.Items["CorrelationId"].Should().Be(correlationId);
    }
}