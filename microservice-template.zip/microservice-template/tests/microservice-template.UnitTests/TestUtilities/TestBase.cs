using Microsoft.Extensions.Logging;
using Moq;

namespace microservice_template.UnitTests.TestUtilities;

public abstract class TestBase<T> where T : class
{
    protected Mock<ILogger<T>> LoggerMock { get; }

    protected TestBase()
    {
        LoggerMock = new Mock<ILogger<T>>();
    }

    protected void VerifyLoggerCalled(LogLevel logLevel, Times times)
    {
        LoggerMock.Verify(
            x => x.Log(
                logLevel,
                It.IsAny<EventId>(),
                It.IsAny<It.IsAnyType>(),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            times);
    }
}
