using System.Net;
using System.Text.Json;

namespace microservice_template.UnitTests.TestUtilities;

public sealed class MockHttpMessageHandler : HttpMessageHandler
{
    private readonly Dictionary<string, (HttpStatusCode StatusCode, string Content)> _responses = new();
    private readonly List<HttpRequestMessage> _requests = new();

    public void SetupResponse(string requestUri, HttpStatusCode statusCode, object? content = null)
    {
        var json = content != null ? JsonSerializer.Serialize(content) : string.Empty;
        _responses[requestUri] = (statusCode, json);
    }

    public void VerifyNoRequests()
    {
        if (_requests.Count > 0)
            throw new InvalidOperationException($"Expected no HTTP requests, but {_requests.Count} were made.");
    }

    public void VerifyRequest(string expectedUri, HttpMethod expectedMethod)
    {
        var matchingRequest = _requests.FirstOrDefault(r => 
            r.RequestUri?.ToString() == expectedUri && r.Method == expectedMethod);
        
        if (matchingRequest == null)
            throw new InvalidOperationException($"Expected request to {expectedMethod} {expectedUri} was not made.");
    }

    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        _requests.Add(request);
        
        var uri = request.RequestUri?.ToString() ?? string.Empty;
        
        if (_responses.TryGetValue(uri, out var response))
        {
            return Task.FromResult(new HttpResponseMessage(response.StatusCode)
            {
                Content = new StringContent(response.Content)
            });
        }

        return Task.FromResult(new HttpResponseMessage(HttpStatusCode.NotFound));
    }
}