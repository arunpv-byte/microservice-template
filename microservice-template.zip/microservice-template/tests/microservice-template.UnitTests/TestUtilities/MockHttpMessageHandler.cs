using System.Net;
using System.Text.Json;

namespace microservice_template.UnitTests.TestUtilities;

public sealed class MockHttpMessageHandler : HttpMessageHandler
{
    private readonly Dictionary<string, (HttpStatusCode StatusCode, string Content)> _responses = new();

    public void SetupResponse(string requestUri, HttpStatusCode statusCode, object? content = null)
    {
        var json = content != null ? JsonSerializer.Serialize(content) : string.Empty;
        _responses[requestUri] = (statusCode, json);
    }

    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var uri = request.RequestUri?.ToString() ?? string.Empty;
        
        if (_responses.TryGetValue(uri, out var response))
        {
            return Task.FromResult(new HttpResponseMessage(response.StatusCode)
            {
                Content = new StringContent(response.Content)
            });
        }

        return Task.FromResult(new HttpResponseMessage(HttpStatusCode.NotFound));
    }
}