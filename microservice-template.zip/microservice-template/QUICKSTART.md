# Quick Start Guide

## Prerequisites

- .NET 8 SDK
- SQL Server (local or Docker)
- Docker Desktop (optional)
- Redis (optional, for distributed caching)

## Option 1: Run with Docker Compose (Recommended)

```bash
docker-compose up -d
```

The API will be available at: `http://localhost:5000`

## Option 2: Run Locally

### 1. Update Configuration

Edit `src/microservice-template.API/appsettings.json`:

```json
{
  "ServiceName": "microservice-template",
  "ServiceVersion": "1.0.0",
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=MicroserviceDb;User Id=sa;Password=<YourPassword>;TrustServerCertificate=True;",
    "Redis": "localhost:6379"
  },
  "Caching": {
    "Type": "Memory"
  },
  "ThirdPartyServices": {
    "NymCard": {
      "BaseUrl": "https://api.sand.platform.nymcard.com",
      "AuthType": "ApiKey",
      "ApiKey": "<YourNymCardApiKey>"
    }
  }
}
```

### 2. Restore and Build

```bash
dotnet restore
dotnet build
```

### 3. Run the Application

```bash
dotnet run --project src/microservice-template.API
```

The API will be available at: `https://localhost:5001`

### 4. Access Swagger UI

Navigate to: `https://localhost:5001/swagger`

## Testing the API

### Create a Cardholder

```bash
curl -X POST https://localhost:5001/api/v1/cardholders \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <your-jwt-token>" \
  -d '{
    "firstName": "John",
    "lastName": "Doe",
    "email": "john.doe@example.com",
    "phoneNumber": "+1234567890",
    "dateOfBirth": "1990-01-01",
    "address1": "123 Main St",
    "town": "New York",
    "country": "USA",
    "postalCode": "10001",
    "username": "johndoe",
    "deviceId": "device123",
    "title": "Mr",
    "middlename": "Michael",
    "nickname": "Johnny",
    "gender": "M"
  }'
```

### Get a Cardholder

```bash
curl https://localhost:5001/api/v1/cardholders/{userId} \
  -H "Authorization: Bearer <your-jwt-token>"
```

### Get a Cardholder

```bash
curl https://localhost:5001/api/v1/cardholders/{userId} \
  -H "Authorization: Bearer <your-jwt-token>"
```

### Update a Cardholder

```bash
curl -X PUT https://localhost:5001/api/v1/cardholders/{userId} \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <your-jwt-token>" \
  -d '{
    "firstName": "Jane",
    "lastName": "Smith",
    "email": "jane.smith@example.com",
    "phoneNumber": "+1234567890",
    "address": "456 Oak Ave",
    "city": "Los Angeles",
    "country": "USA",
    "postalCode": "90210"
  }'
```

## Running Tests

### Run All Tests

```bash
dotnet test
```

### Run Unit Tests Only

```bash
dotnet test tests/microservice-template.UnitTests
```

### Run with Coverage

```bash
dotnet test /p:CollectCoverage=true
```

## Project Structure

```
microservice-template/
├── src/
│   ├── microservice-template.API          # REST API endpoints
│   ├── microservice-template.Application  # Business logic & handlers
│   ├── microservice-template.Domain       # Domain entities & rules
│   └── microservice-template.Infrastructure # Data access & external services
├── tests/
│   ├── microservice-template.UnitTests
│   └── microservice-template.IntegrationTests
├── scripts/
│   └── init-database.sql                  # Database initialization
├── Dockerfile
├── docker-compose.yml
└── README.md
```

## Key Features

✅ Clean Architecture with Vertical Slices
✅ CQRS with MediatR
✅ Dynamic Third-Party Service Authentication
✅ Factory Pattern for External Services
✅ API Versioning (Asp.Versioning)
✅ Rate Limiting (.NET 8 Built-in)
✅ Circuit Breaker (Polly)
✅ Distributed Tracing (OpenTelemetry)
✅ Caching (Redis/Memory)
✅ Event-Driven Architecture
✅ FluentValidation
✅ Global Exception Handling
✅ Structured Logging with Serilog
✅ Correlation ID Tracking
✅ JWT Bearer Authentication for Swagger
✅ Health Checks
✅ Dapper for Data Access
✅ Docker Support
✅ Comprehensive Unit Tests
✅ Swagger/OpenAPI Documentation

## Next Steps

1. **Configure Third-Party Services**: Add API keys in `appsettings.json`
2. **Customize Domain**: Modify entities in `Domain/Entities/`
3. **Add Features**: Create new features in `Application/Features/`
4. **Add External Services**: Implement new third-party integrations
5. **Add Validators**: Create validators in `Application/Validators/`
6. **Add Controllers**: Add endpoints in `API/Controllers/`
7. **Write Tests**: Add tests in `tests/microservice-template.UnitTests/`

## Troubleshooting

### Database Connection Issues

- Ensure SQL Server is running
- Verify connection string in `appsettings.json`
- Check firewall settings

### Third-Party Service Issues

- Verify API keys in `ThirdPartyServices` configuration
- Check service base URLs and endpoints
- Review authentication type (ApiKey, Bearer, Basic, OAuth2)
- Monitor logs for external service errors
- Check correlation IDs in structured logs

### Authentication Issues

- Ensure JWT token is valid and not expired
- Check Bearer token format in Authorization header
- Verify Swagger UI authentication configuration

### Port Already in Use

Change ports in `launchSettings.json` or `docker-compose.yml`

### Build Errors

```bash
dotnet clean
dotnet restore
dotnet build
```

### Logging Issues

- Check `appsettings.Logging.json` for Serilog configuration
- Verify correlation ID middleware is registered
- Monitor structured logs in JSON format
- Use correlation IDs to trace requests across services

## Support

For architecture details, see [ARCHITECTURE.md](ARCHITECTURE.md)
For full documentation, see [README.md](README.md)
For complete API reference, see [API_DOCUMENTATION.md](API_DOCUMENTATION.md)
