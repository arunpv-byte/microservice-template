# Third-Party Service Error Handling

## Overview

The microservice template includes comprehensive error handling for third-party service failures, ensuring appropriate HTTP responses and proper error logging with correlation IDs.

## Error Types Handled

### 1. Timeout Errors
- **Exception**: `ThirdPartyServiceTimeoutException`
- **HTTP Status**: 408 Request Timeout
- **Causes**: Network timeouts, slow external services
- **Response**:
```json
{
  "statusCode": 408,
  "message": "NymCard service request timed out",
  "correlationId": "12345678-1234-1234-1234-123456789012",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### 2. Service Unavailable
- **Exception**: `ThirdPartyServiceUnavailableException`
- **HTTP Status**: 503 Service Unavailable
- **Causes**: External service downtime, network issues
- **Response**:
```json
{
  "statusCode": 503,
  "message": "NymCard service is currently unavailable",
  "correlationId": "12345678-1234-1234-1234-123456789012",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### 3. Authentication Failures
- **Exception**: `ThirdPartyServiceException` (401)
- **HTTP Status**: 401 Unauthorized
- **Causes**: Invalid API keys, expired tokens
- **Response**:
```json
{
  "statusCode": 401,
  "message": "Authentication with external service failed",
  "correlationId": "12345678-1234-1234-1234-123456789012",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### 4. Rate Limiting
- **Exception**: `ThirdPartyServiceException` (429)
- **HTTP Status**: 429 Too Many Requests
- **Causes**: Exceeded external service rate limits
- **Response**:
```json
{
  "statusCode": 429,
  "message": "Rate limit exceeded for external service",
  "correlationId": "12345678-1234-1234-1234-123456789012",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### 5. Validation Errors
- **Exception**: `ThirdPartyServiceException` (400)
- **HTTP Status**: 400 Bad Request
- **Causes**: Invalid request data sent to external service
- **Response**:
```json
{
  "statusCode": 400,
  "message": "Invalid email format",
  "correlationId": "12345678-1234-1234-1234-123456789012",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### 6. General Service Errors
- **Exception**: `ThirdPartyServiceException` (other status codes)
- **HTTP Status**: 502 Bad Gateway
- **Causes**: Internal errors in external services
- **Response**:
```json
{
  "statusCode": 502,
  "message": "Error communicating with NymCard service",
  "correlationId": "12345678-1234-1234-1234-123456789012",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

## Implementation Details

### ResilientHttpClient Enhancement

The `ResilientHttpClient` base class handles:
- **Timeout Detection**: Catches `TaskCanceledException` with timeout
- **Network Issues**: Catches `HttpRequestException`
- **HTTP Status Mapping**: Maps external service status codes to appropriate exceptions
- **Error Message Extraction**: Parses JSON error responses from external services
- **Correlation ID Logging**: Includes correlation IDs in all log entries

### Exception Hierarchy

```
Exception
├── ThirdPartyServiceException (base)
│   ├── ThirdPartyServiceTimeoutException
│   └── ThirdPartyServiceUnavailableException
```

### Global Exception Middleware

The `GlobalExceptionMiddleware` maps exceptions to HTTP responses:

```csharp
ThirdPartyServiceTimeoutException => 408 Request Timeout
ThirdPartyServiceUnavailableException => 503 Service Unavailable
ThirdPartyServiceException (400) => 400 Bad Request
ThirdPartyServiceException (401) => 401 Unauthorized
ThirdPartyServiceException (429) => 429 Too Many Requests
ThirdPartyServiceException (other) => 502 Bad Gateway
```

## Circuit Breaker Integration

The solution includes Polly circuit breaker patterns:
- **Failure Threshold**: 3 consecutive failures
- **Circuit Open Duration**: 30 seconds
- **Retry Policy**: Exponential backoff (2, 4, 8 seconds)
- **Transient Fault Handling**: Automatic retry for network issues

## Monitoring and Logging

### Structured Logging
All third-party service errors are logged with:
- **Correlation ID**: For request tracing
- **Service Name**: Which external service failed
- **HTTP Status Code**: Original error status
- **Error Message**: Extracted from service response
- **Request Details**: Endpoint and method

### Example Log Entry
```json
{
  "@timestamp": "2024-01-15T10:30:00.000Z",
  "@level": "Error",
  "@message": "POST /v1/users failed with status 400. Response: {\"message\":\"Invalid email format\"}",
  "CorrelationId": "12345678-1234-1234-1234-123456789012",
  "Application": "microservice-template",
  "ServiceName": "NymCard",
  "StatusCode": 400,
  "Endpoint": "/v1/users",
  "Method": "POST"
}
```

## Best Practices

### 1. Graceful Degradation
- Return meaningful error messages to clients
- Maintain service availability despite external failures
- Use circuit breakers to prevent cascade failures

### 2. Error Transparency
- Map external service errors to appropriate HTTP status codes
- Preserve correlation IDs for troubleshooting
- Log sufficient context for debugging

### 3. Client Communication
- Provide clear error messages without exposing internal details
- Include correlation IDs in responses for support requests
- Use consistent error response format

### 4. Monitoring
- Track external service failure rates
- Monitor circuit breaker state changes
- Alert on authentication failures
- Dashboard for service health metrics

## Configuration

### Timeout Settings
```json
{
  "HttpClientSettings": {
    "Timeout": "00:00:30",
    "RetryCount": 3,
    "CircuitBreakerFailureThreshold": 3,
    "CircuitBreakerOpenDuration": "00:00:30"
  }
}
```

### Logging Configuration
```json
{
  "Serilog": {
    "MinimumLevel": {
      "Override": {
        "microservice_template.Infrastructure.ExternalServices": "Information"
      }
    }
  }
}
```

This comprehensive error handling ensures that third-party service failures are properly managed, logged, and communicated to clients with appropriate HTTP status codes and meaningful error messages.