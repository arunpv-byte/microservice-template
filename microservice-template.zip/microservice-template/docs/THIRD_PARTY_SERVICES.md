# Adding New Third-Party Services

This template provides a generic, reusable infrastructure for integrating with any third-party API using dynamic authentication. Here's how to add a new service:

## Example: Adding a Payment Service

### 1. Define Service Interface (Application Layer)

```csharp
// Application/Interfaces/IPaymentService.cs
public interface IPaymentService
{
    Task<PaymentResponse> ProcessPaymentAsync(PaymentRequest request, CancellationToken cancellationToken);
}

public record PaymentRequest(decimal Amount, string Currency, string CardToken);
public record PaymentResponse(string TransactionId, string Status, string Message);
```

### 2. Implement Service (Infrastructure Layer)

```csharp
// Infrastructure/ExternalServices/Clients/PaymentService.cs
public sealed class PaymentService : ResilientHttpClient, IPaymentService
{
    public PaymentService(HttpClient httpClient, ILogger<PaymentService> logger)
        : base(httpClient, logger)
    {
    }

    public async Task<PaymentResponse> ProcessPaymentAsync(PaymentRequest request, CancellationToken cancellationToken)
    {
        var payload = new { amount = request.Amount, currency = request.Currency, card_token = request.CardToken };
        var response = await PostAsync<PaymentApiResponse>("/v1/payments", payload, cancellationToken);
        
        return new PaymentResponse(response.Id, response.Status, "Payment processed");
    }
}
```

### 3. Register Service (DependencyInjection.cs)

```csharp
private static IServiceCollection AddPaymentService(this IServiceCollection services, IConfiguration configuration)
{
    services.AddHttpClient<IPaymentService, PaymentService>(client =>
    {
        ConfigureServiceAuth(client, configuration, "Payment");
    });
    
    return services;
}
```

### 4. Add Configuration

```json
{
  "ThirdPartyServices": {
    "Payment": {
      "BaseUrl": "https://api.payment-provider.com",
      "AuthType": "Bearer",
      "Token": "your-bearer-token"
    }
  }
}
```

### 5. Use in Handlers

```csharp
public class ProcessPaymentHandler : IRequestHandler<ProcessPaymentCommand, ProcessPaymentResponse>
{
    private readonly IThirdPartyServiceFactory _serviceFactory;

    public ProcessPaymentHandler(IThirdPartyServiceFactory serviceFactory)
    {
        _serviceFactory = serviceFactory;
    }

    public async Task<ProcessPaymentResponse> Handle(ProcessPaymentCommand request, CancellationToken cancellationToken)
    {
        var paymentService = _serviceFactory.GetService<IPaymentService>();
        var result = await paymentService.ProcessPaymentAsync(new PaymentRequest(request.Amount, request.Currency, request.CardToken), cancellationToken);
        
        return new ProcessPaymentResponse(result.TransactionId, result.Status);
    }
}
```

## Available Authentication Types

### 1. API Key Authentication
```json
{
  "AuthType": "ApiKey",
  "ApiKey": "your-api-key"
}
```
Adds `X-API-Key` header to requests.

### 2. Bearer Token Authentication
```json
{
  "AuthType": "Bearer",
  "Token": "your-bearer-token"
}
```
Adds `Authorization: Bearer {token}` header to requests.

### 3. Basic Authentication
```json
{
  "AuthType": "Basic",
  "Username": "your-username",
  "Password": "your-password"
}
```
Adds `Authorization: Basic {credentials}` header to requests.

## Available HTTP Methods

- **GetAsync<T>**: GET requests
- **PostAsync<T>**: POST requests  
- **PutAsync<T>**: PUT requests

## Built-in Features

✅ **Dynamic Authentication**: Configuration-driven auth selection
✅ **Factory Pattern**: Centralized service resolution
✅ **Logging**: Structured logging with correlation IDs
✅ **Monitoring**: Activity tracing for observability
✅ **Error Handling**: Consistent exception handling
✅ **JSON Serialization**: Automatic camelCase conversion
✅ **Cancellation Support**: CancellationToken throughout

## Real Implementation: NymCard Service

The NymCard service demonstrates this pattern:
- Uses **ApiKey** authentication
- Implements **POST** for user creation, **PUT** for updates, **GET** for account balance
- Leverages factory pattern for service resolution
- Configured via `ThirdPartyServices:NymCard` section
- Used in CreateCardholderHandler, UpdateCardholderHandler, and GetCardBalanceHandler

## Configuration Examples

### Multiple Services
```json
{
  "ThirdPartyServices": {
    "NymCard": {
      "BaseUrl": "https://api.sand.platform.nymcard.com",
      "AuthType": "ApiKey",
      "ApiKey": "nymcard-api-key"
    },
    "Stripe": {
      "BaseUrl": "https://api.stripe.com",
      "AuthType": "Bearer",
      "Token": "stripe-secret-key"
    },
    "PayPal": {
      "BaseUrl": "https://api.paypal.com",
      "AuthType": "Basic",
      "Username": "paypal-client-id",
      "Password": "paypal-client-secret"
    }
  }
}
```

### Environment-Specific Configuration
```json
{
  "ThirdPartyServices": {
    "NymCard": {
      "BaseUrl": "https://api.sand.platform.nymcard.com",
      "AuthType": "ApiKey",
      "ApiKey": "${NYMCARD_API_KEY}"
    }
  }
}
```

## Benefits

- **No Code Changes**: Add new services via configuration only
- **Type Safety**: Strongly typed service interfaces
- **Testability**: Easy to mock via factory pattern
- **Consistency**: All services follow same patterns
- **Maintainability**: Centralized authentication logic
- **Scalability**: Easy to add unlimited third-party services