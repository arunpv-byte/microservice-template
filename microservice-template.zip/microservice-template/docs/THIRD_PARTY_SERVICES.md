# Adding New Third-Party Services

This template provides a generic, reusable infrastructure for integrating with any third-party API using dynamic authentication. Here's how to add a new service:

## Example: Adding a Payment Service

### 1. Define Service Interface (Application Layer)

```csharp
// Application/Interfaces/IPaymentService.cs
public interface IPaymentService
{
    Task<PaymentResponse> ProcessPaymentAsync(PaymentRequest request, CancellationToken cancellationToken);
}

public record PaymentRequest(decimal Amount, string Currency, string CardToken);
public record PaymentResponse(string TransactionId, string Status, string Message);
```

### 2. Implement Service (Infrastructure Layer)

```csharp
// Infrastructure/ExternalServices/Clients/PaymentService.cs
public sealed class PaymentService : ResilientHttpClient, IPaymentService
{
    public PaymentService(HttpClient httpClient, ILogger<PaymentService> logger, ICorrelationIdService correlationIdService)
        : base(httpClient, logger, correlationIdService)
    {
    }

    public async Task<PaymentResponse> ProcessPaymentAsync(PaymentRequest request, CancellationToken cancellationToken)
    {
        var payload = new { amount = request.Amount, currency = request.Currency, card_token = request.CardToken };
        var response = await PostAsync<PaymentApiResponse>("/v1/payments", payload, cancellationToken);
        
        return new PaymentResponse(response.Id, response.Status, "Payment processed");
    }
}
```

### 3. Register Service (DependencyInjection.cs)

```csharp
private static IServiceCollection AddPaymentService(this IServiceCollection services, IConfiguration configuration)
{
    services.AddHttpClient<IPaymentService, PaymentService>(client =>
    {
        ConfigureServiceAuth(client, configuration, "Payment");
    });
    
    return services;
}
```

### 4. Add Configuration

```json
{
  "ThirdPartyServices": {
    "Payment": {
      "BaseUrl": "https://api.payment-provider.com",
      "AuthType": "Bearer",
      "Token": "<PaymentServiceToken>"
    }
  }
}
```

### 5. Use in Handlers

```csharp
public class ProcessPaymentHandler : IRequestHandler<ProcessPaymentCommand, ProcessPaymentResponse>
{
    private readonly IThirdPartyServiceFactory _serviceFactory;

    public ProcessPaymentHandler(IThirdPartyServiceFactory serviceFactory)
    {
        _serviceFactory = serviceFactory;
    }

    public async Task<ProcessPaymentResponse> Handle(ProcessPaymentCommand request, CancellationToken cancellationToken)
    {
        var paymentService = _serviceFactory.GetService<IPaymentService>();
        var result = await paymentService.ProcessPaymentAsync(new PaymentRequest(request.Amount, request.Currency, request.CardToken), cancellationToken);
        
        return new ProcessPaymentResponse(result.TransactionId, result.Status);
    }
}
```

## Available Authentication Types

### 1. API Key Authentication
```json
{
  "AuthType": "ApiKey",
  "ApiKey": "<YourApiKey>"
}
```
Adds `X-API-Key` header to requests.

### 2. Bearer Token Authentication
```json
{
  "AuthType": "Bearer",
  "Token": "<YourBearerToken>"
}
```
Adds `Authorization: Bearer {token}` header to requests.

### 3. Basic Authentication
```json
{
  "AuthType": "Basic",
  "Username": "<YourUsername>",
  "Password": "<YourPassword>"
}
```
Adds `Authorization: Basic {credentials}` header to requests.

### 4. OAuth 2.0 Client Credentials
```json
{
  "AuthType": "oauth_client_credentials",
  "TokenUrl": "https://auth.service.com/token",
  "ClientId": "<YourClientId>",
  "ClientSecret": "<YourClientSecret>",
  "Scope": "api:read api:write"
}
```
Automatically obtains and refreshes OAuth 2.0 access tokens.

### 5. OAuth 2.0 Password Grant
```json
{
  "AuthType": "oauth_password",
  "TokenUrl": "https://auth.service.com/token",
  "ClientId": "<YourClientId>",
  "ClientSecret": "<YourClientSecret>",
  "Username": "<ServiceUsername>",
  "Password": "<ServicePassword>",
  "Scope": "full_access"
}
```
Uses resource owner password credentials flow for legacy systems.

## Available HTTP Methods

- **GetAsync<T>**: GET requests
- **PostAsync<T>**: POST requests  
- **PutAsync<T>**: PUT requests

## Built-in Features

✅ **Dynamic Authentication**: Configuration-driven auth selection
✅ **Factory Pattern**: Centralized service resolution
✅ **Structured Logging**: JSON-formatted logs with correlation IDs
✅ **Distributed Tracing**: Activity tracing for observability
✅ **Error Handling**: Consistent exception handling
✅ **JSON Serialization**: Automatic camelCase conversion
✅ **Cancellation Support**: CancellationToken throughout
✅ **OAuth 2.0 Support**: Automatic token management and refresh
✅ **Circuit Breaker**: Polly-based resilience patterns
✅ **Correlation ID Tracking**: Request tracing across services

## Real Implementation: NymCard Service

The NymCard service demonstrates this pattern:
- Uses **ApiKey** authentication
- Implements **POST** for user creation, **PUT** for updates, **GET** for account balance
- Leverages factory pattern for service resolution
- Configured via `ThirdPartyServices:NymCard` section
- Used in CreateCardholderHandler, UpdateCardholderHandler, and GetCardBalanceHandler
- Includes structured logging with correlation IDs

## Configuration Examples

### Multiple Services
```json
{
  "ThirdPartyServices": {
    "NymCard": {
      "BaseUrl": "https://api.sand.platform.nymcard.com",
      "AuthType": "ApiKey",
      "ApiKey": "<NymCardApiKey>"
    },
    "Stripe": {
      "BaseUrl": "https://api.stripe.com",
      "AuthType": "Bearer",
      "Token": "<StripeSecretKey>"
    },
    "PayPal": {
      "BaseUrl": "https://api.paypal.com",
      "AuthType": "Basic",
      "Username": "<PayPalClientId>",
      "Password": "<PayPalClientSecret>"
    },
    "OAuth2Service": {
      "BaseUrl": "https://api.oauth2service.com",
      "AuthType": "oauth_client_credentials",
      "TokenUrl": "https://auth.oauth2service.com/token",
      "ClientId": "<OAuth2ClientId>",
      "ClientSecret": "<OAuth2ClientSecret>",
      "Scope": "api:read api:write"
    }
  }
}
```

### Environment-Specific Configuration
```json
{
  "ThirdPartyServices": {
    "NymCard": {
      "BaseUrl": "https://api.sand.platform.nymcard.com",
      "AuthType": "ApiKey",
      "ApiKey": "${NYMCARD_API_KEY}"
    }
  }
}
```

### AWS Secrets Manager Integration
```json
{
  "ThirdPartyServices": {
    "NymCard": {
      "BaseUrl": "https://api.sand.platform.nymcard.com",
      "AuthType": "ApiKey",
      "ApiKey": "{{resolve:secretsmanager:microservice-template/nymcard:SecretString:ApiKey}}"
    }
  }
}
```

## Benefits

- **No Code Changes**: Add new services via configuration only
- **Type Safety**: Strongly typed service interfaces
- **Testability**: Easy to mock via factory pattern
- **Consistency**: All services follow same patterns
- **Maintainability**: Centralized authentication logic
- **Scalability**: Easy to add unlimited third-party services
- **Security**: Sensitive data masked in logs and documentation
- **Observability**: Correlation ID tracking and structured logging
- **Resilience**: Built-in circuit breaker and retry policies
- **OAuth 2.0 Support**: Automatic token management for modern APIs