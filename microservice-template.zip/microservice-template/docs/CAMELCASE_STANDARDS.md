# CamelCase Standards

This project follows **camelCase** naming convention for all JSON serialization and API communication.

## Configuration

### Global API Configuration
```csharp
// Program.cs
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
    });
```

### HTTP Client Configuration
```csharp
// ResilientHttpClient.cs
var json = JsonSerializer.Serialize(request, new JsonSerializerOptions 
{ 
    PropertyNamingPolicy = JsonNamingPolicy.CamelCase 
});
```

## Examples

### API Requests/Responses
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "emailAddress": "john@example.com",
  "phoneNumber": "+1234567890",
  "dateOfBirth": "1990-01-01"
}
```

### Third-Party API Calls
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phoneNumber": "+1234567890",
  "dateOfBirth": "1990-01-01",
  "address": {
    "street": "123 Main St",
    "city": "City",
    "country": "Country",
    "postalCode": "12345"
  }
}
```

## Benefits

- **Consistency**: All JSON follows JavaScript/web standards
- **Interoperability**: Better integration with frontend applications
- **Standards Compliance**: Follows REST API best practices
- **Automatic**: No manual property naming required

## Implementation

The camelCase standard is enforced at:
- **API Level**: All controller responses
- **HTTP Client Level**: All external API calls
- **Serialization Level**: All JSON operations

This ensures consistent naming across the entire application stack.