# New Relic Integration with OpenTelemetry

## Overview

This microservice template includes comprehensive New Relic integration using OpenTelemetry Protocol (OTLP) for distributed tracing, metrics, and observability.

## Configuration

### Environment Variables

For production environments, configure New Relic via environment variables:

```bash
# New Relic Configuration
NEW_RELIC__APIKEY=<your-new-relic-ingest-api-key>
NEW_RELIC__ENDPOINT=https://otlp.nr-data.net:4317

# Service Information
SERVICENAME=microservice-template
SERVICEVERSION=1.0.0
ASPNETCORE_ENVIRONMENT=Production
```

### appsettings.json

For development environments:

```json
{
  "ServiceName": "microservice-template",
  "ServiceVersion": "1.0.0",
  "NewRelic": {
    "ApiKey": "<your-new-relic-ingest-api-key>",
    "Endpoint": "https://otlp.nr-data.net:4317"
  }
}
```

### AWS Secrets Manager

For production deployments, store the New Relic API key in AWS Secrets Manager:

```json
{
  "NewRelic:ApiKey": "<your-new-relic-ingest-api-key>"
}
```

## Features

### Distributed Tracing

**Automatic Instrumentation:**
- ASP.NET Core requests and responses
- HTTP client calls (including third-party services)
- SQL database queries
- Exception tracking
- Custom spans with correlation IDs

**Trace Attributes:**
- Service name and version
- Environment (Development, Staging, Production)
- Machine/container instance ID
- Request correlation IDs
- Custom business context

### Metrics Collection

**Runtime Metrics:**
- CPU usage
- Memory consumption
- Garbage collection statistics
- Thread pool metrics

**Application Metrics:**
- HTTP request duration and count
- HTTP client request metrics
- Database query performance
- Custom business metrics

**Infrastructure Metrics:**
- Process-level metrics
- System resource utilization

### Error Tracking

**Exception Monitoring:**
- Automatic exception capture in traces
- Stack trace information
- Error rate metrics
- Failed request tracking

## New Relic Setup

### 1. Create New Relic Account

1. Sign up at [newrelic.com](https://newrelic.com)
2. Navigate to **API Keys** in account settings
3. Create an **Ingest - License** key
4. Copy the API key for configuration

### 2. Configure Application

**Option A: Environment Variables (Recommended for Production)**
```bash
export NEW_RELIC__APIKEY="your-api-key-here"
export SERVICENAME="microservice-template"
export SERVICEVERSION="1.0.0"
```

**Option B: Configuration File (Development)**
```json
{
  "NewRelic": {
    "ApiKey": "your-api-key-here"
  }
}
```

### 3. Deploy and Verify

1. Deploy the application with New Relic configuration
2. Generate some traffic to the API endpoints
3. Check New Relic dashboard for incoming data
4. Verify traces appear in **APM & Services** section

## New Relic Dashboard Features

### APM Overview
- Service map showing dependencies
- Response time and throughput
- Error rate and Apdex score
- Database query performance

### Distributed Tracing
- End-to-end request traces
- Service dependency visualization
- Performance bottleneck identification
- Error propagation tracking

### Infrastructure Monitoring
- Host and container metrics
- Resource utilization trends
- Alert configuration
- Custom dashboards

### Alerts and Notifications
- Response time thresholds
- Error rate alerts
- Infrastructure alerts
- Custom metric alerts

## Custom Instrumentation

### Adding Custom Spans

```csharp
using System.Diagnostics;

public class CustomService
{
    private static readonly ActivitySource ActivitySource = new("microservice-template.CustomService");

    public async Task ProcessBusinessLogic()
    {
        using var activity = ActivitySource.StartActivity("ProcessBusinessLogic");
        activity?.SetTag("business.operation", "cardholder-creation");
        activity?.SetTag("correlation.id", correlationId);
        
        try
        {
            // Business logic here
            activity?.SetStatus(ActivityStatusCode.Ok);
        }
        catch (Exception ex)
        {
            activity?.SetStatus(ActivityStatusCode.Error, ex.Message);
            throw;
        }
    }
}
```

### Custom Metrics

```csharp
using System.Diagnostics.Metrics;

public class BusinessMetrics
{
    private static readonly Meter Meter = new("microservice-template.business");
    private static readonly Counter<int> CardholderCreated = Meter.CreateCounter<int>("cardholder.created");
    private static readonly Histogram<double> ProcessingTime = Meter.CreateHistogram<double>("processing.duration");

    public void RecordCardholderCreated()
    {
        CardholderCreated.Add(1, new KeyValuePair<string, object?>("operation", "create"));
    }

    public void RecordProcessingTime(double duration)
    {
        ProcessingTime.Record(duration, new KeyValuePair<string, object?>("operation", "cardholder-creation"));
    }
}
```

## Troubleshooting

### Common Issues

**1. No Data in New Relic**
- Verify API key is correct
- Check network connectivity to New Relic endpoint
- Ensure OTLP exporter is configured properly
- Check application logs for export errors

**2. Missing Traces**
- Verify OpenTelemetry instrumentation is enabled
- Check trace sampling configuration
- Ensure ActivitySource names match
- Verify correlation ID propagation

**3. Performance Impact**
- Monitor application performance after enabling telemetry
- Adjust sampling rates if needed
- Use batch export for high-throughput scenarios
- Consider async export options

### Debugging

**Enable Detailed Logging:**
```json
{
  "Logging": {
    "LogLevel": {
      "OpenTelemetry": "Debug",
      "System.Net.Http": "Information"
    }
  }
}
```

**Console Exporter for Development:**
The template includes console exporter for local debugging. Traces and metrics will be visible in application logs.

## Production Considerations

### Security
- Store New Relic API keys in secure configuration (AWS Secrets Manager)
- Use IAM roles instead of hardcoded credentials
- Implement proper network security for OTLP endpoint

### Performance
- Configure appropriate sampling rates for high-traffic applications
- Use batch export to reduce network overhead
- Monitor telemetry export performance impact

### Monitoring
- Set up alerts for telemetry export failures
- Monitor New Relic data ingestion costs
- Implement fallback mechanisms for telemetry failures

## Integration Benefits

✅ **Complete Observability**: End-to-end visibility into application performance
✅ **Automatic Instrumentation**: Zero-code instrumentation for common frameworks
✅ **Custom Business Metrics**: Track domain-specific KPIs and business events
✅ **Error Tracking**: Comprehensive exception monitoring and alerting
✅ **Performance Optimization**: Identify bottlenecks and optimization opportunities
✅ **Dependency Mapping**: Visualize service dependencies and communication patterns
✅ **Production Ready**: Enterprise-grade monitoring and alerting capabilities

This integration provides comprehensive observability for the microservice template, enabling proactive monitoring, performance optimization, and rapid issue resolution in production environments.