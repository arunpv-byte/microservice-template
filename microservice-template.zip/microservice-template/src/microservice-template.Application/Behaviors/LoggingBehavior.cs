using MediatR;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using microservice_template.Application.Interfaces;

namespace microservice_template.Application.Behaviors;

public sealed class LoggingBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
    where TRequest : IRequest<TResponse>
{
    private readonly ILogger<LoggingBehavior<TRequest, TResponse>> _logger;
    private readonly ICorrelationIdService _correlationIdService;

    public LoggingBehavior(ILogger<LoggingBehavior<TRequest, TResponse>> logger, ICorrelationIdService correlationIdService)
    {
        _logger = logger;
        _correlationIdService = correlationIdService;
    }

    public async Task<TResponse> Handle(TRequest request, RequestHandlerDelegate<TResponse> next, CancellationToken cancellationToken)
    {
        var requestName = typeof(TRequest).Name;
        var correlationId = _correlationIdService.GetCorrelationId();
        
        _logger.LogInformation("Handling {RequestName} with CorrelationId {CorrelationId}", requestName, correlationId);
        
        var stopwatch = Stopwatch.StartNew();
        
        try
        {
            var response = await next();
            
            stopwatch.Stop();
            
            _logger.LogInformation("Handled {RequestName} in {ElapsedMilliseconds}ms with CorrelationId {CorrelationId}", 
                requestName, stopwatch.ElapsedMilliseconds, correlationId);
            
            return response;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            
            _logger.LogError(ex, "Error handling {RequestName} after {ElapsedMilliseconds}ms with CorrelationId {CorrelationId}", 
                requestName, stopwatch.ElapsedMilliseconds, correlationId);
            
            throw;
        }
    }
}
