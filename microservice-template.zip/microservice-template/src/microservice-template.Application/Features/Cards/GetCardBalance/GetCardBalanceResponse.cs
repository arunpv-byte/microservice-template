namespace microservice_template.Application.Features.Cards.GetCardBalance;

public sealed record GetCardBalanceResponse(
    string AccountId,
    decimal AvailableBalance,
    string Currency
);