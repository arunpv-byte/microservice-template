using MediatR;
using microservice_template.Application.Interfaces;
using microservice_template.Domain.Exceptions;

namespace microservice_template.Application.Features.Cards.GetCardBalance;

public sealed class GetCardBalanceHandler : IRequestHandler<GetCardBalanceQuery, GetCardBalanceResponse>
{
    private readonly IThirdPartyServiceFactory _serviceFactory;

    public GetCardBalanceHandler(IThirdPartyServiceFactory serviceFactory)
    {
        _serviceFactory = serviceFactory;
    }

    public async Task<GetCardBalanceResponse> Handle(GetCardBalanceQuery request, CancellationToken cancellationToken)
    {
        var nymCardService = _serviceFactory.GetService<INymCardService>();
        var accountResponse = await nymCardService.GetAccountAsync(request.AccountId, cancellationToken);

        if (accountResponse is null)
        {
            throw new NotFoundException($"Account with ID '{request.AccountId}' was not found.");
        }

        return new GetCardBalanceResponse(
            accountResponse.AccountId,
            accountResponse.AvailableBalance,
            accountResponse.Currency
        );
    }
}