using MediatR;

namespace microservice_template.Application.Features.Cards.GetCardBalance;

public sealed record GetCardBalanceQuery(string AccountId) : IRequest<GetCardBalanceResponse>;