using MediatR;

namespace microservice_template.Application.Features.Cardholders.UpdateCardholder;

public sealed record UpdateCardholderCommand(
    string cardholderReference,    
    string emailAddress,
    string phoneNumber
) : IRequest<UpdateCardholderResponse>;
