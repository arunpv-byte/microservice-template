using MediatR;

namespace microservice_template.Application.Features.Cardholders.UpdateCardholder;

public sealed record UpdateCardholderCommand(
    string userId,
    string firstName,
    string lastName,
    string email,
    string phoneNumber,
    string address,
    string city,
    string country,
    string postalCode
) : IRequest<UpdateCardholderResponse>;