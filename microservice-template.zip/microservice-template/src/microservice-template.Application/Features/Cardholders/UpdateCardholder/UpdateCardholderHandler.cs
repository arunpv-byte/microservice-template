using MediatR;
using Microsoft.Extensions.Logging;
using microservice_template.Application.Interfaces;

namespace microservice_template.Application.Features.Cardholders.UpdateCardholder;

public sealed class UpdateCardholderHandler : IRequestHandler<UpdateCardholderCommand, UpdateCardholderResponse>
{
    private readonly IThirdPartyServiceFactory _serviceFactory;
    private readonly ICardholderRepository _cardholderRepository;
    private readonly ILogger<UpdateCardholderHandler> _logger;

    public UpdateCardholderHandler(IThirdPartyServiceFactory serviceFactory, ICardholderRepository cardholderRepository, ILogger<UpdateCardholderHandler> logger)
    {
        _serviceFactory = serviceFactory;
        _cardholderRepository = cardholderRepository;
        _logger = logger;
    }

    public async Task<UpdateCardholderResponse> Handle(UpdateCardholderCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Updating cardholder: {UserId}", request.userId);

        var nymCardService = _serviceFactory.GetService<INymCardService>();
        var cardholder = await _cardholderRepository.GetByNymCardUserIdAsync(request.userId, cancellationToken);
        if (cardholder == null)
            throw new InvalidOperationException($"Cardholder with NymCard ID {request.userId} not found");

        var nymCardRequest = new NymCardUpdateUserRequest(
            request.firstName,
            request.lastName,
            request.email,
            request.phoneNumber,
            request.address,
            request.city,
            request.country,
            request.postalCode
        );

        var nymCardResponse = await nymCardService.UpdateUserAsync(request.userId, nymCardRequest, cancellationToken);

        cardholder.Update(
            request.firstName,
            request.lastName,
            request.email,
            request.phoneNumber,
            request.address,
            request.city,
            request.country,
            request.postalCode,
            nymCardResponse.Status
        );

        await _cardholderRepository.UpdateAsync(cardholder, cancellationToken);

        _logger.LogInformation("Cardholder updated successfully: {UserId}", request.userId);

        return new UpdateCardholderResponse(
            request.userId,
            request.firstName,
            request.lastName,
            request.email,
            nymCardResponse.Status,
            DateTime.UtcNow
        );
    }
}