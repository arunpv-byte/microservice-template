using MediatR;
using Microsoft.Extensions.Logging;
using microservice_template.Application.Interfaces;

namespace microservice_template.Application.Features.Cardholders.UpdateCardholder;

public sealed class UpdateCardholderHandler : IRequestHandler<UpdateCardholderCommand, UpdateCardholderResponse>
{
    private readonly IThirdPartyServiceFactory _serviceFactory;
    private readonly ICardholderRepository _cardholderRepository;
    private readonly ILogger<UpdateCardholderHandler> _logger;

    public UpdateCardholderHandler(IThirdPartyServiceFactory serviceFactory, ICardholderRepository cardholderRepository, ILogger<UpdateCardholderHandler> logger)
    {
        _serviceFactory = serviceFactory;
        _cardholderRepository = cardholderRepository;
        _logger = logger;
    }

    public async Task<UpdateCardholderResponse> Handle(UpdateCardholderCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Updating cardholder: {UserId}", request.cardholderReference);

        var nymCardService = _serviceFactory.GetService<INymCardService>();
        var cardholder = await _cardholderRepository.GetByNymCardUserIdAsync(request.cardholderReference, cancellationToken);
        if (cardholder == null)
            throw new InvalidOperationException($"Cardholder with NymCard ID {request.cardholderReference} not found");

        cardholder.emailAddress = string.IsNullOrEmpty(request.emailAddress) ? cardholder.emailAddress : request.emailAddress;
        cardholder.phoneNumber = string.IsNullOrEmpty(request.phoneNumber) ? cardholder.phoneNumber.Replace(@"-", "") : request.phoneNumber.Replace(@"-", "");


        var nymcardUpdateCardholderReq = new NymCardUpdateUserRequest
        (
            cardholder.emailAddress,
            cardholder.phoneNumber
        );

        var nymCardResponse = await nymCardService.UpdateUserAsync(request.cardholderReference, nymcardUpdateCardholderReq, cancellationToken);

        cardholder.Update(
            request.cardholderReference,
            cardholder.emailAddress,
            cardholder.phoneNumber
        );

        await _cardholderRepository.UpdateAsync(cardholder, cancellationToken);

        _logger.LogInformation("Cardholder updated successfully: {UserId}", request.cardholderReference);

        return new UpdateCardholderResponse(
            request.cardholderReference,
            cardholder.emailAddress,
            cardholder.phoneNumber
        );
    }
}
