namespace microservice_template.Application.Features.Cardholders.UpdateCardholder;

public sealed record UpdateCardholderResponse(
    string cardholderReference,
    string emailAddress,
    string phoneNumber
);
