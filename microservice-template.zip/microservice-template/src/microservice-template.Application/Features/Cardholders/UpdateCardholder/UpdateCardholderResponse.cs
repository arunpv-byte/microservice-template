namespace microservice_template.Application.Features.Cardholders.UpdateCardholder;

public sealed record UpdateCardholderResponse(
    string userId,
    string firstName,
    string lastName,
    string email,
    string status,
    DateTime updatedAt
);