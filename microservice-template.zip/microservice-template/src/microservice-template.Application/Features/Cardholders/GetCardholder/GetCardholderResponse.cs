namespace microservice_template.Application.Features.Cardholders.GetCardholder;

public sealed record GetCardholderResponse(
    string userId,
    string firstName,
    string lastName,
    string email,
    string phoneNumber,
    string dateOfBirth,
    string address,
    string city,
    string country,
    string postalCode,
    string status,
    DateTime createdAt,
    DateTime? updatedAt
);
