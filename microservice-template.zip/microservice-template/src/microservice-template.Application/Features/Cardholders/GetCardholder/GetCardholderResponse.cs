namespace microservice_template.Application.Features.Cardholders.GetCardholder;

public sealed record GetCardholderResponse(
    string cardholderId,
    string cardholderReference,
    string firstName,
    string lastName,
    string emailAddress,
    string phoneNumber,
    string dateOfBirth,
    string addressLine1,
    string city,
    string country,
    string postalCode
);
