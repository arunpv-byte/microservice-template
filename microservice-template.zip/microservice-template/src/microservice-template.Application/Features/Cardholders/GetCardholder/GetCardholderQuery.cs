using MediatR;

namespace microservice_template.Application.Features.Cardholders.GetCardholder;

public sealed record GetCardholderQuery(string UserId) : IRequest<GetCardholderResponse>;