using MediatR;
using microservice_template.Application.Interfaces;
using microservice_template.Domain.Exceptions;

namespace microservice_template.Application.Features.Cardholders.GetCardholder;

public sealed class GetCardholderHandler : IRequestHandler<GetCardholderQuery, GetCardholderResponse>
{
    private readonly ICardholderRepository _cardholderRepository;

    public GetCardholderHandler(ICardholderRepository cardholderRepository)
    {
        _cardholderRepository = cardholderRepository;
    }

    public async Task<GetCardholderResponse> Handle(GetCardholderQuery request, CancellationToken cancellationToken)
    {
        var cardholder = await _cardholderRepository.GetByNymCardUserIdAsync(request.UserId, cancellationToken);

        if (cardholder is null)
        {
            throw new NotFoundException($"Cardholder with userId '{request.UserId}' was not found.");
        }

        return new GetCardholderResponse(
            cardholder.cardholderId,           
            cardholder.cardholderReference,
            cardholder.firstName,
            cardholder.lastName,
            cardholder.emailAddress,
            cardholder.phoneNumber,
            cardholder.dateOfBirth,
            cardholder.addressLine1,
            cardholder.city,
            cardholder.country,
            cardholder.postalCode
        );
    }
}
