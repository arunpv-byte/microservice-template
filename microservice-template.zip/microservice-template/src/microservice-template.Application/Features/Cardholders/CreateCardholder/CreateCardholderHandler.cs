using MediatR;
using Microsoft.Extensions.Logging;
using microservice_template.Application.Interfaces;
using microservice_template.Domain.Entities;
using System.Security.Cryptography;

namespace microservice_template.Application.Features.Cardholders.CreateCardholder;

public sealed class CreateCardholderHandler : IRequestHandler<CreateCardholderCommand, CreateCardholderResponse>
{
    private readonly IThirdPartyServiceFactory _serviceFactory;
    private readonly ICardholderRepository _cardholderRepository;
    private readonly ILogger<CreateCardholderHandler> _logger;

    public CreateCardholderHandler(IThirdPartyServiceFactory serviceFactory, ICardholderRepository cardholderRepository, ILogger<CreateCardholderHandler> logger)
    {
        _serviceFactory = serviceFactory;
        _cardholderRepository = cardholderRepository;
        _logger = logger;
    }

    public async Task<CreateCardholderResponse> Handle(CreateCardholderCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Creating cardholder: {FirstName} {LastName}", request.firstName, request.lastName);

        var nymCardService = _serviceFactory.GetService<INymCardService>();
        var centreId = _cardholderRepository.GetCtsCredCentreId(request.username, request.deviceId);

        string cardholderReference = GetRandomCardholderref(10, Convert.ToInt32(centreId));

        var parentUserId = _cardholderRepository.GetParentUserId(centreId);
      
        var nymcardCreateCardholderReq = new Nymcard_CreateCardholderReq
        {
            id = cardholderReference,
            title = "MR",
            first_name = request.firstName,
            last_name = request.lastName,
            date_of_birth = request.dateOfBirth,
            gender = request.gender == "M" ? "MALE" : "FEMALE",
            email = request.emailAddress,
            mobile = request.phoneNumber.Replace(@"-", ""),
            address = new Address
            {
                address_line1 = request.address1,
                address_line2 = request.address2,
                city = request.city,
                country = request.country,
                postal_code = request.postalCode,
            },
            nationality = request.country,
            preferred_language = "EN",
            place_of_birth = "ARE",
            country_residence = "ARE",
            country_tax_residence = "ARE",
            employment_type = "OTHER",
            company_name = "Gift Card",
            parent_user_id = string.IsNullOrEmpty(parentUserId)? null: parentUserId
        };

        var nymCardResponse = await nymCardService.CreateUserAsync(nymcardCreateCardholderReq, cancellationToken);

        if(string.IsNullOrWhiteSpace(nymCardResponse.UserId))
        {
            return new CreateCardholderResponse(
                      "0",
                      "",
                      request.firstName,
                      request.lastName,
                      request.emailAddress
                  );
        }
       
        var cardholder = Cardholder.Create(
            "",
            nymCardResponse.UserId,
            request.firstName,
            request.lastName,
            request.emailAddress,
            request.phoneNumber,
            request.dateOfBirth,
            request.address1,
            request.address2,
            request.city,
            request.country,
            request.postalCode
        );

         cardholder = await _cardholderRepository.CreateAsync(cardholder, cancellationToken);

        _logger.LogInformation("Cardholder created successfully with ID: {UserId}", nymCardResponse.UserId);

        return new CreateCardholderResponse(
            cardholder.cardholderId,
            nymCardResponse.UserId,            
            request.firstName,
            request.lastName,
            request.emailAddress
        );
    }

    private string GetRandomCardholderref(int length, int centreId)
    {
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ01234567890";
        
        while (true)
        {
            var result = new char[length];
            for (var i = 0; i < result.Length; i++)
            {
                var randomIndex = RandomNumberGeneratorUtility.GenerateThreadSafeRandomNumber(0, chars.Length);
                result[i] = chars[randomIndex];
            }
            
            var cardholderRef = new string(result);
            if (_cardholderRepository.checkcardholderref(centreId, cardholderRef) == 0)
            {
                return cardholderRef;
            }
        }
    }
}

public static class RandomNumberGeneratorUtility
{
    private static readonly RandomNumberGenerator _rng = RandomNumberGenerator.Create();

    public static int GenerateSecureRandomNumber(int minValue, int maxValue)
    {
        ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual(minValue, maxValue);

        var range = maxValue - minValue;
        var randomBytes = new byte[4];
        
        int randomValue;
        do
        {
            _rng.GetBytes(randomBytes);
            randomValue = Math.Abs(BitConverter.ToInt32(randomBytes, 0)) % range;
        } while (randomValue >= range);

        return minValue + randomValue;
    }

    public static double GenerateSecureRandomDouble()
    {
        var bytes = new byte[8];
        _rng.GetBytes(bytes);
        var ulongResult = BitConverter.ToUInt64(bytes, 0);
        return (double)ulongResult / ulong.MaxValue;
    }

    public static int GenerateThreadSafeRandomNumber(int minValue, int maxValue) 
        => GenerateSecureRandomNumber(minValue, maxValue);

    public static double GenerateThreadSafeRandomDouble() 
        => GenerateSecureRandomDouble();
}
