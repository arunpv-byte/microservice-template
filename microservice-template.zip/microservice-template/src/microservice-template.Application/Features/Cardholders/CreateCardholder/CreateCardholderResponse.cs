namespace microservice_template.Application.Features.Cardholders.CreateCardholder;

public sealed record CreateCardholderResponse(
    string userId,
    string firstName,
    string lastName,
    string email,
    string status,
    DateTime createdAt
);