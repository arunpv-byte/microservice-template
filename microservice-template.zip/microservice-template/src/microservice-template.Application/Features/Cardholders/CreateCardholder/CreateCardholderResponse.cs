namespace microservice_template.Application.Features.Cardholders.CreateCardholder;

public sealed record CreateCardholderResponse(
    string cardholderId,
    string cardholderReference,
    string firstName,
    string lastName,
    string emailAddress
);
