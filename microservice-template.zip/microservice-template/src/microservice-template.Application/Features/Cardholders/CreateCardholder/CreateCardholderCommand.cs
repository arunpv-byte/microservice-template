using MediatR;

namespace microservice_template.Application.Features.Cardholders.CreateCardholder;

public sealed record CreateCardholderCommand(
    string firstName,
    string lastName,
    string email,
    string phoneNumber,
    string dateOfBirth,
    string address1,
    string address2,
    string address3,
    string town,
    string country,
    string postalCode,
    string username,
    string deviceId,
    string title,
    string middlename,
    string nickname,
    string gender
) : IRequest<CreateCardholderResponse>;
