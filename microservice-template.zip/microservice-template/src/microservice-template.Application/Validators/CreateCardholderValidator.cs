using FluentValidation;
using microservice_template.Application.Features.Cardholders.CreateCardholder;

namespace microservice_template.Application.Validators;

public sealed class CreateCardholderValidator : AbstractValidator<CreateCardholderCommand>
{
    /// <summary>
    /// Just added for future validation references
    /// </summary>
    public CreateCardholderValidator()
    {
        RuleFor(x => x.firstName)
            .NotEmpty().WithMessage("First name is required")
            .MaximumLength(100).WithMessage("First name must not exceed 100 characters");

        RuleFor(x => x.phoneNumber)
            .NotEmpty().WithMessage("Phone number is required")
            .MaximumLength(20).WithMessage("Phone number must not exceed 20 characters");

    }
}
