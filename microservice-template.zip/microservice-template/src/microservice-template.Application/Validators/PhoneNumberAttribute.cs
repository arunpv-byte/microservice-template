using System.ComponentModel.DataAnnotations;
using System.Reflection;
using System;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;

namespace microservice_template.Application.Validators
{
    [AttributeUsage(AttributeTargets.Property)]
    public class PhoneNumberAttribute : ValidationAttribute
    {
        private const int MaxLength = 15;

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value is not string phone || string.IsNullOrWhiteSpace(phone))
            {
                // Skip validation when no value is provided
                return ValidationResult.Success!;
            }

            if (phone.Length > MaxLength)
            {
                return new ValidationResult($"{validationContext.DisplayName} cannot exceed {MaxLength} characters.");
            }

            return ValidationResult.Success!;
        }
    }

    public class PhoneNumberValidationFilter : IActionFilter
    {
        public void OnActionExecuting(ActionExecutingContext context)
        {
            var errors = new List<string>();

            foreach (var arg in context.ActionArguments.Values)
            {
                if (arg == null) continue;

                var properties = arg.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

                foreach (var prop in properties)
                {
                    var attr = prop.GetCustomAttribute<PhoneNumberAttribute>();
                    if (attr == null) continue;

                    var value = prop.GetValue(arg);
                    var validationContext = new System.ComponentModel.DataAnnotations.ValidationContext(arg)
                    {
                        MemberName = prop.Name
                    };

                    var result = attr.GetValidationResult(value, validationContext);
                    if (result != System.ComponentModel.DataAnnotations.ValidationResult.Success)
                    {
                        errors.Add(result!.ErrorMessage!);
                    }
                }
            }

            if (errors.Any())
            {
                context.Result = new BadRequestObjectResult(new { errors });
            }
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            // Nothing needed here
        }
    }
}
