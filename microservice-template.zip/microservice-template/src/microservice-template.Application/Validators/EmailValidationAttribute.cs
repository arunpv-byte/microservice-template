using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace microservice_template.Application.Validators
{
    public class EmailValidationAttribute : ValidationAttribute
    {
        public EmailValidationAttribute()
        {
            ErrorMessage = "Invalid email address format.";
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var email = value?.ToString();

            if (string.IsNullOrWhiteSpace(email))
                return ValidationResult.Success;

            // 1. Disallowed characters (NEW)
            if (RegexHelper.HasInvalidEmailChars(email))
            {
                return new ValidationResult(
                    $"{validationContext.MemberName} contains invalid characters.");
            }

            // 2. Length check (same as CustomEmailAttribute)
            if (email.Length < 5 || email.Length > 100)
            {
                return new ValidationResult(
                    "Email must be between 5 and 100 characters.");
            }

            // 3. Format check (same regex)
            var regex = new Regex(@"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,63}$",
                                  RegexOptions.Compiled);

            if (!regex.IsMatch(email))
            {
                return new ValidationResult(ErrorMessage);
            }

            return ValidationResult.Success;
        }
    }

    public static partial class RegexHelper
    {
        [GeneratedRegex(@"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$", RegexOptions.Compiled)]
        public static partial Regex EmailRegex();

        [GeneratedRegex("\\[\\SubjectStart\\](.*?)\\[SubjectEnd\\]")]
        public static partial Regex SubjectRegex();

        [GeneratedRegex(@"^[ ]+$")]
        public static partial Regex OnlySpacesRegex();

        private static readonly Regex DateForbiddenChars =
     new(@"[;,\\\/:!\?<>\~#%\^@\+\*_\$\(\)\{\}\|&'\[\]""]",
         RegexOptions.Compiled);


        private static readonly Regex EmailForbiddenChars =
     new(@"[;,\\\/:!\?<>\~#%\^\(\)\{\}\|&'\[\]""]",
         RegexOptions.Compiled);


        public static bool HasInvalidDateChars(string value)
        {
            if (string.IsNullOrEmpty(value))
                return false;

            return DateForbiddenChars.IsMatch(value);
        }

        public static bool HasInvalidEmailChars(string value)
        {
            if (string.IsNullOrEmpty(value))
                return false;

            return EmailForbiddenChars.IsMatch(value);
        }
    }
}
