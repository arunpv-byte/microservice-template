namespace microservice_template.Application.Interfaces;

public interface IThirdPartyServiceFactory
{
    T GetService<T>() where T : class;
}