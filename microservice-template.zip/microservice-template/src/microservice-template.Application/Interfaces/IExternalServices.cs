namespace microservice_template.Application.Interfaces;

public interface IExternalService
{
    string ServiceName { get; }
}