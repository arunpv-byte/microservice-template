namespace microservice_template.Application.Interfaces;

public interface ICorrelationIdService
{
    string GetCorrelationId();
    void SetCorrelationId(string correlationId);
}