using System.Net;

namespace microservice_template.Application.Interfaces;

public interface INymCardService
{
    Task<NymCardCreateUserResponse> CreateUserAsync(Nymcard_CreateCardholderReq request, CancellationToken cancellationToken);
    Task<NymCardUpdateUserResponse> UpdateUserAsync(string userId, NymCardUpdateUserRequest request, CancellationToken cancellationToken);   
}

#region Nymcard entities
public class Nymcard_CreateCardholderReq
{
    public string id { get; set; }
    public string title { get; set; }
    public string first_name { get; set; }
    public string middle_name { get; set; }
    public string last_name { get; set; }
    public string native_name { get; set; }
    public string date_of_birth { get; set; }
    public string email { get; set; }
    public string mobile { get; set; }
    public Address address { get; set; }
    public string gender { get; set; }
    public string preferred_language { get; set; }
    public string place_of_birth { get; set; }
    public string nationality { get; set; }
    public string parent_user_id { get; set; }
    public string country_residence { get; set; }
    public string country_tax_residence { get; set; }
    public string employment_type { get; set; }
    public string employment_title { get; set; }
    public string monthly_salary { get; set; }
    public string company_name { get; set; }
    public Company_address company_address { get; set; }
    public string company_country { get; set; }
    public string industry_type { get; set; }
    public string expected_monthly_balance { get; set; }
    public string relationship_with_parent { get; set; }
    public string user_type { get; set; }
    public string business_legal_name { get; set; }
    public string business_dba_name { get; set; }
    public string phone_number { get; set; }
    public string website { get; set; }
    public string designation { get; set; }
    public string share_controller_name { get; set; }
    public Local_address local_address { get; set; }
    public string incorporation_type { get; set; }
    public string entity_registered_no { get; set; }
    public string old_entity_name { get; set; }
    public string old_entity_ops_start_date { get; set; }
    public string old_entity_ops_end_date { get; set; }
    public bool regulated_entity { get; set; }
    public string regulator_name { get; set; }
    public string business_activities { get; set; }
    public string other_operated_countries { get; set; }
    public string tax_residence_country { get; set; }
    public string tin { get; set; }
    public string external_auditor_name { get; set; }
    public List<string> director_list { get; set; }
    public List<string> signature_list { get; set; }
    public List<string> shareholder_list { get; set; }
    public bool company_onbehalf { get; set; }
    public string company_onbehalf_relation { get; set; }
    public Group_additional_info group_additional_info { get; set; }
    public Pep_check_info pep_check_info { get; set; }
    public string no_of_employees { get; set; }
    public bool accept_cash_check { get; set; }
    public double annual_turnover { get; set; }
    public string source_of_funds { get; set; }
    public bool source_fund_uae { get; set; }
    public Due_diligence_declaration due_diligence_declaration { get; set; }
}

public class Address
{
    public string address_line1 { get; set; }
    public string address_line2 { get; set; }
    public string city { get; set; }
    public string state { get; set; }
    public string postal_code { get; set; }
    public string country { get; set; }
}

public class Company_address
{
    public string address_line1 { get; set; }
    public string address_line2 { get; set; }
    public string city { get; set; }
    public string state { get; set; }
    public string postal_code { get; set; }
    public string country { get; set; }
}

public class Local_address
{
    public string address_line1 { get; set; }
    public string address_line2 { get; set; }
    public string city { get; set; }
    public string state { get; set; }
    public string postal_code { get; set; }
    public string country { get; set; }
}

public class Group_additional_info
{
    public string group_entity { get; set; }
    public string independent_entity { get; set; }
    public string special_investment { get; set; }
    public string entity_details { get; set; }
}

public class Pep_check_info
{
    public string pri_pep_check { get; set; }
    public string pri_pep_check_name { get; set; }
    public string sec_pep_check { get; set; }
    public string sec_pep_check_name { get; set; }
}

public class Due_diligence_declaration
{
    public string bankruptcy_declaration { get; set; }
    public string disciplinary_declaration { get; set; }
    public string fraud_aml_declaration { get; set; }
    public string disqualification_declaration { get; set; }
    public string conviction_accusition_declaration { get; set; }
    public string breach_of_law_declaration { get; set; }
}

public sealed record NymCardCreateUserResponse(  
    string UserId,
    string Status,
    string Message
);

public sealed record NymCardUpdateUserRequest(    
    string email,
    string mobile
);

public sealed record NymCardUpdateUserResponse(
    string UserId,
    string Status,
    string Message
);

//public sealed record NymCardAccountResponse(
//    string AccountId,
//    decimal AvailableBalance
//);

#endregion
