using System.Net;

namespace microservice_template.Application.Interfaces;

public interface INymCardService
{
    Task<NymCardCreateUserResponse> CreateUserAsync(NymCardCreateUserRequest request, CancellationToken cancellationToken);
    Task<NymCardUpdateUserResponse> UpdateUserAsync(string userId, NymCardUpdateUserRequest request, CancellationToken cancellationToken);
    Task<NymCardAccountResponse?> GetAccountAsync(string accountId, CancellationToken cancellationToken);
}

public sealed class NymCardCreateUserRequest
{
    public string Id { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string MiddleName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string NativeName { get; set; } = string.Empty;
    public string DateOfBirth { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Mobile { get; set; } = string.Empty;
    public Address Address { get; set; } = new();
    public string Gender { get; set; } = string.Empty;
    public string PreferredLanguage { get; set; } = string.Empty;
    public string PlaceOfBirth { get; set; } = string.Empty;
    public string Nationality { get; set; } = string.Empty;
    public string ParentUserId { get; set; } = string.Empty;
    public string CountryResidence { get; set; } = string.Empty;
    public string CountryTaxResidence { get; set; } = string.Empty;
    public string EmploymentType { get; set; } = string.Empty;
    public string EmploymentTitle { get; set; } = string.Empty;
    public string MonthlySalary { get; set; } = string.Empty;
    public string CompanyName { get; set; } = string.Empty;
    public CompanyAddress CompanyAddress { get; set; } = new();
    public string CompanyCountry { get; set; } = string.Empty;
    public string IndustryType { get; set; } = string.Empty;
    public string ExpectedMonthlyBalance { get; set; } = string.Empty;
    public string RelationshipWithParent { get; set; } = string.Empty;
    public string UserType { get; set; } = string.Empty;
    public string BusinessLegalName { get; set; } = string.Empty;
    public string BusinessDbaName { get; set; } = string.Empty;
    public string PhoneNumber { get; set; } = string.Empty;
    public string Website { get; set; } = string.Empty;
    public string Designation { get; set; } = string.Empty;
    public string ShareControllerName { get; set; } = string.Empty;
    public LocalAddress LocalAddress { get; set; } = new();
    public string IncorporationType { get; set; } = string.Empty;
    public string EntityRegisteredNo { get; set; } = string.Empty;
    public string OldEntityName { get; set; } = string.Empty;
    public string OldEntityOpsStartDate { get; set; } = string.Empty;
    public string OldEntityOpsEndDate { get; set; } = string.Empty;
    public bool RegulatedEntity { get; set; }
    public string RegulatorName { get; set; } = string.Empty;
    public string BusinessActivities { get; set; } = string.Empty;
    public string OtherOperatedCountries { get; set; } = string.Empty;
    public string TaxResidenceCountry { get; set; } = string.Empty;
    public string Tin { get; set; } = string.Empty;
    public string ExternalAuditorName { get; set; } = string.Empty;
    public List<string> DirectorList { get; set; } = new();
    public List<string> SignatureList { get; set; } = new();
    public List<string> ShareholderList { get; set; } = new();
    public bool CompanyOnBehalf { get; set; }
    public string CompanyOnBehalfRelation { get; set; } = string.Empty;
    public GroupAdditionalInfo GroupAdditionalInfo { get; set; } = new();
    public PepCheckInfo PepCheckInfo { get; set; } = new();
    public string NoOfEmployees { get; set; } = string.Empty;
    public bool AcceptCashCheck { get; set; }
    public double AnnualTurnover { get; set; }
    public string SourceOfFunds { get; set; } = string.Empty;
    public bool SourceFundUae { get; set; }
    public DueDiligenceDeclaration DueDiligenceDeclaration { get; set; } = new();
}

public sealed class Address
{
    public string AddressLine1 { get; set; } = string.Empty;
    public string AddressLine2 { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string State { get; set; } = string.Empty;
    public string PostalCode { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
}

public sealed class CompanyAddress
{
    public string AddressLine1 { get; set; } = string.Empty;
    public string AddressLine2 { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string State { get; set; } = string.Empty;
    public string PostalCode { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
}

public sealed class LocalAddress
{
    public string AddressLine1 { get; set; } = string.Empty;
    public string AddressLine2 { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string State { get; set; } = string.Empty;
    public string PostalCode { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
}

public sealed class GroupAdditionalInfo
{
    public string GroupEntity { get; set; } = string.Empty;
    public string IndependentEntity { get; set; } = string.Empty;
    public string SpecialInvestment { get; set; } = string.Empty;
    public string EntityDetails { get; set; } = string.Empty;
}

public sealed class PepCheckInfo
{
    public string PriPepCheck { get; set; } = string.Empty;
    public string PriPepCheckName { get; set; } = string.Empty;
    public string SecPepCheck { get; set; } = string.Empty;
    public string SecPepCheckName { get; set; } = string.Empty;
}

public sealed class DueDiligenceDeclaration
{
    public string BankruptcyDeclaration { get; set; } = string.Empty;
    public string DisciplinaryDeclaration { get; set; } = string.Empty;
    public string FraudAmlDeclaration { get; set; } = string.Empty;
    public string DisqualificationDeclaration { get; set; } = string.Empty;
    public string ConvictionAccusitionDeclaration { get; set; } = string.Empty;
    public string BreachOfLawDeclaration { get; set; } = string.Empty;
}

public sealed record NymCardCreateUserResponse(
    string UserId,
    string Status,
    string Message
);

public sealed record NymCardUpdateUserRequest(
    string FirstName,
    string LastName,
    string Email,
    string PhoneNumber,
    string Address,
    string City,
    string Country,
    string PostalCode
);

public sealed record NymCardUpdateUserResponse(
    string UserId,
    string Status,
    string Message
);

public sealed record NymCardAccountResponse(
    string AccountId,
    decimal AvailableBalance,
    string Currency
);