using microservice_template.Domain.Events;

namespace microservice_template.Application.Interfaces;

public interface IMessagePublisher
{
    Task PublishAsync<T>(T message, string topic, CancellationToken cancellationToken = default) where T : class;
    Task PublishDomainEventAsync<T>(T domainEvent, CancellationToken cancellationToken = default) where T : class, IDomainEvent;
}