using microservice_template.Domain.Entities;

namespace microservice_template.Application.Interfaces;

public interface ICardholderRepository
{
    string GetCtsCredCentreId(string username = "", string deviceId = "");
    int checkcardholderref(int client, string cardholderReference);
    string GetParentUserId(string centreId);
    Task<Cardholder> CreateAsync(Cardholder cardholder, CancellationToken cancellationToken);    
    Task<Cardholder?> GetByNymCardUserIdAsync(string nymCardUserId, CancellationToken cancellationToken);
    Task<Cardholder> UpdateAsync(Cardholder cardholder, CancellationToken cancellationToken);
}
