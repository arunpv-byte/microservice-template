namespace microservice_template.Domain.Entities;

public sealed class Cardholder
{
    public Guid Id { get; private set; }
    public string NymCardUserId { get; private set; } = string.Empty;
    public string FirstName { get; private set; } = string.Empty;
    public string LastName { get; private set; } = string.Empty;
    public string Email { get; private set; } = string.Empty;
    public string PhoneNumber { get; private set; } = string.Empty;
    public string DateOfBirth { get; private set; } = string.Empty;
    public string Address { get; private set; } = string.Empty;
    public string City { get; private set; } = string.Empty;
    public string Country { get; private set; } = string.Empty;
    public string PostalCode { get; private set; } = string.Empty;
    public string Status { get; private set; } = string.Empty;
    public DateTime CreatedAt { get; private set; }
    public DateTime? UpdatedAt { get; private set; }

    private Cardholder() { }

    private Cardholder(Guid id, string nymCardUserId, string firstName, string lastName, string email, 
        string phoneNumber, string dateOfBirth, string address, string city, string country, 
        string postalCode, string status)
    {
        Id = id;
        NymCardUserId = nymCardUserId;
        FirstName = firstName;
        LastName = lastName;
        Email = email;
        PhoneNumber = phoneNumber;
        DateOfBirth = dateOfBirth;
        Address = address;
        City = city;
        Country = country;
        PostalCode = postalCode;
        Status = status;
        CreatedAt = DateTime.UtcNow;
    }

    public static Cardholder Create(string nymCardUserId, string firstName, string lastName, string email,
        string phoneNumber, string dateOfBirth, string address, string city, string country,
        string postalCode, string status)
    {
        return new Cardholder(Guid.NewGuid(), nymCardUserId, firstName, lastName, email, phoneNumber,
            dateOfBirth, address, city, country, postalCode, status);
    }

    public void Update(string firstName, string lastName, string email, string phoneNumber,
        string address, string city, string country, string postalCode, string status)
    {
        FirstName = firstName;
        LastName = lastName;
        Email = email;
        PhoneNumber = phoneNumber;
        Address = address;
        City = city;
        Country = country;
        PostalCode = postalCode;
        Status = status;
        UpdatedAt = DateTime.UtcNow;
    }
}
