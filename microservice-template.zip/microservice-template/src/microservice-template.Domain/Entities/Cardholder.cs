namespace microservice_template.Domain.Entities;

public sealed class Cardholder
{
    public string cardholderId { get; set; } = string.Empty;
    public string cardholderReference { get; private set; } = string.Empty;
    public string firstName { get; private set; } = string.Empty;
    public string lastName { get; private set; } = string.Empty;
    public string emailAddress { get; set; } = string.Empty;
    public string phoneNumber { get; set; } = string.Empty;
    public string dateOfBirth { get; private set; } = string.Empty;
    public string addressLine1 { get; private set; } = string.Empty;
    public string addressLine2 { get; private set; } = string.Empty;
    public string city { get; private set; } = string.Empty;
    public string country { get; private set; } = string.Empty;
    public string postalCode { get; private set; } = string.Empty;

    private Cardholder() { }

    private Cardholder(
    string cardholderId,
    string cardholderReference,
    string firstName,
    string lastName,
    string emailAddress,
    string phoneNumber,
    string dateOfBirth,
    string addressLine1,
    string addressLine2,
    string city,
    string country,
    string postalCode)
    {
        this.cardholderId = cardholderId;
        this.cardholderReference = cardholderReference;
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailAddress = emailAddress;
        this.phoneNumber = phoneNumber;
        this.dateOfBirth = dateOfBirth;
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.city = city;
        this.country = country;
        this.postalCode = postalCode;
    }

    public static Cardholder Create(
        string cardholderId,
    string cardholderReference,
    string firstName,
    string lastName,
    string emailAddress,
    string phoneNumber,
    string dateOfBirth,
    string addressLine1,
    string addressLine2,
    string city,
    string country,
    string postalCode)
    {
        var cardholderDetails = new Cardholder(cardholderId, cardholderReference, firstName, lastName, emailAddress, phoneNumber,
            dateOfBirth, addressLine1, addressLine2, city, country, postalCode);
        return cardholderDetails;
    }

    public void Update(
    string cardholderReference,
    string emailAddress,
    string phoneNumber
    )
    {
        cardholderReference = cardholderReference;
        emailAddress = emailAddress;
        phoneNumber = phoneNumber;
    }
}
