namespace microservice_template.Domain.Events;

public record CardholderCreatedEvent(
    string UserId,
    string Email,
    string FirstName,
    string LastName,
    DateTime CreatedAt
) : IDomainEvent
{
    public DateTime OccurredOn { get; } = DateTime.UtcNow;
    public Guid EventId { get; } = Guid.NewGuid();
}
