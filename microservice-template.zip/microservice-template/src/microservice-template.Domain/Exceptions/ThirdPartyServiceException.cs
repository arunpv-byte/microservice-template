namespace microservice_template.Domain.Exceptions;

public class ThirdPartyServiceException : Exception
{
    public string ServiceName { get; }
    public int? StatusCode { get; }
    public string? ErrorCode { get; }

    public ThirdPartyServiceException(string serviceName, string message) 
        : base(message)
    {
        ServiceName = serviceName;
    }

    public ThirdPartyServiceException(string serviceName, int statusCode, string message) 
        : base(message)
    {
        ServiceName = serviceName;
        StatusCode = statusCode;
    }

    public ThirdPartyServiceException(string serviceName, int statusCode, string errorCode, string message) 
        : base(message)
    {
        ServiceName = serviceName;
        StatusCode = statusCode;
        ErrorCode = errorCode;
    }
}

public class ThirdPartyServiceTimeoutException : ThirdPartyServiceException
{
    public ThirdPartyServiceTimeoutException(string serviceName) 
        : base(serviceName, $"{serviceName} service request timed out")
    {
    }
}

public class ThirdPartyServiceUnavailableException : ThirdPartyServiceException
{
    public ThirdPartyServiceUnavailableException(string serviceName) 
        : base(serviceName, 503, $"{serviceName} service is currently unavailable")
    {
    }
}