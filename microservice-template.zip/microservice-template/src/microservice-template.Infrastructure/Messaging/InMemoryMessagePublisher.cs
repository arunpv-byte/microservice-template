using System.Text.Json;
using microservice_template.Application.Interfaces;
using microservice_template.Domain.Events;
using Microsoft.Extensions.Logging;

namespace microservice_template.Infrastructure.Messaging;

public class InMemoryMessagePublisher : IMessagePublisher
{
    private readonly ILogger<InMemoryMessagePublisher> _logger;

    public InMemoryMessagePublisher(ILogger<InMemoryMessagePublisher> logger)
    {
        _logger = logger;
    }

    public Task PublishAsync<T>(T message, string topic, CancellationToken cancellationToken = default) where T : class
    {
        var serializedMessage = JsonSerializer.Serialize(message);
        _logger.LogInformation("Publishing message to topic {Topic}: {Message}", topic, serializedMessage);
        
        // In production, this would publish to actual message queue (RabbitMQ, Azure Service Bus, etc.)
        return Task.CompletedTask;
    }

    public Task PublishDomainEventAsync<T>(T domainEvent, CancellationToken cancellationToken = default) where T : class, IDomainEvent
    {
        var topic = $"domain-events.{typeof(T).Name.ToLowerInvariant()}";
        return PublishAsync(domainEvent, topic, cancellationToken);
    }
}