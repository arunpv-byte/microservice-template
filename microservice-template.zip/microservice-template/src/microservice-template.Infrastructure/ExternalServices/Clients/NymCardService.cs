using Microsoft.Extensions.Logging;
using microservice_template.Application.Interfaces;
using microservice_template.Infrastructure.ExternalServices.Abstractions;
using System.Text.Json;

namespace microservice_template.Infrastructure.ExternalServices.Clients;

public sealed class NymCardService : ResilientHttpClient, INymCardService
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    public NymCardService(HttpClient httpClient, ILogger<NymCardService> logger)
        : base(httpClient, logger)
    {
        Console.WriteLine($"NymCardService constructor called with HttpClient: {httpClient.BaseAddress}");
        Console.WriteLine($"HttpClient headers: {string.Join(", ", httpClient.DefaultRequestHeaders.Select(h => $"{h.Key}={string.Join(",", h.Value)}"))}");
    }

    public async Task<NymCardCreateUserResponse> CreateUserAsync(NymCardCreateUserRequest request, CancellationToken cancellationToken)
    {
        Logger.LogInformation("Creating user in NymCard: {Email}", request.Email);

        try
        {
            var response = await PostAsync<NymCardApiResponse>("/v1/users", request, cancellationToken);
            
            Logger.LogInformation("User created successfully in NymCard: {UserId}", response?.Id);
            
            return new NymCardCreateUserResponse(
                response?.Id ?? string.Empty,
                "Success",
                "User created successfully"
            );
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, "HTTP error while creating user in NymCard: {Email}", request.Email);
            return new NymCardCreateUserResponse(string.Empty, "Error", "External service unavailable");
        }
        catch (TaskCanceledException ex)
        {
            Logger.LogError(ex, "Timeout while creating user in NymCard: {Email}", request.Email);
            return new NymCardCreateUserResponse(string.Empty, "Error", "Request timeout");
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Unexpected error while creating user in NymCard: {Email}", request.Email);
            return new NymCardCreateUserResponse(string.Empty, "Error", "An unexpected error occurred");
        }
    }

    public async Task<NymCardUpdateUserResponse> UpdateUserAsync(string userId, NymCardUpdateUserRequest request, CancellationToken cancellationToken)
    {
        Logger.LogInformation("Updating user in NymCard: {UserId}", userId);

        var payload = new
        {
            firstName = request.FirstName,
            lastName = request.LastName,
            email = request.Email,
            phoneNumber = request.PhoneNumber,
            address = new
            {
                street = request.Address,
                city = request.City,
                country = request.Country,
                postalCode = request.PostalCode
            }
        };

        try
        {
            var response = await PutAsync<NymCardApiResponse>($"/v1/users/{userId}", payload, cancellationToken);
            
            Logger.LogInformation("User updated successfully in NymCard: {UserId}", userId);
            
            return new NymCardUpdateUserResponse(
                userId,
                "Success",
                "User updated successfully"
            );
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, "HTTP error while updating user in NymCard: {UserId}", userId);
            return new NymCardUpdateUserResponse(userId, "Error", "External service unavailable");
        }
        catch (TaskCanceledException ex)
        {
            Logger.LogError(ex, "Timeout while updating user in NymCard: {UserId}", userId);
            return new NymCardUpdateUserResponse(userId, "Error", "Request timeout");
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Unexpected error while updating user in NymCard: {UserId}", userId);
            return new NymCardUpdateUserResponse(userId, "Error", "An unexpected error occurred");
        }
    }
    public async Task<NymCardAccountResponse?> GetAccountAsync(string accountId, CancellationToken cancellationToken)
    {
        Logger.LogInformation("Getting account balance from NymCard: {AccountId}", accountId);

        try
        {
            var response = await GetAsync<NymCardAccountApiResponse>($"/v1/accounts/{accountId}", cancellationToken);
            
            if (response is null)
            {
                Logger.LogWarning("Account not found in NymCard: {AccountId}", accountId);
                return null;
            }

            Logger.LogInformation("Account balance retrieved successfully from NymCard: {AccountId}", accountId);
            
            return new NymCardAccountResponse(
                response.Id,
                response.AvailableBalance,
                response.Currency
            );
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, "HTTP error while getting account from NymCard: {AccountId}", accountId);
            return null;
        }
        catch (TaskCanceledException ex)
        {
            Logger.LogError(ex, "Timeout while getting account from NymCard: {AccountId}", accountId);
            return null;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Unexpected error while getting account from NymCard: {AccountId}", accountId);
            return null;
        }
    }
}

internal sealed record NymCardApiResponse(string Id, string Status);
internal sealed record NymCardAccountApiResponse(string Id, decimal AvailableBalance, string Currency);
