using Microsoft.Extensions.Logging;
using microservice_template.Application.Interfaces;
using microservice_template.Infrastructure.ExternalServices.Abstractions;
using System.Text.Json;

namespace microservice_template.Infrastructure.ExternalServices.Clients;

public sealed class NymCardService : ResilientHttpClient, INymCardService
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    private readonly ICorrelationIdService _correlationIdService;

    public NymCardService(HttpClient httpClient, ILogger<NymCardService> logger, ICorrelationIdService correlationIdService)
        : base(httpClient, logger, correlationIdService)
    {
        _correlationIdService = correlationIdService;
        Console.WriteLine($"NymCardService constructor called with HttpClient: {httpClient.BaseAddress}");
        Console.WriteLine($"HttpClient headers: {string.Join(", ", httpClient.DefaultRequestHeaders.Select(h => $"{h.Key}={string.Join(",", h.Value)}"))}");
    }

    public async Task<NymCardCreateUserResponse> CreateUserAsync(Nymcard_CreateCardholderReq request, CancellationToken cancellationToken)
    {
        var correlationId = _correlationIdService.GetCorrelationId();
        Logger.LogInformation("Creating user in NymCard: {Email} with CorrelationId {CorrelationId}", request.email, correlationId);

        try
        {
            var response = await PostAsync<NymCardApiResponse>("/v1/users", request, cancellationToken);

            if (response.ErrorObj == null)
            {
                Logger.LogInformation("User created successfully in NymCard: {UserId} with CorrelationId {CorrelationId}", response?.Id, correlationId);

                return new NymCardCreateUserResponse(
                    response?.Id ?? string.Empty,
                    "Success",
                    "User created successfully"
                );
            }
            else
            {
                return new NymCardCreateUserResponse(
                  null,
                  response.ErrorObj.status.ToString(),
                  response.ErrorObj.detail
              );
            }
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, "HTTP error while creating user in NymCard: {Email} with CorrelationId {CorrelationId}", request.email, correlationId);
            return new NymCardCreateUserResponse(string.Empty, "Error", "External service unavailable");
        }
        catch (TaskCanceledException ex)
        {
            Logger.LogError(ex, "Timeout while creating user in NymCard: {Email} with CorrelationId {CorrelationId}", request.email, correlationId);
            return new NymCardCreateUserResponse(string.Empty, "Error", "Request timeout");
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Unexpected error while creating user in NymCard: {Email} with CorrelationId {CorrelationId}", request.email, correlationId);
            return new NymCardCreateUserResponse(string.Empty, "Error", "An unexpected error occurred");
        }
    }

    public async Task<NymCardUpdateUserResponse> UpdateUserAsync(string userId, NymCardUpdateUserRequest request, CancellationToken cancellationToken)
    {
        Logger.LogInformation("Updating user in NymCard: {UserId}", userId);

        try
        {
            var response = await PutAsync<NymCardApiResponse>($"/v1/users/{userId}", request, cancellationToken);

            Logger.LogInformation("User updated successfully in NymCard: {UserId}", userId);

            return new NymCardUpdateUserResponse(
                userId,
                "Success",
                "User updated successfully"
            );
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, "HTTP error while updating user in NymCard: {UserId}", userId);
            return new NymCardUpdateUserResponse(userId, "Error", "External service unavailable");
        }
        catch (TaskCanceledException ex)
        {
            Logger.LogError(ex, "Timeout while updating user in NymCard: {UserId}", userId);
            return new NymCardUpdateUserResponse(userId, "Error", "Request timeout");
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Unexpected error while updating user in NymCard: {UserId}", userId);
            return new NymCardUpdateUserResponse(userId, "Error", "An unexpected error occurred");
        }
    }
}

internal sealed record NymCardApiResponse(string Id, string Status, NymcardErrorMsg ErrorObj);

public class Conflict
{
    public string kind { get; set; }
    public string id { get; set; }
}

public class Field
{
    public string field { get; set; }
    public string message { get; set; }
}

public class NymcardErrorMsg
{
    public Conflict conflict { get; set; }
    public List<Field> fields { get; set; }
    public string type { get; set; }
    public string title { get; set; }
    public int status { get; set; }
    public string detail { get; set; }
}
