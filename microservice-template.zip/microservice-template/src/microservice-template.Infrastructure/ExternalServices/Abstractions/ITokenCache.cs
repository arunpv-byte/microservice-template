using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;

namespace microservice_template.Infrastructure.ExternalServices.Abstractions;

public interface ITokenCache
{
    Task<string?> GetTokenAsync(string key, CancellationToken cancellationToken = default);
    Task SetTokenAsync(string key, string token, TimeSpan expiry, CancellationToken cancellationToken = default);
}

public sealed class MemoryTokenCache : ITokenCache
{
    private readonly IMemoryCache _cache;
    private readonly ILogger<MemoryTokenCache> _logger;

    public MemoryTokenCache(IMemoryCache cache, ILogger<MemoryTokenCache> logger)
    {
        _cache = cache;
        _logger = logger;
    }

    public Task<string?> GetTokenAsync(string key, CancellationToken cancellationToken = default)
    {
        var token = _cache.Get<string>(key);
        _logger.LogDebug("Token cache {Status} for key {Key}", token != null ? "hit" : "miss", key);
        return Task.FromResult(token);
    }

    public Task SetTokenAsync(string key, string token, TimeSpan expiry, CancellationToken cancellationToken = default)
    {
        _cache.Set(key, token, expiry);
        _logger.LogDebug("Token cached for key {Key} with expiry {Expiry}", key, expiry);
        return Task.CompletedTask;
    }
}