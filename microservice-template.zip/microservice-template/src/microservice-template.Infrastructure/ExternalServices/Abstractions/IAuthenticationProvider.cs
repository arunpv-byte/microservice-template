namespace microservice_template.Infrastructure.ExternalServices.Abstractions;

public interface IAuthenticationProvider
{
    Task<string> GetAuthenticationHeaderAsync(CancellationToken cancellationToken = default);
}

public sealed class ApiKeyAuthProvider : IAuthenticationProvider
{
    private readonly string _apiKey;
    private readonly string _headerName;

    public ApiKeyAuthProvider(string apiKey, string headerName = "X-API-Key")
    {
        _apiKey = apiKey ?? throw new ArgumentNullException(nameof(apiKey));
        _headerName = headerName;
    }

    public Task<string> GetAuthenticationHeaderAsync(CancellationToken cancellationToken = default)
    {
        return Task.FromResult($"{_headerName}:{_apiKey}");
    }
}

public sealed class BearerTokenAuthProvider : IAuthenticationProvider
{
    private readonly string _token;

    public BearerTokenAuthProvider(string token)
    {
        _token = token ?? throw new ArgumentNullException(nameof(token));
    }

    public Task<string> GetAuthenticationHeaderAsync(CancellationToken cancellationToken = default)
    {
        return Task.FromResult($"Bearer {_token}");
    }
}

public sealed class BasicAuthProvider : IAuthenticationProvider
{
    private readonly string _credentials;

    public BasicAuthProvider(string username, string password)
    {
        var credentials = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes($"{username}:{password}"));
        _credentials = $"Basic {credentials}";
    }

    public Task<string> GetAuthenticationHeaderAsync(CancellationToken cancellationToken = default)
    {
        return Task.FromResult($"Authorization:{_credentials}");
    }
}

public sealed class OAuthTokenProvider : IAuthenticationProvider
{
    private readonly HttpClient _httpClient;
    private readonly ITokenCache _tokenCache;
    private readonly string _tokenUrl;
    private readonly string _clientId;
    private readonly string _clientSecret;
    private readonly string? _username;
    private readonly string? _password;
    private readonly string _cacheKey;

    public OAuthTokenProvider(HttpClient httpClient, ITokenCache tokenCache, string tokenUrl, string clientId, string clientSecret)
    {
        _httpClient = httpClient;
        _tokenCache = tokenCache;
        _tokenUrl = tokenUrl;
        _clientId = clientId;
        _clientSecret = clientSecret;
        _cacheKey = $"oauth_token_{clientId}";
    }

    public OAuthTokenProvider(HttpClient httpClient, ITokenCache tokenCache, string tokenUrl, string clientId, string clientSecret, string username, string password)
        : this(httpClient, tokenCache, tokenUrl, clientId, clientSecret)
    {
        _username = username;
        _password = password;
        _cacheKey = $"oauth_token_{clientId}_{username}";
    }

    public async Task<string> GetAuthenticationHeaderAsync(CancellationToken cancellationToken = default)
    {
        var cachedToken = await _tokenCache.GetTokenAsync(_cacheKey, cancellationToken);
        if (cachedToken != null)
            return $"Authorization:Bearer {cachedToken}";

        var parameters = new List<KeyValuePair<string, string>>
        {
            new("client_id", _clientId),
            new("client_secret", _clientSecret)
        };

        if (!string.IsNullOrEmpty(_username) && !string.IsNullOrEmpty(_password))
        {
            parameters.Add(new("grant_type", "password"));
            parameters.Add(new("username", _username));
            parameters.Add(new("password", _password));
        }
        else
        {
            parameters.Add(new("grant_type", "client_credentials"));
        }

        var tokenRequest = new FormUrlEncodedContent(parameters);
        var response = await _httpClient.PostAsync(_tokenUrl, tokenRequest, cancellationToken);
        response.EnsureSuccessStatusCode();

        var json = await response.Content.ReadAsStringAsync(cancellationToken);
        var tokenResponse = System.Text.Json.JsonSerializer.Deserialize<TokenResponse>(json);

        var token = tokenResponse?.AccessToken ?? throw new InvalidOperationException("No access token received");
        var expiry = TimeSpan.FromSeconds(tokenResponse.ExpiresIn - 60); // 60s buffer
        
        await _tokenCache.SetTokenAsync(_cacheKey, token, expiry, cancellationToken);
        return $"Authorization:Bearer {token}";
    }

    private sealed record TokenResponse(string AccessToken, int ExpiresIn)
    {
        public string AccessToken { get; init; } = AccessToken;
        public int ExpiresIn { get; init; } = ExpiresIn;
    }
}