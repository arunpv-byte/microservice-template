using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Text.Json;
using System.Text;
using System.Net;
using microservice_template.Domain.Exceptions;
using microservice_template.Application.Interfaces;

namespace microservice_template.Infrastructure.ExternalServices.Abstractions;

public abstract class ResilientHttpClient
{
    protected readonly HttpClient HttpClient;
    protected readonly ILogger Logger;
    private readonly ICorrelationIdService? _correlationIdService;
    private static readonly ActivitySource ActivitySource = new("ExternalServices");

    protected ResilientHttpClient(HttpClient httpClient, ILogger logger, ICorrelationIdService correlationIdService)
    {
        HttpClient = httpClient;
        Logger = logger;
        _correlationIdService = correlationIdService;
    }

    protected async Task<T?> GetAsync<T>(string endpoint, CancellationToken cancellationToken = default)
    {
        using var activity = ActivitySource.StartActivity($"GET {endpoint}");
        var correlationId = _correlationIdService?.GetCorrelationId();
        
        try
        {
            Logger.LogInformation("Making GET request to {Endpoint} with CorrelationId {CorrelationId}", endpoint, correlationId);
            var response = await HttpClient.GetAsync(endpoint, cancellationToken);

            if (response.IsSuccessStatusCode)
            {
                string successResult = await response.Content.ReadAsStringAsync();
               
            }
            else
            {
                string resultError = await response.Content.ReadAsStringAsync();

            }

            return await ProcessResponseAsync<T>(response, "GET", endpoint);
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError(ex, "Timeout occurred for GET {Endpoint}", endpoint);
            throw new ThirdPartyServiceTimeoutException(GetServiceName());
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, "HTTP request exception for GET {Endpoint}", endpoint);
            throw new ThirdPartyServiceUnavailableException(GetServiceName());
        }
    }

    protected async Task<T?> PostAsync<T>(string endpoint, object request, CancellationToken cancellationToken = default)
    {
        using var activity = ActivitySource.StartActivity($"POST {endpoint}");
        var correlationId = _correlationIdService?.GetCorrelationId();
        
        try
        {
            Logger.LogInformation("Making POST request to {Endpoint} with CorrelationId {CorrelationId}", endpoint, correlationId);
            
            var json = JsonSerializer.Serialize(request, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await HttpClient.PostAsync(endpoint, content, cancellationToken);
            return await ProcessResponseAsync<T>(response, "POST", endpoint);
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError(ex, "Timeout occurred for POST {Endpoint}", endpoint);
            throw new ThirdPartyServiceTimeoutException(GetServiceName());
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, "HTTP request exception for POST {Endpoint}", endpoint);
            throw new ThirdPartyServiceUnavailableException(GetServiceName());
        }
    }

    protected async Task<T?> PutAsync<T>(string endpoint, object request, CancellationToken cancellationToken = default)
    {
        using var activity = ActivitySource.StartActivity($"PUT {endpoint}");
        var correlationId = _correlationIdService?.GetCorrelationId();
        
        try
        {
            Logger.LogInformation("Making PUT request to {Endpoint} with CorrelationId {CorrelationId}", endpoint, correlationId);
            
            var json = JsonSerializer.Serialize(request, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await HttpClient.PutAsync(endpoint, content, cancellationToken);
            return await ProcessResponseAsync<T>(response, "PUT", endpoint);
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError(ex, "Timeout occurred for PUT {Endpoint}", endpoint);
            throw new ThirdPartyServiceTimeoutException(GetServiceName());
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, "HTTP request exception for PUT {Endpoint}", endpoint);
            throw new ThirdPartyServiceUnavailableException(GetServiceName());
        }
    }

    private async Task<T?> ProcessResponseAsync<T>(HttpResponseMessage response, string method, string endpoint)
    {
        var content = await response.Content.ReadAsStringAsync();
        
        if (response.IsSuccessStatusCode)
        {
            Logger.LogInformation("{Method} {Endpoint} succeeded with status {StatusCode}", method, endpoint, response.StatusCode);
            return JsonSerializer.Deserialize<T>(content, new JsonSerializerOptions 
            { 
                PropertyNameCaseInsensitive = true,
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });
        }

        Logger.LogError("{Method} {Endpoint} failed with status {StatusCode}. Response: {Response}", 
            method, endpoint, response.StatusCode, content);

        var errorMessage = ExtractErrorMessage(content, response.StatusCode);
        
        throw response.StatusCode switch
        {
            HttpStatusCode.BadRequest => new ThirdPartyServiceException(GetServiceName(), 400, "BadRequest", errorMessage),
            HttpStatusCode.Unauthorized => new ThirdPartyServiceException(GetServiceName(), 401, "Unauthorized", "Authentication failed"),
            HttpStatusCode.Forbidden => new ThirdPartyServiceException(GetServiceName(), 403, "Forbidden", "Access denied"),
            HttpStatusCode.NotFound => new ThirdPartyServiceException(GetServiceName(), 404, "NotFound", errorMessage),
            HttpStatusCode.TooManyRequests => new ThirdPartyServiceException(GetServiceName(), 429, "RateLimited", "Rate limit exceeded"),
            HttpStatusCode.InternalServerError => new ThirdPartyServiceException(GetServiceName(), 500, "InternalServerError", "External service error"),
            HttpStatusCode.BadGateway => new ThirdPartyServiceUnavailableException(GetServiceName()),
            HttpStatusCode.ServiceUnavailable => new ThirdPartyServiceUnavailableException(GetServiceName()),
            HttpStatusCode.GatewayTimeout => new ThirdPartyServiceTimeoutException(GetServiceName()),
            _ => new ThirdPartyServiceException(GetServiceName(), (int)response.StatusCode, errorMessage)
        };
    }

    private string ExtractErrorMessage(string content, HttpStatusCode statusCode)
    {
        try
        {
            using var document = JsonDocument.Parse(content);
            
            if (document.RootElement.TryGetProperty("message", out var message))
                return message.GetString() ?? $"Request failed with status {statusCode}";
            
            if (document.RootElement.TryGetProperty("error", out var error))
                return error.GetString() ?? $"Request failed with status {statusCode}";
            
            if (document.RootElement.TryGetProperty("detail", out var detail))
                return detail.GetString() ?? $"Request failed with status {statusCode}";
        }
        catch
        {
            // JSON parsing failed, return generic message
        }
        
        return $"Request failed with status {statusCode}";
    }

    private string GetServiceName()
    {
        var typeName = GetType().Name;
        return typeName.EndsWith("Service") ? typeName[..^7] : typeName;
    }
}
