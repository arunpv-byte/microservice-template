using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Diagnostics;

namespace microservice_template.Infrastructure.ExternalServices.Abstractions;

public abstract class ResilientHttpClient
{
    protected readonly HttpClient HttpClient;
    protected readonly ILogger Logger;
    private static readonly ActivitySource ActivitySource = new("ExternalServices");

    protected ResilientHttpClient(HttpClient httpClient, ILogger logger)
    {
        HttpClient = httpClient;
        Logger = logger;
    }

    protected async Task<T?> GetAsync<T>(string endpoint, CancellationToken cancellationToken = default)
    {
        using var activity = ActivitySource.StartActivity($"GET {endpoint}");
        
        Logger.LogDebug("GET request to {Endpoint}", endpoint);
        var response = await HttpClient.GetAsync(endpoint, cancellationToken);

        return await ProcessResponseAsync<T>(response);
    }

    protected async Task<T?> PostAsync<T>(string endpoint, object request, CancellationToken cancellationToken = default)
    {
        using var activity = ActivitySource.StartActivity($"POST {endpoint}");
        
        var json = JsonSerializer.Serialize(request, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

        Logger.LogDebug("POST request to {Endpoint}", endpoint);
        var response = await HttpClient.PostAsync(endpoint, content, cancellationToken);

        return await ProcessResponseAsync<T>(response);
    }

    protected async Task<T?> PutAsync<T>(string endpoint, object request, CancellationToken cancellationToken = default)
    {
        using var activity = ActivitySource.StartActivity($"PUT {endpoint}");
        
        var json = JsonSerializer.Serialize(request, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

        Logger.LogDebug("PUT request to {Endpoint}", endpoint);
        var response = await HttpClient.PutAsync(endpoint, content, cancellationToken);

        return await ProcessResponseAsync<T>(response);
    }

    private async Task<T?> ProcessResponseAsync<T>(HttpResponseMessage response)
    {
        if (!response.IsSuccessStatusCode)
        {
            var error = await response.Content.ReadAsStringAsync();
            Logger.LogError("HTTP {StatusCode}: {Error}", response.StatusCode, error);
            throw new HttpRequestException($"HTTP {response.StatusCode}: {error}");
        }

        var json = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<T>(json, new JsonSerializerOptions 
        { 
            PropertyNameCaseInsensitive = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        });
    }
}