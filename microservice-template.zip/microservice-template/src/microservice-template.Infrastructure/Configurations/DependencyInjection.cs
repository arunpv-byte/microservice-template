using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using microservice_template.Application.Interfaces;
using microservice_template.Infrastructure.Persistence;
using microservice_template.Infrastructure.Repositories;
using microservice_template.Infrastructure.ExternalServices.Configuration;
using microservice_template.Infrastructure.ExternalServices.Clients;
using microservice_template.Infrastructure.Messaging;
using microservice_template.Infrastructure.Services;
using microservice_template.Infrastructure.Configuration;

namespace microservice_template.Infrastructure.Configurations;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddScoped<ICardholderRepository, CardholderRepository>();
        services.AddScoped<DatabaseInitializer>();
        services.AddExternalServices(configuration);
        services.AddNymCardService(configuration);
        services.AddMessaging();
        services.AddHttpClient<IOAuthTokenService, OAuthTokenService>();
        services.AddScoped<ISecureConfigurationService, SecureConfigurationService>();

        // Register correlation ID service
        services.AddHttpContextAccessor();
        services.AddScoped<ICorrelationIdService, CorrelationIdService>();

        return services;
    }

    private static IServiceCollection AddMessaging(this IServiceCollection services)
    {
        services.AddScoped<IMessagePublisher, InMemoryMessagePublisher>();
        return services;
    }

    private static IServiceCollection AddNymCardService(this IServiceCollection services, IConfiguration configuration)
    {
        Console.WriteLine("AddNymCardService method called");

        // Register HttpClient with immediate synchronous configuration
        services.AddHttpClient<INymCardService, NymCardService>(client =>
        {
            Console.WriteLine("HttpClient configuration delegate called");
            ConfigureServiceAuthSync(client, configuration, "NymCard");
        });

        Console.WriteLine("NymCardService registered");

        return services;
    }

    private static void ConfigureServiceAuthSync(HttpClient client, IConfiguration configuration, string serviceName)
    {
        Console.WriteLine($"Configuring auth for service: {serviceName}");

        var config = configuration.GetSection($"ThirdPartyServices:{serviceName}");
        var baseUrl = config["BaseUrl"];
        if (!string.IsNullOrEmpty(baseUrl))
        {
            client.BaseAddress = new Uri(baseUrl);
        }
        client.Timeout = TimeSpan.FromSeconds(30);

        var authType = config["AuthType"]?.ToLower();
        Console.WriteLine($"Auth type for {serviceName}: {authType}");

        // Check if running in AWS environment
        var useAwsSecrets = !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("AWS_REGION"));

        switch (authType)
        {
            case "apikey":
                var apiKey = useAwsSecrets ? 
                    GetAwsParameterSync($"/microservice-template/{serviceName.ToLower()}/api-key") ?? config["ApiKey"] :
                    config["ApiKey"];
                if (!string.IsNullOrEmpty(apiKey))
                {
                    client.DefaultRequestHeaders.Add("apikey", apiKey);
                    Console.WriteLine($"Added API Key for {serviceName}");
                }
                break;
            case "bearer":
                var token = useAwsSecrets ?
                    GetAwsParameterSync($"/microservice-template/{serviceName.ToLower()}/token") ?? config["Token"] :
                    config["Token"];
                if (!string.IsNullOrEmpty(token))
                {
                    client.DefaultRequestHeaders.Authorization =
                        new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
                    Console.WriteLine($"Added Bearer token for {serviceName}");
                }
                break;
            case "basic":
                var username = useAwsSecrets ?
                    GetAwsParameterSync($"/microservice-template/{serviceName.ToLower()}/username") ?? config["Username"] :
                    config["Username"];
                var password = useAwsSecrets ?
                    GetAwsParameterSync($"/microservice-template/{serviceName.ToLower()}/password") ?? config["Password"] :
                    config["Password"];
                if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password))
                {
                    var credentials = Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes($"{username}:{password}"));
                    client.DefaultRequestHeaders.Authorization =
                        new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", credentials);
                    Console.WriteLine($"Added Basic auth for {serviceName}");
                }
                break;
            case "oauth_client_credentials":
            case "oauth_password":
                // OAuth tokens are handled at runtime via delegating handler
                Console.WriteLine($"OAuth {authType} configured for {serviceName} - tokens handled at runtime");
                break;
            default:
                Console.WriteLine($"No auth configured for {serviceName}");
                break;
        }
    }

    private static string GetAwsParameterSync(string parameterName)
    {
        try
        {
            using var ssmClient = new Amazon.SimpleSystemsManagement.AmazonSimpleSystemsManagementClient();
            var request = new Amazon.SimpleSystemsManagement.Model.GetParameterRequest
            {
                Name = parameterName,
                WithDecryption = true
            };
            var response = ssmClient.GetParameterAsync(request).GetAwaiter().GetResult();
            return response.Parameter.Value;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed to get AWS parameter {parameterName}: {ex.Message}");
            return null;
        }
    }

    public static async Task ConfigureServiceAuth(HttpClient client, IConfiguration configuration, string serviceName)
    {
        Console.WriteLine($"Configuring auth for service: {serviceName}");

        var config = configuration.GetSection($"ThirdPartyServices:{serviceName}");
        client.BaseAddress = new Uri(config["BaseUrl"]);
        client.Timeout = TimeSpan.FromSeconds(30);

        var authType = config["AuthType"]?.ToLower();
        Console.WriteLine($"Auth type for {serviceName}: {authType}");

        // For AWS secrets, we'll use environment-based detection
        var useAwsSecrets = !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("AWS_REGION"));

        switch (authType)
        {
            case "apikey":
                var apiKey = useAwsSecrets ?
                   !string.IsNullOrEmpty(await GetAwsParameter($"/microservice-template/{serviceName.ToLower()}/api-key")) ?
                   await GetAwsParameter($"/microservice-template/{serviceName.ToLower()}/api-key") : config["ApiKey"] :
                    config["ApiKey"];
                client.DefaultRequestHeaders.Add("apikey", apiKey);
                Console.WriteLine($"Added API Key for {serviceName}");
                break;
            case "bearer":
                var token = useAwsSecrets ?
                    await GetAwsParameter($"/microservice-template/{serviceName.ToLower()}/token") :
                    config["Token"];
                client.DefaultRequestHeaders.Authorization =
                    new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
                Console.WriteLine($"Added Bearer token for {serviceName}");
                break;
            case "basic":
                var username = useAwsSecrets ?
                    await GetAwsParameter($"/microservice-template/{serviceName.ToLower()}/username") :
                    config["Username"];
                var password = useAwsSecrets ?
                    await GetAwsParameter($"/microservice-template/{serviceName.ToLower()}/password") :
                    config["Password"];
                var credentials = Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes($"{username}:{password}"));
                client.DefaultRequestHeaders.Authorization =
                    new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", credentials);
                Console.WriteLine($"Added Basic auth for {serviceName}");
                break;
            case "oauth_client_credentials":
                // OAuth handled at runtime via delegating handler
                Console.WriteLine($"OAuth client credentials configured for {serviceName}");
                break;
            case "oauth_password":
                // OAuth handled at runtime via delegating handler
                Console.WriteLine($"OAuth password grant configured for {serviceName}");
                break;
            default:
                Console.WriteLine($"No auth configured for {serviceName}");
                break;
        }
    }

    private static async Task<string> GetAwsParameter(string parameterName)
    {
        try
        {
            using var ssmClient = new Amazon.SimpleSystemsManagement.AmazonSimpleSystemsManagementClient();
            var request = new Amazon.SimpleSystemsManagement.Model.GetParameterRequest
            {
                Name = parameterName,
                WithDecryption = true
            };
            var response = await ssmClient.GetParameterAsync(request);
            return response.Parameter.Value;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed to get AWS parameter {parameterName}: {ex.Message}");
            return null;
        }
    }
}