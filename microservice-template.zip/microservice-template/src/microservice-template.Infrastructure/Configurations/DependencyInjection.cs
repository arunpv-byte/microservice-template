using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using microservice_template.Application.Interfaces;
using microservice_template.Infrastructure.Persistence;
using microservice_template.Infrastructure.Repositories;
using microservice_template.Infrastructure.ExternalServices.Configuration;
using microservice_template.Infrastructure.ExternalServices.Clients;
using microservice_template.Infrastructure.ExternalServices.Abstractions;
using microservice_template.Infrastructure.Messaging;

namespace microservice_template.Infrastructure.Configurations;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddScoped<ICardholderRepository, CardholderRepository>();
        services.AddSingleton<DatabaseInitializer>();
        services.AddExternalServices(configuration);
        services.AddNymCardService(configuration);
        services.AddMessaging();

        return services;
    }

    private static IServiceCollection AddMessaging(this IServiceCollection services)
    {
        services.AddScoped<IMessagePublisher, InMemoryMessagePublisher>();
        return services;
    }

    private static IServiceCollection AddNymCardService(this IServiceCollection services, IConfiguration configuration)
    {
        Console.WriteLine("AddNymCardService method called");
        
        // Register HttpClient with configuration
        services.AddHttpClient<INymCardService, NymCardService>(client =>
        {
            Console.WriteLine("HttpClient configuration delegate called");
            ConfigureServiceAuth(client, configuration, "NymCard");
        });
        
        Console.WriteLine("NymCardService registered");
        
        return services;
    }

    public static void ConfigureServiceAuth(HttpClient client, IConfiguration configuration, string serviceName)
    {
        Console.WriteLine($"Configuring auth for service: {serviceName}");
        
        var config = configuration.GetSection($"ThirdPartyServices:{serviceName}");
        client.BaseAddress = new Uri(config["BaseUrl"] ?? "https://api.sand.platform.nymcard.com");
        client.Timeout = TimeSpan.FromSeconds(30);
        
        var authType = config["AuthType"]?.ToLower();
        Console.WriteLine($"Auth type for {serviceName}: {authType}");
        
        switch (authType)
        {
            case "apikey":
                client.DefaultRequestHeaders.Add("X-API-Key", config["ApiKey"]);
                Console.WriteLine($"Added API Key for {serviceName}");
                break;
            case "bearer":
                client.DefaultRequestHeaders.Authorization = 
                    new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", config["Token"]);
                Console.WriteLine($"Added Bearer token for {serviceName}");
                break;
            case "basic":
                var credentials = Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes($"{config["Username"]}:{config["Password"]}"));
                client.DefaultRequestHeaders.Authorization = 
                    new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", credentials);
                Console.WriteLine($"Added Basic auth for {serviceName}");
                break;
            default:
                Console.WriteLine($"No auth configured for {serviceName}");
                break;
        }
    }
}
