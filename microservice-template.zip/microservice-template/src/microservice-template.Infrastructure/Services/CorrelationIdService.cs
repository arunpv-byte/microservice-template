using Microsoft.AspNetCore.Http;
using microservice_template.Application.Interfaces;

namespace microservice_template.Infrastructure.Services;

public class CorrelationIdService : ICorrelationIdService
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public CorrelationIdService(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    public string GetCorrelationId()
    {
        return _httpContextAccessor.HttpContext?.Items["CorrelationId"]?.ToString() 
               ?? Guid.NewGuid().ToString();
    }

    public void SetCorrelationId(string correlationId)
    {
        if (_httpContextAccessor.HttpContext != null)
        {
            _httpContextAccessor.HttpContext.Items["CorrelationId"] = correlationId;
        }
    }
}