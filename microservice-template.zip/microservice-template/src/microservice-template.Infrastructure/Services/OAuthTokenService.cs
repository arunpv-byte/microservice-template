using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace microservice_template.Infrastructure.Services;

public interface IOAuthTokenService
{
    Task<string> GetTokenAsync(string tokenUrl, string clientId, string clientSecret, string grantType, string? username = null, string? password = null, string? scope = null);
}

public class OAuthTokenService : IOAuthTokenService
{
    private readonly HttpClient _httpClient;
    private readonly Dictionary<string, (string Token, DateTime Expiry)> _tokenCache = new();

    public OAuthTokenService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<string> GetTokenAsync(string tokenUrl, string clientId, string clientSecret, string grantType, string? username = null, string? password = null, string? scope = null)
    {
        var cacheKey = $"{tokenUrl}:{clientId}:{grantType}:{username}";
        
        if (_tokenCache.TryGetValue(cacheKey, out var cached) && cached.Expiry > DateTime.UtcNow.AddMinutes(5))
        {
            return cached.Token;
        }

        var parameters = new List<KeyValuePair<string, string>>
        {
            new("grant_type", grantType),
            new("client_id", clientId),
            new("client_secret", clientSecret)
        };

        if (grantType == "password" && !string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password))
        {
            parameters.Add(new("username", username));
            parameters.Add(new("password", password));
        }

        if (!string.IsNullOrEmpty(scope))
        {
            parameters.Add(new("scope", scope));
        }

        var content = new FormUrlEncodedContent(parameters);
        var response = await _httpClient.PostAsync(tokenUrl, content);
        response.EnsureSuccessStatusCode();

        var json = await response.Content.ReadAsStringAsync();
        var tokenResponse = JsonSerializer.Deserialize<TokenResponse>(json);

        var expiryTime = DateTime.UtcNow.AddSeconds(tokenResponse.ExpiresIn - 60);
        _tokenCache[cacheKey] = (tokenResponse.AccessToken, expiryTime);

        return tokenResponse.AccessToken;
    }

    private class TokenResponse
    {
        [JsonPropertyName("access_token")]
        public string AccessToken { get; set; } = string.Empty;
        
        [JsonPropertyName("expires_in")]
        public int ExpiresIn { get; set; }
    }
}