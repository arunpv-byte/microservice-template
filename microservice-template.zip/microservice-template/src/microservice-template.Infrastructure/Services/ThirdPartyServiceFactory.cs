using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using microservice_template.Application.Interfaces;
using microservice_template.Infrastructure.Configuration;

namespace microservice_template.Infrastructure.Services;

public class ThirdPartyServiceFactory : IThirdPartyServiceFactory
{
    private readonly IServiceProvider _serviceProvider;
    private readonly IConfiguration _configuration;

    public ThirdPartyServiceFactory(IServiceProvider serviceProvider, IConfiguration configuration)
    {
        _serviceProvider = serviceProvider;
        _configuration = configuration;
    }

    public T GetService<T>() where T : class
    {
        return _serviceProvider.GetRequiredService<T>();
    }
}