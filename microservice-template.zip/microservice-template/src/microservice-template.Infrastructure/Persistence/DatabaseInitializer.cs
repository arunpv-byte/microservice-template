using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using microservice_template.Infrastructure.Configuration;

namespace microservice_template.Infrastructure.Persistence;

public sealed class DatabaseInitializer
{
    private readonly ISecureConfigurationService _configService;
    private readonly ILogger<DatabaseInitializer> _logger;

    public DatabaseInitializer(ISecureConfigurationService configService, ILogger<DatabaseInitializer> logger)
    {
        _configService = configService;
        _logger = logger;
    }

    public async Task InitializeAsync()
    {
        try
        {
            var connectionString = await _configService.GetConnectionStringAsync("DefaultConnection");
            await using var connection = new SqlConnection(connectionString);
            await connection.OpenAsync();
            _logger.LogInformation("Database connection verified");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Database connection failed");
            throw;
        }
    }
}
