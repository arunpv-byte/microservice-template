using Microsoft.Extensions.Configuration;
using microservice_template.Infrastructure.Services;

namespace microservice_template.Infrastructure.Configuration;

public interface ISecureConfigurationService
{
    Task<string> GetConnectionStringAsync(string name);
    Task<string> GetThirdPartyServiceConfigAsync(string serviceName, string configKey);
}

public class SecureConfigurationService : ISecureConfigurationService
{
    private readonly IAwsSecretsService _awsSecretsService;
    private readonly IConfiguration _configuration;
    private readonly bool _useAwsSecrets;

    public SecureConfigurationService(IAwsSecretsService awsSecretsService, IConfiguration configuration)
    {
        _awsSecretsService = awsSecretsService;
        _configuration = configuration;
        _useAwsSecrets = !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("AWS_REGION"));
    }

    public async Task<string> GetConnectionStringAsync(string name)
    {
        if (_useAwsSecrets)
        {
            try
            {
                var awsConnectionString = await _awsSecretsService.GetParameterAsync("/microservice-template/database/connection-string");
                if (!string.IsNullOrEmpty(awsConnectionString))
                {
                    return awsConnectionString;
                }
            }
            catch
            {
                // Fallback to configuration
                return _configuration.GetConnectionString(name) ?? throw new InvalidOperationException($"Connection string '{name}' not found");
            }
        }
        
        return _configuration.GetConnectionString(name) ?? throw new InvalidOperationException($"Connection string '{name}' not found");
    }

    public async Task<string> GetThirdPartyServiceConfigAsync(string serviceName, string configKey)
    {
        if (_useAwsSecrets)
        {
            try
            {
                return await _awsSecretsService.GetParameterAsync($"/microservice-template/{serviceName.ToLower()}/{configKey.ToLower()}");
            }
            catch
            {
                // Fallback to configuration
            }
        }

        return _configuration[$"ThirdPartyServices:{serviceName}:{configKey}"] ?? throw new InvalidOperationException($"Config '{serviceName}:{configKey}' not found");
    }
}
