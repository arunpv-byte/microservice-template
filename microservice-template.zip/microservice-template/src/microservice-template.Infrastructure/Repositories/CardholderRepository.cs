using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using microservice_template.Application.Interfaces;
using microservice_template.Domain.Entities;
using microservice_template.Domain.Exceptions;
using microservice_template.Infrastructure.Configuration;
using System.Data;

namespace microservice_template.Infrastructure.Repositories;

public sealed class CardholderRepository : ICardholderRepository
{
    private readonly ISecureConfigurationService _secureConfig;

    public CardholderRepository(ISecureConfigurationService secureConfig)
    {
        _secureConfig = secureConfig;
    }

    public string GetCtsCredCentreId(string username = "", string deviceId = "")
    {
        var connectionString = _secureConfig.GetConnectionStringAsync("DefaultConnection").Result;
        using var connection = new SqlConnection(connectionString);
        using var command = new SqlCommand
        {
            Connection = connection,
            CommandType = CommandType.StoredProcedure,
            CommandText = "[CRUNCH_API_CTS_CredCheck]"
        };
        
        command.Parameters.Add("@userId", SqlDbType.NVarChar).Value = username;
        command.Parameters.Add("@DeviceId", SqlDbType.NVarChar).Value = deviceId;
        
        try
        {
            connection.Open();
            return Convert.ToString(command.ExecuteScalar()) ?? string.Empty;
        }
        catch (SqlException ex)
        {
            throw new InvalidOperationException($"Database error occurred while getting centre ID: {ex.Message}", ex);
        }
    }

    public int checkcardholderref(int client, string cardholderReference)
    {
        var connectionString = _secureConfig.GetConnectionStringAsync("DefaultConnection").Result;
        using var connection = new SqlConnection(connectionString);
        using var command = new SqlCommand
        {
            Connection = connection,
            CommandType = CommandType.StoredProcedure,
            CommandText = "[Crunch_sp_checkcardholder]"
        };
        
        command.Parameters.Add("@client", SqlDbType.Int).Value = client;
        command.Parameters.Add("@cardhlder_ref", SqlDbType.VarChar).Value = cardholderReference;
        
        try
        {
            connection.Open();
            return Convert.ToInt32(command.ExecuteScalar());
        }
        catch (SqlException ex)
        {
            throw new InvalidOperationException($"Database error occurred while checking cardholder reference: {ex.Message}", ex);
        }
    }

    public string GetParentUserId(string centreId)
    {
        var connectionString = _secureConfig.GetConnectionStringAsync("DefaultConnection").Result;
        using var connection = new SqlConnection(connectionString);
        using var command = new SqlCommand
        {
            Connection = connection,
            CommandType = CommandType.StoredProcedure,
            CommandText = "[Crunch_sp_client]"
        };
        
        command.Parameters.Add("@centre_id", SqlDbType.Int).Value = Convert.ToInt32(centreId);
        command.Parameters.Add("@Transtype", SqlDbType.Int).Value = 20;
        
        try
        {
            connection.Open();
            return Convert.ToString(command.ExecuteScalar()) ?? string.Empty;
        }
        catch (SqlException ex)
        {
            throw new InvalidOperationException($"Database error occurred while getting parent user ID: {ex.Message}", ex);
        }
    }

    public async Task<Cardholder> CreateAsync(Cardholder cardholder, CancellationToken cancellationToken)
    {
        const string sql = @"
            INSERT INTO gc_cardholder (CardholderRef, FirstName, LastName, EmailAddress, PhoneNumber, 
                DOB, AddressLine1, AddressLine2, Town, County, PostCode)
            VALUES (@cardholderReference, @firstName, @lastName, @emailAddress, @phoneNumber, 
            @dateOfBirth, @addressLine1, @addressLine2, @city, @country, @postalCode)
select gc_cardholder_id from gc_cardholder where CardholderRef = @cardholderReference
";

        try
        {
            var connectionString = await _secureConfig.GetConnectionStringAsync("DefaultConnection");
            await using var connection = new SqlConnection(connectionString);
            var newCardholderId = await connection.ExecuteScalarAsync<int>(sql, new
            {
                cardholder.cardholderReference,
                cardholder.firstName,
                cardholder.lastName,
                cardholder.emailAddress,
                cardholder.phoneNumber,
                cardholder.dateOfBirth,
                cardholder.addressLine1,
                cardholder.addressLine2,
                cardholder.city,
                cardholder.country,
                cardholder.postalCode
            });

            cardholder.cardholderId = Convert.ToString(newCardholderId);
            return cardholder;
        }
        catch (SqlException ex) when (ex.Number == 2627 || ex.Number == 2601) // Unique constraint violation
        {
            throw new ConflictException($"Cardholder with NymCardUserId '{cardholder.cardholderReference}' already exists");
        }
        catch (SqlException ex)
        {
            throw new InvalidOperationException($"Database error occurred while creating cardholder: {ex.Message}", ex);
        }
    }

    public async Task<Cardholder?> GetByNymCardUserIdAsync(string nymCardUserId, CancellationToken cancellationToken)
    {
        const string sql = @"
            SELECT gc_cardholder_id, CardHolderRef, FirstName, LastName, EmailAddress, PhoneNumber, DOB, 
    AddressLine1, Town, County, PostCode
FROM gc_cardholder
WHERE CardHolderRef = @NymCardUserId";

        try
        {
            var connectionString = await _secureConfig.GetConnectionStringAsync("DefaultConnection");
            await using var connection = new SqlConnection(connectionString);
            var dto = await connection.QuerySingleOrDefaultAsync<CardholderDto>(sql, new { NymCardUserId = nymCardUserId });
            return dto?.ToEntity();
        }
        catch (SqlException ex)
        {
            throw new InvalidOperationException($"Database error occurred while retrieving cardholder: {ex.Message}", ex);
        }
    }

    public async Task<Cardholder> UpdateAsync(Cardholder cardholder, CancellationToken cancellationToken)
    {
        const string sql = @"
            UPDATE gc_cardholder 
            SET EmailAddress = @emailAddress, PhoneNumber = @phoneNumber
            WHERE gc_cardholder_id = @cardholderId";

        try
        {
            var connectionString = await _secureConfig.GetConnectionStringAsync("DefaultConnection");
            await using var connection = new SqlConnection(connectionString);
            var rowsAffected = await connection.ExecuteAsync(sql, new
            {
                cardholder.cardholderId,
                cardholder.emailAddress,
                cardholder.phoneNumber,
            });

            if (rowsAffected == 0)
                throw new NotFoundException($"Cardholder with Id '{cardholder.cardholderReference}' not found");

            return cardholder;
        }
        catch (SqlException ex)
        {
            throw new InvalidOperationException($"Database error occurred while updating cardholder: {ex.Message}", ex);
        }
    }

    private sealed class CardholderDto
    {
        public string gc_cardholder_id { get; init; } = string.Empty;
        public string CardHolderRef { get; init; } = string.Empty;
        public string firstName { get; init; } = string.Empty;
        public string lastName { get; init; } = string.Empty;
        public string emailAddress { get; init; } = string.Empty;
        public string phoneNumber { get; init; } = string.Empty;
        public string DOB { get; init; } = string.Empty;
        public string addressLine1 { get; init; } = string.Empty;
        public string addressLine2 { get; init; } = string.Empty;
        public string Town { get; init; } = string.Empty;
        public string County { get; init; } = string.Empty;
        public string PostCode { get; init; } = string.Empty;

        public Cardholder ToEntity()
        {
            var cardholder = Cardholder.Create(gc_cardholder_id,CardHolderRef, firstName, lastName, emailAddress, phoneNumber,
                DOB, addressLine1, addressLine2, Town, County, PostCode);

            //typeof(Cardholder).GetProperty(nameof(Cardholder.Id))!.SetValue(cardholder, Id);
            //typeof(Cardholder).GetProperty(nameof(Cardholder.CreatedAt))!.SetValue(cardholder, CreatedAt);
            //typeof(Cardholder).GetProperty(nameof(Cardholder.UpdatedAt))!.SetValue(cardholder, UpdatedAt);

            return cardholder;
        }
    }
}
