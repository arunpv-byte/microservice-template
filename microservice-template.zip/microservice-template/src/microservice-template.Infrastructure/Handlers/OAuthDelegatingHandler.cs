using Microsoft.Extensions.Configuration;
using microservice_template.Infrastructure.Services;

namespace microservice_template.Infrastructure.Handlers;

public class OAuthDelegatingHandler : DelegatingHandler
{
    private readonly IOAuthTokenService _tokenService;
    private readonly IConfiguration _configuration;
    private readonly string _serviceName;

    public OAuthDelegatingHandler(IOAuthTokenService tokenService, IConfiguration configuration, string serviceName)
    {
        _tokenService = tokenService;
        _configuration = configuration;
        _serviceName = serviceName;
    }

    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var config = _configuration.GetSection($"ThirdPartyServices:{_serviceName}");
        var authType = config["AuthType"]?.ToLower();

        if (authType == "oauth_client_credentials" || authType == "oauth_password")
        {
            var token = await _tokenService.GetTokenAsync(
                config["TokenUrl"],
                config["ClientId"],
                config["ClientSecret"],
                authType == "oauth_client_credentials" ? "client_credentials" : "password",
                config["Username"],
                config["Password"],
                config["Scope"]);

            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        }

        return await base.SendAsync(request, cancellationToken);
    }
}