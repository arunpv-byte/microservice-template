using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using microservice_template.Application.Interfaces;
using microservice_template.Infrastructure.Caching;

namespace microservice_template.Infrastructure.Caching;

public static class CachingExtensions
{
    public static IServiceCollection AddCaching(this IServiceCollection services, IConfiguration configuration)
    {
        var cacheType = configuration["Caching:Type"] ?? "Memory";

        if (cacheType.Equals("Redis", StringComparison.OrdinalIgnoreCase))
        {
            var connectionString = configuration.GetConnectionString("Redis");
            services.AddStackExchangeRedisCache(options =>
            {
                options.Configuration = connectionString;
            });
        }
        else
        {
            services.AddDistributedMemoryCache();
        }

        services.AddScoped<ICacheService, RedisCacheService>();
        return services;
    }
}