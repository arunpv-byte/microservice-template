using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using OpenTelemetry.Metrics;
using OpenTelemetry.Exporter;

namespace microservice_template.API.Telemetry;

public static class TelemetryExtensions
{
    public static IServiceCollection AddTelemetry(this IServiceCollection services, IConfiguration configuration)
    {
        var serviceName = configuration["ServiceName"] ?? "microservice-template";
        var serviceVersion = configuration["ServiceVersion"] ?? "1.0.0";
        var newRelicApiKey = configuration["NewRelic:ApiKey"];
        var newRelicEndpoint = configuration["NewRelic:Endpoint"] ?? "https://otlp.nr-data.net:4317";

        services.AddOpenTelemetry()
            .WithTracing(builder =>
            {
                builder
                    .SetResourceBuilder(ResourceBuilder.CreateDefault()
                        .AddService(serviceName, serviceVersion)
                        .AddAttributes(new Dictionary<string, object>
                        {
                            ["service.instance.id"] = Environment.MachineName,
                            ["deployment.environment"] = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Development"
                        }))
                    .AddAspNetCoreInstrumentation(options =>
                    {
                        options.RecordException = true;
                        options.Filter = (httpContext) => !httpContext.Request.Path.StartsWithSegments("/health");
                    })
                    .AddHttpClientInstrumentation(options =>
                    {
                        options.RecordException = true;
                        options.FilterHttpRequestMessage = (httpRequestMessage) => 
                            !httpRequestMessage.RequestUri?.AbsolutePath.Contains("/health") == true;
                    })
                    .AddSqlClientInstrumentation(options =>
                    {
                        options.SetDbStatementForText = true;
                        options.RecordException = true;
                    })
                    .AddConsoleExporter();

                // Add New Relic exporter if API key is configured
                if (!string.IsNullOrEmpty(newRelicApiKey))
                {
                    builder.AddOtlpExporter(options =>
                    {
                        options.Endpoint = new Uri(newRelicEndpoint);
                        options.Headers = $"api-key={newRelicApiKey}";
                        options.Protocol = OtlpExportProtocol.Grpc;
                    });
                }
                else
                {
                    // Fallback to Jaeger for development
                    builder.AddJaegerExporter();
                }
            })
            .WithMetrics(builder =>
            {
                builder
                    .SetResourceBuilder(ResourceBuilder.CreateDefault()
                        .AddService(serviceName, serviceVersion)
                        .AddAttributes(new Dictionary<string, object>
                        {
                            ["service.instance.id"] = Environment.MachineName,
                            ["deployment.environment"] = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Development"
                        }))
                    .AddAspNetCoreInstrumentation()
                    .AddHttpClientInstrumentation()
                    .AddConsoleExporter();

                // Add New Relic metrics exporter if API key is configured
                if (!string.IsNullOrEmpty(newRelicApiKey))
                {
                    builder.AddOtlpExporter(options =>
                    {
                        options.Endpoint = new Uri(newRelicEndpoint);
                        options.Headers = $"api-key={newRelicApiKey}";
                        options.Protocol = OtlpExportProtocol.Grpc;
                    });
                }
            });

        return services;
    }
}