using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using microservice_template.Domain.Exceptions;

namespace microservice_template.API.Authentication;

public class CustomJwtHandler : AuthenticationHandler<AuthenticationSchemeOptions>
{
    private readonly IConfiguration _config;
    private readonly HttpClient _httpClient;

    public CustomJwtHandler(
        IOptionsMonitor<AuthenticationSchemeOptions> options,
        ILoggerFactory logger,
        UrlEncoder encoder,
        ISystemClock clock,
        IConfiguration config,
        HttpClient httpClient)
        : base(options, logger, encoder, clock)
    {
        _config = config;
        _httpClient = httpClient;
    }

    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var authHeader = Request.Headers["Authorization"].FirstOrDefault();

        if (string.IsNullOrWhiteSpace(authHeader) || !authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            return AuthenticateResult.NoResult();

        var token = authHeader.Substring("Bearer ".Length).Trim();

        var validator = new TokenValidator(_config, _httpClient, Logger);
        var principal = await validator.ValidateTokenAsync(token, Context);

        if (principal == null)
        {
            Logger.LogError("Invalid token");
            return AuthenticateResult.Fail("Invalid token");
        }

        return AuthenticateResult.Success(new AuthenticationTicket(principal, Scheme.Name));
    }
}

public class TokenValidator
{
    private readonly IConfiguration _config;
    private readonly HttpClient _httpClient;
    private readonly ILogger _logger;

    public TokenValidator(IConfiguration config, HttpClient httpClient, ILogger logger)
    {
        _config = config;
        _httpClient = httpClient;
        _logger = logger;
    }

    public async Task<ClaimsPrincipal?> ValidateTokenAsync(string token, HttpContext httpContext)
    {
        try
        {
            var handler = new JwtSecurityTokenHandler();

            if (!handler.CanReadToken(token))
                return null;

            var jwt = handler.ReadJwtToken(token);

            string issuer = jwt.Issuer;
            string azp = jwt.Claims.FirstOrDefault(c => c.Type == "azp")?.Value ?? string.Empty;
            string subject = jwt.Subject ?? string.Empty;

            if (string.IsNullOrEmpty(issuer) || string.IsNullOrEmpty(azp) || string.IsNullOrEmpty(subject))
                return null;

            // Validate issuer matches expected authority
            string expectedAuthority = _config["Keycloak:Authority"] ?? string.Empty;
            if (!issuer.Equals(expectedAuthority, StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogWarning("Invalid issuer: {Issuer}", issuer);
                return null;
            }

            var signingKeys = await GetSigningKeysAsync(issuer);
            var validationParams = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidIssuer = issuer,
                ValidateAudience = true,
                ValidAudience = _config["Keycloak:Audience"],
                ValidateLifetime = true,
                ClockSkew = TimeSpan.FromMinutes(5),
                ValidateIssuerSigningKey = true,
                IssuerSigningKeys = signingKeys
            };

            ClaimsPrincipal principal;
            try
            {
                principal = handler.ValidateToken(token, validationParams, out SecurityToken validatedToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Token validation failed");
                return null;
            }

            // Validate azp claim
            var allowedAzp = _config.GetSection("Keycloak:AllowedAzp").Get<string[]>() ?? Array.Empty<string>();
            if (!allowedAzp.Contains(azp))
            {
                _logger.LogWarning("Invalid azp claim: {Azp}", azp);
                return null;
            }

            // Validate sub claim pattern if configured
            var allowedSubPattern = _config["Keycloak:AllowedSubPattern"];
            if (!string.IsNullOrEmpty(allowedSubPattern) && !subject.Contains(allowedSubPattern))
            {
                _logger.LogWarning("Invalid sub claim pattern: {Sub}", subject);
                return null;
            }

            _logger.LogInformation("Token validation successful for azp: {Azp}, sub: {Sub}", azp, subject);
            return principal;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error during token validation");
            return null;
        }
    }

    private async Task<IEnumerable<SecurityKey>> GetSigningKeysAsync(string issuer)
    {
        try
        {
            string jwksUrl = $"{issuer.TrimEnd('/')}/protocol/openid-connect/certs";
            var response = await _httpClient.GetStringAsync(jwksUrl);

            var keys = new List<SecurityKey>();
            var jwks = JObject.Parse(response)["keys"];

            if (jwks != null)
            {
                foreach (var key in jwks)
                {
                    var e = Base64UrlEncoder.DecodeBytes(key["e"]?.ToString() ?? string.Empty);
                    var n = Base64UrlEncoder.DecodeBytes(key["n"]?.ToString() ?? string.Empty);

                    var rsa = new System.Security.Cryptography.RSACryptoServiceProvider();
                    rsa.ImportParameters(new System.Security.Cryptography.RSAParameters { Exponent = e, Modulus = n });

                    keys.Add(new RsaSecurityKey(rsa) { KeyId = key["kid"]?.ToString() ?? string.Empty });
                }
            }

            return keys;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Failed to fetch signing keys from {JwksUrl}", $"{issuer}/protocol/openid-connect/certs");
            throw new ExternalServiceException("Failed to fetch signing keys", ex);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error while processing signing keys");
            throw;
        }
    }
}