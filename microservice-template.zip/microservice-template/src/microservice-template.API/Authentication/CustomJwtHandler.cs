using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using microservice_template.Domain.Exceptions;
using System.Data;
using Microsoft.Data.SqlClient;
using microservice_template.Infrastructure.Configuration;
using Dapper;

namespace microservice_template.API.Authentication;

public class CustomJwtHandler : AuthenticationHandler<AuthenticationSchemeOptions>
{
    private readonly IConfiguration _config;
    private readonly HttpClient _httpClient;
    private readonly ISecureConfigurationService _secureConfig;

    public CustomJwtHandler(
        IOptionsMonitor<AuthenticationSchemeOptions> options,
        ILoggerFactory logger,
        UrlEncoder encoder,
        ISystemClock clock,
        IConfiguration config,
        HttpClient httpClient,
        ISecureConfigurationService secureConfig
        )
        : base(options, logger, encoder, clock)
    {
        _config = config;
        _httpClient = httpClient;
        _secureConfig = secureConfig;
    }

    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var authHeader = Request.Headers["Authorization"].FirstOrDefault();

        if (string.IsNullOrWhiteSpace(authHeader) || !authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            return AuthenticateResult.NoResult();

        var token = authHeader.Substring("Bearer ".Length).Trim();

        var validator = new TokenValidator(_config, _httpClient, Logger, _secureConfig);
        var principal = await validator.ValidateTokenAsync(token, Context);

        if (principal == null)
        {
            Logger.LogError("Invalid token");
            return AuthenticateResult.Fail("Invalid token");
        }

        return AuthenticateResult.Success(new AuthenticationTicket(principal, Scheme.Name));
    }
}

public class TokenValidator
{
    private readonly IConfiguration _config;
    private readonly HttpClient _httpClient;
    private readonly ILogger _logger;
    private readonly ISecureConfigurationService _secureConfig;
    private readonly List<KeyCloakClientCredDetail> _clientCredDetails;
    private readonly string _realm;
    public TokenValidator(IConfiguration config, HttpClient httpClient, ILogger logger,
        ISecureConfigurationService secureConfig)
    {
        _config = config;
        _httpClient = httpClient;
        _logger = logger;
        _secureConfig = secureConfig;
        _clientCredDetails = config.GetSection("KeyCloakClientDetails").Get<List<KeyCloakClientCredDetail>>();
        _realm = _config["KeyCloakCreds:realm"];
    }

    public async Task<ClaimsPrincipal?> ValidateTokenAsync(string token, HttpContext httpContext)
    {
        try
        {
            var handler = new JwtSecurityTokenHandler();

            if (!handler.CanReadToken(token))
                return null;

            var jwt = handler.ReadJwtToken(token);

            string issuer = jwt.Issuer;
            string azp = jwt.Claims.FirstOrDefault(c => c.Type == "azp")?.Value ?? string.Empty;
            string subject = jwt.Subject ?? string.Empty;

            if (string.IsNullOrEmpty(issuer) || string.IsNullOrEmpty(azp) || string.IsNullOrEmpty(subject))
                return null;

            // Validate issuer matches expected authority
            string expectedAuthority = _config["Keycloak:Authority"] ?? string.Empty;
            if (!issuer.Equals(expectedAuthority, StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogWarning("Invalid issuer: {Issuer}", issuer);
                return null;
            }

            var signingKeys = await GetSigningKeysAsync(issuer);
            var validationParams = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidIssuer = issuer,
                ValidateAudience = false,
                ValidateLifetime = true,
                ClockSkew = TimeSpan.FromMinutes(5),
                ValidateIssuerSigningKey = true,
                IssuerSigningKeys = signingKeys
            };

            ClaimsPrincipal principal;
            try
            {
                principal = handler.ValidateToken(token, validationParams, out SecurityToken validatedToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Token validation failed");
                return null;
            }

            string keyCloakUserId = principal.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(keyCloakUserId))
                return null;

            var claims = principal.Claims
                        .GroupBy(c => c.Type)
                        .ToDictionary(g => g.Key, g => g.First().Value);

            bool isClientCredentials = claims.ContainsKey("client_id");

            if (isClientCredentials)
            {
                var clientId = claims["client_id"];
                var tokenAzp = claims.ContainsKey("azp") ? claims["azp"] : null;

                var config = _config.GetSection("KeyCloakClientDetails")
                                    .Get<List<KeyCloakClientCredDetails>>()
                                    .FirstOrDefault(c =>
                                        c.realm == ExtractRealmFromIssuer(issuer)?.Trim() &&
                                        c.azp == tokenAzp &&
                                        c.sub == keyCloakUserId);

                if (config == null)
                {
                    _logger.LogError("Invalid client credentials token");
                    return null;
                }

                var isSuperUser = _config.GetSection("KeyCloakClientDetails")
                                  .Get<List<KeyCloakClientCredDetails>>()
                                  .FirstOrDefault(c =>
                                      c.realm == ExtractRealmFromIssuer(issuer)?.Trim() &&
                                      c.azp == tokenAzp &&
                                      c.sub == keyCloakUserId &&
                                      c.isSuper == true);

                if (isSuperUser != null)
                {
                    httpContext.Items["isKeycloakSuperUser"] = true;
                }
                else
                {
                    httpContext.Items["isKeycloakSuperUser"] = false;
                }

                httpContext.Items["IsCrunchApiClient"] = true;
                httpContext.Items["KeycloakClientId"] = clientId;
            }
            else
            {
                var tokenAzp = principal.Claims.FirstOrDefault(c => c.Type == "azp")?.Value;
                if (string.IsNullOrEmpty(tokenAzp))
                    return null;

                using IDbConnection db = new SqlConnection(await _secureConfig.GetConnectionStringAsync("DefaultConnection"));

                string sql = @"
                                SELECT COUNT(1)
                                FROM CRN_EndUsers
                                WHERE keycloak_user_id = @UserId
                                  AND keycloak_realm = @Realm
                                  AND (
                                        application_name = @ClientId
                                        OR application_name IN @AllowedAzps
                                      )";

                string realm = ExtractRealmFromIssuer(issuer)?.Trim();

                var allowedAzps = _clientCredDetails
                    .Where(x => string.Equals(x.realm, realm, StringComparison.OrdinalIgnoreCase))
                    .Select(x => x.azp)
                    .ToList();

                int exists = await db.ExecuteScalarAsync<int>(sql, new
                {
                    UserId = keyCloakUserId?.Trim(),
                    Realm = realm,
                    ClientId = tokenAzp?.Trim(),
                    AllowedAzps = allowedAzps
                });

                if (exists == 0)
                    return null;


                httpContext.Items["IsCrunchApiClient"] = false;

                if (realm == _realm)
                {
                    httpContext.Items["IsCrunchApiPublic"] = true;
                }
                else
                {
                    httpContext.Items["IsCrunchApiPublic"] = false;
                }
            }

            httpContext.Items["KeyCloakUserId"] = keyCloakUserId;

            return principal;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error during token validation");
            return null;
        }
    }

    private async Task<IEnumerable<SecurityKey>> GetSigningKeysAsync(string issuer)
    {
        try
        {
            string jwksUrl = $"{issuer.TrimEnd('/')}/protocol/openid-connect/certs";
            var response = await _httpClient.GetStringAsync(jwksUrl);

            var keys = new List<SecurityKey>();
            var jwks = JObject.Parse(response)["keys"];

            if (jwks != null)
            {
                foreach (var key in jwks)
                {
                    var e = Base64UrlEncoder.DecodeBytes(key["e"]?.ToString() ?? string.Empty);
                    var n = Base64UrlEncoder.DecodeBytes(key["n"]?.ToString() ?? string.Empty);

                    var rsa = new System.Security.Cryptography.RSACryptoServiceProvider();
                    rsa.ImportParameters(new System.Security.Cryptography.RSAParameters { Exponent = e, Modulus = n });

                    keys.Add(new RsaSecurityKey(rsa) { KeyId = key["kid"]?.ToString() ?? string.Empty });
                }
            }

            return keys;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Failed to fetch signing keys from {JwksUrl}", $"{issuer}/protocol/openid-connect/certs");
            throw new ExternalServiceException("Failed to fetch signing keys", ex);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error while processing signing keys");
            throw;
        }
    }

    private string ExtractRealmFromIssuer(string issuer)
    {
        var parts = issuer.Split("/realms/");
        return parts.Length > 1 ? parts[1] : issuer;
    }
}

public class KeyCloakClientCredDetails
{
    public string realm { get; set; }
    public string azp { get; set; }
    public string sub { get; set; }
    public bool isSuper { get; set; }
}

public class KeyCloakClientCredDetail
{
    public string realm { get; set; }
    public string azp { get; set; }
    public string sub { get; set; }
}
