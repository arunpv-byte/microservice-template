using microservice_template.Application.Validators;
using System.ComponentModel.DataAnnotations;

namespace microservice_template.API.Contracts.Cardholder
{
    public class UpdateCardholderRequest
    {
        /// <summary>
        /// emailAddress, specifies the cardholder's email contact information.<br/>        
        /// <b>Ensure that the provided email address follows the standard email format.</b>
        /// **Conditional**
        /// ##11##
        /// </summary>
        /// <example>example@example.com</example>
        [StringLength(60)]
        [EmailValidation]
        public string? emailAddress { get; set; }

        /// <summary>
        /// phoneNumber represents the cardholder's mobile contact information. <br/>
        /// phone number Format: [+][CountryCode][-][Phone number].<br/>
        ///  <b>Ensure that the provided phone number follows formatting rules or conventions specified by the system.</b><br/>
        ///  **Conditional**
        ///  ##10##
        /// </summary>
        /// <example>+44-1234567890</example>
        [StringLength(15)]
        [PhoneNumber]
        public string? phoneNumber { get; set; }
    }
}
