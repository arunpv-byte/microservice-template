using microservice_template.Application.Validators;
using System.ComponentModel.DataAnnotations;

namespace microservice_template.API.Contracts.Cardholder
{
    public class CreateCardholderRequest
    {
        /// <summary>
        /// Cardholder's Title, specifies the honorific or professional designation associated with the cardholder. There are six possible values corresponding to different titles.<br/>
        /// Mr <br/>
        /// Mrs <br/> 
        /// Miss <br/>
        /// Ms <br/>
        /// Dr <br/>
        /// Rev<br/>
        /// Ensure that the provided title value matches one of the possible values listed above.
        /// </summary>
        /// <example>Mr</example>
        [StringLength(5, MinimumLength = 1)]
        [Required]
        public string title
        {
            get;
            set;
        }
        /// <summary>
        /// firstName, specifies the first name of the cardholder. <br/><br/>
        /// The first name is a mandatory field for creating a cardholder, except for clients categorized under "Till Category". <br/>Please obtain the category information from the help desk or administrator.
        /// **Conditional**
        /// ##1##
        /// </summary>
        /// <example>James</example>
        [StringLength(20, MinimumLength = 0)]
        public string firstName { get; set; }

        /// <summary>
        /// lastName , specifies the surname or last name of the cardholder.<br/><br/>
        /// The lastName is a mandatory field for creating a cardholder, except for clients categorized under "Till Category". <br/>Please obtain the category information from the help desk or administrator.
        /// **Conditional**
        /// ##1##
        /// </summary>
        /// <example>Jacob</example>
        [StringLength(20, MinimumLength = 0)]
        public string lastName { get; set; }

        /// <summary>
        /// The gender of the cardholder.There are three possible values corresponding to different gender.<br/>
        /// M: Male <br/>
        /// F: Female <br/> 
        /// " ": Not specified <br/>
        /// <b>Ensure that the provided gender value matches one of the possible values listed above.</b>
        /// ##1##
        /// </summary>
        /// <example>M</example>
        [StringLength(1, MinimumLength = 0)]
        public string gender { get; set; }

        /// <summary>
        /// emailAddress, specifies the cardholder's email contact information.<br/>        
        /// <b>Ensure that the provided email address follows the standard email format.</b>
        /// **Conditional**
        /// ##11##
        /// </summary>
        /// <example>example@example.com</example>
        [StringLength(60, MinimumLength = 0)]
        [EmailValidation]
        public string emailAddress { get; set; }

        /// <summary>
        /// phoneNumber represents the cardholder's mobile contact information. <br/>
        /// phone number Format: [+][CountryCode][-][Phone number].<br/>
        ///  <b>Ensure that the provided phone number follows formatting rules or conventions specified by the system.</b><br/>
        ///  **Conditional**
        ///  ##10##
        /// </summary>
        /// <example>+44-1234567890</example>
        [StringLength(15, MinimumLength = 0)]
        [PhoneNumber]
        public string phoneNumber { get; set; }

        /// <summary>
        /// The cardholder's date of birth.<br/>
        /// The date of birth is a mandatory field for creating a cardholder, except for clients categorized under "Till Category". Please obtain the category information from the help desk or administrator.<br/>     
        ///Ensure that the provided Date of Birth follows the YYYY-MM-DD format.
        ///**Conditional**
        /// </summary>
        /// <example>1993-09-26</example>
        [StringLength(10, MinimumLength = 10)]
        public string dateOfBirth { get; set; }

        /// <summary>
        /// addressLine1, specifies the first line of the cardholder's address.<br/>
        /// ##1##
        /// </summary>
        ///<example>Rose Garden</example>
        [StringLength(50, MinimumLength = 0)]
        public string addressLine1 { get; set; }

        /// <summary>
        /// addressLine2, specifies the second line of the cardholder's address.<br/>
        /// ##1##
        /// </summary>
        ///<example>Rose Garden</example>
        [StringLength(50, MinimumLength = 0)]
        public string addressLine2 { get; set; }

        /// <summary>
        /// city, specifies the town or city where the cardholder resides.<br/>
        /// Also used as the card purchaser's city if no delivery address is supplied.<br/>
        /// Mandatory if "addressLine1" is present, and "postcode" is not present.
        /// **Conditional**
        /// ##1##
        /// </summary>
        /// <example>Rose Valley</example>
        [StringLength(20, MinimumLength = 0)]
        public string city { get; set; }

        /// <summary>
        ///  Cardholder’s country of residence.This is represented as a <a href="https://en.wikipedia.org/wiki/List_of_ISO_3166_country_codes" target="_blank">3 digit ISO country code</a>.
        ///  Country code is a mandatory field for creating a cardholder, except for clients categorized under "Till Category". Please obtain the category information from the help desk or administrator.
        ///  **Conditional**
        ///  ##3##
        /// </summary>
        /// <example>826</example>
        [StringLength(3, MinimumLength = 0)]
        public string country { get; set; }

        /// <summary>
        /// Cardholder's home postcode <br/>
        /// Mandatory if "addressLine1" is present, and "city" is not present.
        /// <br/><br/>
        /// Only the following characters are allowed:<br/>
        /// * Arabic numerals (0–9)<br/>
        /// * ISO basic Latin letters (A–Z, a–z)<br/>
        /// * Spaces<br/>
        /// * Hyphens (-)
        /// **Conditional**
        /// ##1##
        /// </summary>
        /// <example>PO16 7GZ</example>
        [StringLength(20, MinimumLength = 0)]
        public string postalCode { get; set; }

        /// <summary>
        /// Login username obtained from Crunch Admin Tool .<br/>
        /// The login username obtained from the Crunch Admin Tool  is used to populate the "userName" parameter, 
        /// which is only required for clients categorized under the "Till Category".<br/> 
        /// This parameter signifies the user who logged in and created the cardholder.
        /// **Conditional**
        /// ##1##
        /// </summary>
        [StringLength(20, MinimumLength = 0)]
        [Required]
        public string username { get; set; }

        /// <summary>
        ///The deviceId represents the unique identifier or serial number associated with the device, obtained from the Crunch admin tool.<br/><br/>
        ///  This parameter is only required for clients categorized under the "Till Category".<br/>
        /// **Conditional**
        /// ##6##
        /// </summary>
        /// <example>678</example>
        [StringLength(200, MinimumLength = 0)]
        [Required]
        public string deviceId { get; set; }
    }
}
