using Microsoft.AspNetCore.Mvc;
using microservice_template.Application.Interfaces;

namespace microservice_template.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TestController : ControllerBase
{
    private readonly IThirdPartyServiceFactory _serviceFactory;

    public TestController(IThirdPartyServiceFactory serviceFactory)
    {
        _serviceFactory = serviceFactory;
    }

    [HttpGet("trigger-auth")]
    public IActionResult TriggerAuth()
    {
        Console.WriteLine("TriggerAuth called");
        var service = _serviceFactory.GetService<INymCardService>();
        Console.WriteLine($"Service type: {service.GetType().Name}");
        
        // Force HttpClient creation by accessing it
        var httpClientField = service.GetType().GetField("HttpClient", 
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
        if (httpClientField != null)
        {
            var httpClient = httpClientField.GetValue(service);
            Console.WriteLine($"HttpClient: {httpClient?.GetType().Name}");
        }
        
        return Ok("HttpClient accessed - check console");
    }
}