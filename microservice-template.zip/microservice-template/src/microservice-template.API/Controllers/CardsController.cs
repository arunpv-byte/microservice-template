using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using microservice_template.Application.Features.Cards.GetCardBalance;

namespace microservice_template.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(AuthenticationSchemes = "CustomJwt")]
public sealed class CardsController : ControllerBase
{
    private readonly IMediator _mediator;

    public CardsController(IMediator mediator)
    {
        _mediator = mediator;
    }

    [HttpGet("{accountId}/balance")]
    [ProducesResponseType(typeof(GetCardBalanceResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetCardBalance(
        [FromRoute] string accountId,
        CancellationToken cancellationToken)
    {
        var query = new GetCardBalanceQuery(accountId);
        var response = await _mediator.Send(query, cancellationToken);
        return Ok(response);
    }
}