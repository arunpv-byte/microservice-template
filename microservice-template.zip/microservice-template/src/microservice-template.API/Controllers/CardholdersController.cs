using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Asp.Versioning;
using microservice_template.Application.Features.Cardholders.CreateCardholder;
using microservice_template.Application.Features.Cardholders.GetCardholder;
using microservice_template.Application.Features.Cardholders.UpdateCardholder;
using microservice_template.API.Contracts.Cardholder;
using System.ComponentModel.DataAnnotations;

namespace microservice_template.API.Controllers;

/// <summary>
/// Cardholder management operations
/// </summary>
/// <remarks>
/// Provides endpoints for creating, retrieving, and updating cardholder information
/// integrated with NymCard platform for comprehensive cardholder lifecycle management.
/// </remarks>
[ApiController]
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/[controller]")]
[Authorize(AuthenticationSchemes = "CustomJwt")]
[Produces("application/json")]
[Tags("Cardholders")]
public sealed class CardholdersController : ControllerBase
{
    private readonly IMediator _mediator;

    public CardholdersController(IMediator mediator)
    {
        _mediator = mediator;
    }

    /// <summary>
    /// Retrieve cardholder information
    /// </summary>
    /// <param name="cardholderReference">The unique cardholder reference</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>Cardholder details including personal information and status</returns>
    /// <response code="200">Cardholder information retrieved successfully</response>
    /// <response code="404">Cardholder not found</response>
    /// <response code="401">Unauthorized - Invalid or missing JWT token</response>
    /// <response code="500">Internal server error</response>
    [HttpGet("{cardholderReference}")]
    [ProducesResponseType(typeof(GetCardholderResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> GetCardholder(
        [FromRoute] [Required] string cardholderReference,
        CancellationToken cancellationToken)
    {
        var query = new GetCardholderQuery(cardholderReference);
        var response = await _mediator.Send(query, cancellationToken);
        return Ok(response);
    }

    /// <summary>
    /// Create a new cardholder
    /// </summary>
    /// <param name="request">Cardholder creation details including personal information and contact details</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>Created cardholder information with assigned user ID</returns>
    /// <remarks>
    /// Creates a new cardholder.
    /// All required fields must be provided and will be validated before processing.
    /// 
    /// Sample request:
    /// 
    ///     POST /api/v1/cardholders
    ///     {
    ///         "firstName": "John",
    ///         "lastName": "Doe",
    ///         "emailAddress": "john.doe@example.com",
    ///         "phoneNumber": "+1234567890",
    ///         "dateOfBirth": "1990-01-01",
    ///         "addressLine1": "123 Main Street",
    ///         "addressLine2": "Apt 4B",
    ///         "city": "New York",
    ///         "country": "USA",
    ///         "postalCode": "10001",
    ///         "username": "johndoe",
    ///         "deviceId": "device123",
    ///         "title": "Mr",
    ///         "gender": "M"
    ///     }
    /// </remarks>
    /// <response code="200">Cardholder created successfully</response>
    /// <response code="400">Invalid request data or validation errors</response>
    /// <response code="401">Unauthorized - Invalid or missing JWT token</response>
    /// <response code="409">Conflict - Cardholder already exists</response>
    /// <response code="502">Bad Gateway - External service error</response>
    /// <response code="500">Internal server error</response>
    [HttpPost]
    [ProducesResponseType(typeof(CreateCardholderResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    [ProducesResponseType(StatusCodes.Status502BadGateway)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> CreateCardholder(
        [FromBody] [Required] CreateCardholderRequest request,
        CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        var command = new CreateCardholderCommand(
           request.firstName,
           request.lastName,
           request.emailAddress,
           request.phoneNumber,
           request.dateOfBirth,
           request.addressLine1,
           request.addressLine2,
           "",
           request.city,
           request.country,
           request.postalCode,
           request.username,
           request.deviceId,
           request.title,
           "",
           "",
           request.gender
       );

        var response = await _mediator.Send(command, cancellationToken);

        if(string.IsNullOrWhiteSpace(response.cardholderReference))
        {
            return BadRequest("Cardholder creation failed");
        }
        return Ok(response);
    }

    /// <summary>
    /// Update existing cardholder information
    /// </summary>
    /// <param name="cardholderReference">The unique cardholder reference</param>
    /// <param name="request">Updated cardholder information</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>Updated cardholder information</returns>
    /// <remarks>
    /// Updates cardholder information.
    /// Only provided fields will be updated, others will remain unchanged.
    /// 
    /// Sample request:
    /// 
    ///     PUT /api/v1/cardholders/6JVNH7NFZS
    ///     {
    ///         "emailAddress": "john.smith@example.com",
    ///         "phoneNumber": "+1987654321"
    ///     }
    /// </remarks>
    /// <response code="200">Cardholder updated successfully</response>
    /// <response code="400">Invalid request data or validation errors</response>
    /// <response code="401">Unauthorized - Invalid or missing JWT token</response>
    /// <response code="404">Cardholder not found</response>
    /// <response code="502">Bad Gateway - External service error</response>
    /// <response code="500">Internal server error</response>
    [HttpPut("{cardholderReference}")]
    [ProducesResponseType(typeof(UpdateCardholderResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status502BadGateway)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> UpdateCardholder(
        [FromRoute] [Required] string cardholderReference,
        [FromBody] [Required] UpdateCardholderRequest request,
        CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        var command = new UpdateCardholderCommand(
            cardholderReference,
            request.emailAddress,
            request.phoneNumber
        );

        var response = await _mediator.Send(command, cancellationToken);
        return Ok(response);
    }
}
