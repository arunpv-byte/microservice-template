using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Asp.Versioning;
using microservice_template.Application.Features.Cardholders.CreateCardholder;
using microservice_template.Application.Features.Cardholders.GetCardholder;
using microservice_template.Application.Features.Cardholders.UpdateCardholder;

namespace microservice_template.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/[controller]")]
[Authorize(AuthenticationSchemes = "CustomJwt")]
public sealed class CardholdersController : ControllerBase
{
    private readonly IMediator _mediator;

    public CardholdersController(IMediator mediator)
    {
        _mediator = mediator;
    }

    [HttpGet("{userId}")]
    [ProducesResponseType(typeof(GetCardholderResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetCardholder(
        [FromRoute] string userId,
        CancellationToken cancellationToken)
    {
        var query = new GetCardholderQuery(userId);
        var response = await _mediator.Send(query, cancellationToken);
        return Ok(response);
    }

    [HttpPost]
    [ProducesResponseType(typeof(CreateCardholderResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> CreateCardholder(
        [FromBody] CreateCardholderCommand command,
        CancellationToken cancellationToken)
    {
        var response = await _mediator.Send(command, cancellationToken);
        return CreatedAtAction(nameof(GetCardholder), new { userId = response.userId }, response);
    }

    [HttpPut("{userId}")]
    [ProducesResponseType(typeof(UpdateCardholderResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateCardholder(
        [FromRoute] string userId,
        [FromBody] UpdateCardholderRequest request,
        CancellationToken cancellationToken)
    {
        var command = new UpdateCardholderCommand(
            userId,
            request.firstName,
            request.lastName,
            request.email,
            request.phoneNumber,
            request.address,
            request.city,
            request.country,
            request.postalCode
        );

        var response = await _mediator.Send(command, cancellationToken);
        return Ok(response);
    }
}

public sealed record UpdateCardholderRequest(
    string firstName,
    string lastName,
    string email,
    string phoneNumber,
    string address,
    string city,
    string country,
    string postalCode
);