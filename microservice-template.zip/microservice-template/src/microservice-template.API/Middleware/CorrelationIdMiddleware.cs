using System.Diagnostics;

namespace microservice_template.API.Middleware;

public class CorrelationIdMiddleware
{
    private readonly RequestDelegate _next;
    private const string CorrelationIdHeader = "X-Correlation-ID";

    public CorrelationIdMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var correlationId = GetOrCreateCorrelationId(context);
        
        // Add to response headers
        context.Response.Headers[CorrelationIdHeader] = correlationId;
        
        // Add to activity for distributed tracing
        Activity.Current?.SetTag("correlation.id", correlationId);
        
        // Add to HttpContext for access throughout request
        context.Items["CorrelationId"] = correlationId;

        await _next(context);
    }

    private static string GetOrCreateCorrelationId(HttpContext context)
    {
        return context.Request.Headers[CorrelationIdHeader].FirstOrDefault() 
               ?? Guid.NewGuid().ToString();
    }
}