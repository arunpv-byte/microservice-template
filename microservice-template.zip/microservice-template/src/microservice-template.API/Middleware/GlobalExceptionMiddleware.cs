using FluentValidation;
using microservice_template.Domain.Exceptions;
using System.Net;
using System.Text.Json;

namespace microservice_template.API.Middleware;

public sealed class GlobalExceptionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<GlobalExceptionMiddleware> _logger;

    public GlobalExceptionMiddleware(RequestDelegate next, ILogger<GlobalExceptionMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            await HandleExceptionAsync(context, ex);
        }
    }

    private async Task HandleExceptionAsync(HttpContext context, Exception exception)
    {
        var correlationId = context.TraceIdentifier;
        
        _logger.LogError(exception, "An error occurred. CorrelationId: {CorrelationId}", correlationId);

        var (statusCode, message) = exception switch
        {
            NotFoundException => (HttpStatusCode.NotFound, exception.Message),
            UnauthorizedException => (HttpStatusCode.Unauthorized, exception.Message),
            ConflictException => (HttpStatusCode.Conflict, exception.Message),
            ExternalServiceException => (HttpStatusCode.BadGateway, exception.Message),
            FluentValidation.ValidationException validationEx => (HttpStatusCode.BadRequest, GetValidationErrors(validationEx)),
            ArgumentNullException => (HttpStatusCode.BadRequest, "Required parameter is missing"),
            ArgumentException => (HttpStatusCode.BadRequest, exception.Message),
            InvalidOperationException => (HttpStatusCode.BadRequest, exception.Message),
            TimeoutException => (HttpStatusCode.RequestTimeout, "Request timeout"),
            HttpRequestException => (HttpStatusCode.BadGateway, "External service error"),
            TaskCanceledException => (HttpStatusCode.RequestTimeout, "Request was cancelled"),
            DomainException => (HttpStatusCode.BadRequest, exception.Message),
            _ => (HttpStatusCode.InternalServerError, "An internal server error occurred")
        };

        var response = new ErrorResponse(
            (int)statusCode,
            message,
            correlationId,
            DateTime.UtcNow
        );

        context.Response.ContentType = "application/json";
        context.Response.StatusCode = (int)statusCode;

        var json = JsonSerializer.Serialize(response, new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        });

        await context.Response.WriteAsync(json);
    }

    private static string GetValidationErrors(FluentValidation.ValidationException exception)
    {
        var errors = exception.Errors
            .Select(e => $"{e.PropertyName}: {e.ErrorMessage}");
        
        return string.Join("; ", errors);
    }
}

public sealed record ErrorResponse(
    int StatusCode,
    string Message,
    string CorrelationId,
    DateTime Timestamp
);
