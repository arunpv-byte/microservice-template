namespace microservice_template.API.Middleware;

public static class RateLimitingExtensions
{
    public static IServiceCollection AddRateLimiting(this IServiceCollection services)
    {
        // Rate limiting will be implemented with custom middleware or third-party library
        // For now, return services without rate limiting to avoid package issues
        return services;
    }
}