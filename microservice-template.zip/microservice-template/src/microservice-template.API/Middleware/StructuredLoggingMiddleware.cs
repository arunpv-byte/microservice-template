using System.Diagnostics;
using System.Text;

namespace microservice_template.API.Middleware;

public class StructuredLoggingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<StructuredLoggingMiddleware> _logger;

    public StructuredLoggingMiddleware(RequestDelegate next, ILogger<StructuredLoggingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var stopwatch = Stopwatch.StartNew();
        var correlationId = context.Items["CorrelationId"]?.ToString();

        // Log request
        await LogRequest(context, correlationId);

        // Capture response
        var originalBodyStream = context.Response.Body;
        using var responseBody = new MemoryStream();
        context.Response.Body = responseBody;

        try
        {
            await _next(context);
        }
        finally
        {
            stopwatch.Stop();
            
            // Log response
            await LogResponse(context, correlationId, stopwatch.ElapsedMilliseconds);
            
            // Copy response back to original stream
            responseBody.Seek(0, SeekOrigin.Begin);
            await responseBody.CopyToAsync(originalBodyStream);
        }
    }

    private async Task LogRequest(HttpContext context, string? correlationId)
    {
        var request = context.Request;
        
        _logger.LogInformation("HTTP Request Started: {Method} {Path} {QueryString}",
            request.Method,
            request.Path,
            request.QueryString.ToString(),
            new
            {
                CorrelationId = correlationId,
                Method = request.Method,
                Path = request.Path.ToString(),
                QueryString = request.QueryString.ToString(),
                Headers = GetSafeHeaders(request.Headers),
                UserAgent = request.Headers.UserAgent.ToString(),
                RemoteIpAddress = context.Connection.RemoteIpAddress?.ToString(),
                Timestamp = DateTimeOffset.UtcNow
            });
    }

    private async Task LogResponse(HttpContext context, string? correlationId, long elapsedMs)
    {
        var response = context.Response;
        
        _logger.LogInformation("HTTP Request Completed: {Method} {Path} responded {StatusCode} in {ElapsedMs}ms",
            context.Request.Method,
            context.Request.Path,
            response.StatusCode,
            elapsedMs,
            new
            {
                CorrelationId = correlationId,
                Method = context.Request.Method,
                Path = context.Request.Path.ToString(),
                StatusCode = response.StatusCode,
                ElapsedMs = elapsedMs,
                ResponseSize = response.Body.Length,
                Timestamp = DateTimeOffset.UtcNow
            });
    }

    private static Dictionary<string, string> GetSafeHeaders(IHeaderDictionary headers)
    {
        var safeHeaders = new Dictionary<string, string>();
        var sensitiveHeaders = new[] { "authorization", "cookie", "x-api-key" };

        foreach (var header in headers)
        {
            var key = header.Key.ToLowerInvariant();
            var value = sensitiveHeaders.Contains(key) ? "[REDACTED]" : header.Value.ToString();
            safeHeaders[header.Key] = value;
        }

        return safeHeaders;
    }
}