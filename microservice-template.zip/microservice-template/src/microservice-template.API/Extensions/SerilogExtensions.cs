using Serilog;
using Serilog.Events;
using Serilog.Formatting.Json;

namespace microservice_template.API.Extensions;

public static class SerilogExtensions
{
    public static void ConfigureStructuredLogging(this WebApplicationBuilder builder)
    {
        Log.Logger = new LoggerConfiguration()
            .ReadFrom.Configuration(builder.Configuration)
            .Enrich.FromLogContext()
            .Enrich.With(new CorrelationIdEnricher(new HttpContextAccessor()))
            .Enrich.WithProperty("Application", "microservice-template")
            .Enrich.WithProperty("Environment", builder.Environment.EnvironmentName)
            .Enrich.WithProperty("Version", "1.0.0")
            .Enrich.WithMachineName()
            .WriteTo.Console(new JsonFormatter())
            .WriteTo.File(
                new JsonFormatter(),
                path: "logs/microservice-template-.log",
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: 30,
                fileSizeLimitBytes: 100_000_000,
                rollOnFileSizeLimit: true)
            .MinimumLevel.Information()
            .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
            .MinimumLevel.Override("System", LogEventLevel.Warning)
            .CreateLogger();

        builder.Host.UseSerilog();
    }
}