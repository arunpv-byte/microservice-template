using FluentValidation;
using microservice_template.Application.Behaviors;
using microservice_template.Application.Interfaces;
using microservice_template.Infrastructure.Configurations;
using microservice_template.Infrastructure.Services;
using Microsoft.AspNetCore.Authentication;

namespace microservice_template.API.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services)
    {
        var applicationAssembly = typeof(Application.Features.Cardholders.CreateCardholder.CreateCardholderCommand).Assembly;

        services.AddMediatR(cfg =>
        {
            cfg.RegisterServicesFromAssembly(applicationAssembly);
            cfg.AddOpenBehavior(typeof(LoggingBehavior<,>));
            cfg.AddOpenBehavior(typeof(ValidationBehavior<,>));
        });

        services.AddValidatorsFromAssembly(applicationAssembly);

        return services;
    }

    public static IServiceCollection AddKeycloakAuthentication(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddHttpClient<microservice_template.API.Authentication.CustomJwtHandler>();
        
        services.AddAuthentication("CustomJwt")
            .AddScheme<AuthenticationSchemeOptions, microservice_template.API.Authentication.CustomJwtHandler>("CustomJwt", options => { });

        services.AddAuthorization();
        return services;
    }

    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddInfrastructure(configuration);
        services.AddScoped<IThirdPartyServiceFactory, ThirdPartyServiceFactory>();
        return services;
    }

    public static IServiceCollection AddHealthChecks(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddHealthChecks()
            .AddSqlServer(
                configuration.GetConnectionString("DefaultConnection")!,
                name: "database",
                tags: new[] { "db", "sql" });

        return services;
    }
}
