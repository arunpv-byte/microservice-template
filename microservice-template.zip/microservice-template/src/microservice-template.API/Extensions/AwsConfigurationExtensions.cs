using Amazon.SecretsManager;
using Amazon.SimpleSystemsManagement;
using microservice_template.Infrastructure.Services;

namespace microservice_template.API.Extensions;

public static class AwsConfigurationExtensions
{
    public static IServiceCollection AddAwsServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddAWSService<IAmazonSecretsManager>();
        services.AddAWSService<IAmazonSimpleSystemsManagement>();
        services.AddScoped<IAwsSecretsService, AwsSecretsService>();
        
        return services;
    }

    public static async Task<IConfigurationBuilder> AddAwsSecretsAsync(this IConfigurationBuilder builder, string secretName, string? region = null)
    {
        var tempConfig = builder.Build();
        var secretsManager = new AmazonSecretsManagerClient(Amazon.RegionEndpoint.GetBySystemName(region ?? "us-east-1"));
        
        try
        {
            var secretValue = await secretsManager.GetSecretValueAsync(new Amazon.SecretsManager.Model.GetSecretValueRequest
            {
                SecretId = secretName
            });

            var secretData = System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, string>>(secretValue.SecretString);
            if (secretData != null)
            {
                builder.AddInMemoryCollection(secretData);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed to load secret {secretName}: {ex.Message}");
        }

        return builder;
    }
}