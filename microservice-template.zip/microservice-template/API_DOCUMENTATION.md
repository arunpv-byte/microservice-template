# API Documentation

## Overview

This microservice provides cardholder management and card balance inquiry functionality through RESTful APIs with enterprise-grade features including API versioning, rate limiting, distributed tracing, and caching. All endpoints support JWT Bearer authentication and return structured JSON responses.

## Base URL

- **Development**: `https://localhost:5001`
- **Production**: `https://your-domain.com`

## API Versioning

- **Current Version**: v1.0
- **URL Pattern**: `/api/v1/endpoint`
- **Alternative Methods**:
  - Query string: `?version=1.0`
  - Header: `X-Version: 1.0`

## Rate Limiting

- **Default**: 100 requests per minute per endpoint
- **Burst**: Token bucket for strict endpoints
- **Response Headers**: Rate limit information included
- **429 Status**: Returned when limits exceeded

## Authentication

### Swagger UI
- JWT Bearer token authentication enabled
- Use the "Authorize" button in Swagger UI
- Format: `Bearer <your-jwt-token>`

### API Requests
```http
Authorization: Bearer <your-jwt-token>
```

## Endpoints

### Cardholders

#### Create Cardholder
Creates a new cardholder in the system and NymCard platform.

```http
POST /api/v1/cardholders
Content-Type: application/json
Authorization: Bearer <token>

{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@example.com",
  "phoneNumber": "+1234567890",
  "dateOfBirth": "1990-01-01",
  "address1": "123 Main Street",
  "address2": "Apt 4B",
  "address3": "Building A",
  "town": "New York",
  "country": "USA",
  "postalCode": "10001",
  "username": "johndoe",
  "deviceId": "device123",
  "title": "Mr",
  "middlename": "Michael",
  "nickname": "Johnny",
  "gender": "M"
}
```

**Response (201 Created):**
```json
{
  "userId": "usr_1234567890",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@example.com",
  "status": "Success",
  "createdAt": "2024-01-15T10:30:00Z"
}
```

#### Get Cardholder
Retrieves cardholder information by NymCard user ID.

```http
GET /api/v1/cardholders/{userId}
Authorization: Bearer <token>
```

**Response (200 OK):**
```json
{
  "nymCardUserId": "usr_1234567890",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@example.com",
  "phoneNumber": "+1234567890",
  "dateOfBirth": "1990-01-01",
  "address": "123 Main Street",
  "city": "New York",
  "country": "USA",
  "postalCode": "10001",
  "status": "Active",
  "createdAt": "2024-01-15T10:30:00Z",
  "updatedAt": "2024-01-15T10:30:00Z"
}
```

#### Update Cardholder
Updates existing cardholder information.

```http
PUT /api/v1/cardholders/{userId}
Content-Type: application/json
Authorization: Bearer <token>

{
  "firstName": "John",
  "lastName": "Smith",
  "email": "john.smith@example.com",
  "phoneNumber": "+1234567890",
  "address": "456 Oak Avenue",
  "city": "Los Angeles",
  "country": "USA",
  "postalCode": "90210"
}
```

**Response (200 OK):**
```json
{
  "userId": "usr_1234567890",
  "firstName": "John",
  "lastName": "Smith",
  "email": "john.smith@example.com",
  "status": "Success",
  "updatedAt": "2024-01-15T11:45:00Z"
}
```

### Cards

#### Get Card Balance
Retrieves the available balance for a card account.

```http
GET /api/v1/cards/{accountId}/balance
Authorization: Bearer <token>
```

**Response (200 OK):**
```json
{
  "accountId": "acc_9876543210",
  "availableBalance": 1500.50,
  "currency": "USD"
}
```

### Health Check

#### Application Health
Checks the health status of the application and its dependencies.

```http
GET /health
```

**Response (200 OK):**
```json
{
  "status": "Healthy",
  "totalDuration": "00:00:00.0123456",
  "entries": {
    "database": {
      "status": "Healthy",
      "duration": "00:00:00.0098765"
    }
  }
}
```

## Error Responses

All endpoints return structured error responses with correlation IDs for tracking.

### Validation Error (400 Bad Request)
```json
{
  "type": "ValidationError",
  "title": "One or more validation errors occurred",
  "status": 400,
  "correlationId": "12345678-1234-1234-1234-123456789012",
  "errors": {
    "Email": ["Email is required"],
    "PhoneNumber": ["Phone number format is invalid"]
  }
}
```

### Not Found (404 Not Found)
```json
{
  "type": "NotFound",
  "title": "Resource not found",
  "status": 404,
  "detail": "Cardholder with userId 'usr_invalid' was not found.",
  "correlationId": "12345678-1234-1234-1234-123456789012"
}
```

### Internal Server Error (500 Internal Server Error)
```json
{
  "type": "InternalServerError",
  "title": "An error occurred while processing your request",
  "status": 500,
  "correlationId": "12345678-1234-1234-1234-123456789012"
}
```

## Third-Party Integration

### NymCard API
The service integrates with NymCard platform for cardholder and card management:

- **Authentication**: API Key based
- **Base URL**: `https://api.sand.platform.nymcard.com`
- **Endpoints Used**:
  - `POST /v1/users` - Create cardholder
  - `PUT /v1/users/{userId}` - Update cardholder
  - `GET /v1/accounts/{accountId}` - Get account balance

### Dynamic Authentication
The service supports multiple third-party integrations with configuration-driven authentication:

```json
{
  "ThirdPartyServices": {
    "NymCard": {
      "AuthType": "ApiKey",
      "ApiKey": "your-api-key"
    },
    "Stripe": {
      "AuthType": "Bearer",
      "Token": "your-bearer-token"
    },
    "PayPal": {
      "AuthType": "Basic",
      "Username": "client-id",
      "Password": "client-secret"
    }
  }
}
```

## Enterprise Features

### Distributed Tracing
- OpenTelemetry integration with correlation IDs
- ASP.NET Core, HTTP, and SQL instrumentation
- Jaeger exporter support for trace visualization
- Request/response tracking across services

### Caching
- Redis distributed caching with automatic fallback to memory
- JSON serialization for complex objects
- Configurable expiration policies
- Cache-aside pattern implementation

### Circuit Breaker
- Polly-based resilience patterns for external services
- Exponential backoff retry policies
- Automatic circuit breaking on failures
- Health monitoring and recovery

### Event-Driven Architecture
- Domain events published via MediatR
- Message publishing abstraction
- In-memory publisher for development
- Ready for external message queues (RabbitMQ, Azure Service Bus)

## Rate Limiting

- **Default**: 100 requests per minute per client
- **Burst**: Up to 20 requests in 10 seconds
- **Headers**: Rate limit information included in response headers

## Monitoring

### Correlation IDs
Every request is assigned a unique correlation ID for tracking across services and logs.

### Structured Logging
All requests and responses are logged with structured data including:
- Request method and path
- Response status and duration
- User context
- Correlation ID

### Health Checks
- Database connectivity
- External service availability
- Application metrics

## SDK Examples

### C# HttpClient
```csharp
var client = new HttpClient();
client.DefaultRequestHeaders.Authorization = 
    new AuthenticationHeaderValue("Bearer", "your-jwt-token");

var request = new
{
    firstName = "John",
    lastName = "Doe",
    email = "john.doe@example.com",
    // ... other properties
};

var json = JsonSerializer.Serialize(request);
var content = new StringContent(json, Encoding.UTF8, "application/json");

var response = await client.PostAsync(
    "https://localhost:5001/api/v1/cardholders", 
    content);
```

### JavaScript Fetch
```javascript
const response = await fetch('https://localhost:5001/api/v1/cardholders', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer your-jwt-token'
  },
  body: JSON.stringify({
    firstName: 'John',
    lastName: 'Doe',
    email: 'john.doe@example.com',
    // ... other properties
  })
});

const result = await response.json();
```

### cURL
```bash
curl -X POST "https://localhost:5001/api/v1/cardholders" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer your-jwt-token" \
  -d '{
    "firstName": "John",
    "lastName": "Doe",
    "email": "john.doe@example.com"
  }'
```

## Versioning

- **Current Version**: v1
- **URL Pattern**: `/api/v1/...` (future versions)
- **Backward Compatibility**: Maintained for at least 2 major versions

## Support

For API support and questions:
- **Documentation**: Available at `/swagger` endpoint
- **Health Status**: Monitor via `/health` endpoint
- **Logs**: Structured logging with correlation IDs for troubleshooting