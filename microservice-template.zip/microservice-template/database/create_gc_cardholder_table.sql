-- Create gc_cardholder table for storing cardholder details
CREATE TABLE gc_cardholder (
    Id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    NymCardUserId NVARCHAR(100) NOT NULL UNIQUE,
    FirstName NVARCHAR(100) NOT NULL,
    LastName NVARCHAR(100) NOT NULL,
    Email NVARCHAR(320) NOT NULL,
    PhoneNumber NVARCHAR(20) NOT NULL,
    DateOfBirth DATE NOT NULL,
    Address NVARCHAR(500) NOT NULL,
    City NVARCHAR(100) NOT NULL,
    Country NVARCHAR(100) NOT NULL,
    PostalCode NVARCHAR(20) NOT NULL,
    Status NVARCHAR(50) NOT NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    UpdatedAt DATETIME2 NULL
);

-- Create indexes for better performance
CREATE INDEX IX_gc_cardholder_NymCardUserId ON gc_cardholder(NymCardUserId);
CREATE INDEX IX_gc_cardholder_Email ON gc_cardholder(Email);
CREATE INDEX IX_gc_cardholder_CreatedAt ON gc_cardholder(CreatedAt);